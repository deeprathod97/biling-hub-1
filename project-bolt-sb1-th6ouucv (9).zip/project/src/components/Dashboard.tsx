import { useEffect, useState } from 'react';
import {
  FileText,
  IndianRupee,
  Truck,
  AlertCircle,
  Plus,
  TrendingUp,
  Users,
  Package,
  Layers,
  BarChart3,
  MapPin,
  Droplets,
  HardHat
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

type DashboardStats = {
  totalBills: number;
  totalAmount: number;
  totalTons: number;
  pendingAmount: number;
  asphaltBills: number;
  asphaltAmount: number;
  asphaltTons: number;
  rmcBills: number;
  rmcAmount: number;
  rmcMqb: number;
};

type BillType = 'stone_sell' | 'stone_purchase' | 'aggregate_sell' | 'aggregate_purchase';

const BILL_TYPE_LABELS: Record<BillType, string> = {
  'stone_sell': 'Stone Sell',
  'stone_purchase': 'Stone Purchase',
  'aggregate_sell': 'Aggregate Sell',
  'aggregate_purchase': 'Aggregate Purchase'
};

const COLORS = ['#f59e0b', '#3b82f6', '#10b981', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#84cc16'];

const PIE_COLORS = {
  aggregate: '#3b82f6',
  stone: '#f59e0b',
  asphalt: '#06b6d4',
  rmc: '#8b5cf6'
};

type View = 'dashboard' | 'parties' | 'materials' | 'trucks' | 'bills' | 'new-bill' | 'edit-bill' | 'view-bill';

interface DashboardProps {
  onNavigate: (view: View, billId?: string) => void;
}

interface ChartData {
  name: string;
  aggregate: number;
  stone: number;
  asphalt: number;
  rmc: number;
}

interface MaterialData {
  name: string;
  value: number;
  amount: number;
}

interface MonthlyData {
  month: string;
  aggregate: number;
  stone: number;
  asphalt: number;
  rmc: number;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [stats, setStats] = useState<DashboardStats>({
    totalBills: 0,
    totalAmount: 0,
    totalTons: 0,
    pendingAmount: 0,
    asphaltBills: 0,
    asphaltAmount: 0,
    asphaltTons: 0,
    rmcBills: 0,
    rmcAmount: 0,
    rmcMqb: 0
  });
  const [recentBills, setRecentBills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [billTypeData, setBillTypeData] = useState<{name: string; value: number}[]>([]);
  const [materialData, setMaterialData] = useState<MaterialData[]>([]);
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [asphaltGradeData, setAsphaltGradeData] = useState<{name: string; value: number}[]>([]);
  const [rmcGradeData, setRmcGradeData] = useState<{name: string; value: number}[]>([]);
  const [topParties, setTopParties] = useState<{name: string; amount: number}[]>([]);
  const [topSites, setTopSites] = useState<{name: string; amount: number}[]>([]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Aggregate bills
      const { data: billsData } = await supabase
        .from('bills')
        .select('total_amount, net_weight_ton, pending_amount, bill_type, material:materials(name), party:parties(name), bill_date');

      const totalBills = billsData?.length || 0;
      const totalAmount = billsData?.reduce((sum, b) => sum + (b.total_amount || 0), 0) || 0;
      const totalTons = billsData?.reduce((sum, b) => sum + (b.net_weight_ton || 0), 0) || 0;
      const pendingAmount = billsData?.reduce((sum, b) => sum + (b.pending_amount || 0), 0) || 0;

      // Aggregate bill type breakdown
      const typeBreakdown: Record<string, number> = {};
      billsData?.forEach(b => {
        const type = b.bill_type || 'aggregate_sell';
        typeBreakdown[type] = (typeBreakdown[type] || 0) + (b.total_amount || 0);
      });

      // Material breakdown
      const matBreakdown: Record<string, { qty: number; amount: number }> = {};
      billsData?.forEach(b => {
        const matName = (b.material as any)?.name || 'Unknown';
        if (!matBreakdown[matName]) matBreakdown[matName] = { qty: 0, amount: 0 };
        matBreakdown[matName].qty += (b.net_weight_ton || 0);
        matBreakdown[matName].amount += (b.total_amount || 0);
      });

      // Monthly breakdown for aggregate
      const monthAgg: Record<string, MonthlyData> = {};
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      billsData?.forEach(b => {
        const d = new Date(b.bill_date);
        const key = months[d.getMonth()];
        if (!monthAgg[key]) monthAgg[key] = { month: key, aggregate: 0, stone: 0, asphalt: 0, rmc: 0 };
        monthAgg[key].aggregate += (b.total_amount || 0);
      });

      // Top parties
      const partyBreakdown: Record<string, number> = {};
      billsData?.forEach(b => {
        const pName = (b.party as any)?.name || 'Unknown';
        partyBreakdown[pName] = (partyBreakdown[pName] || 0) + (b.total_amount || 0);
      });

      // Asphalt bills
      const { data: asphaltData } = await supabase
        .from('asphalt_bills')
        .select('total_amount, quantity_ton, bituminous_grade:bituminous_grades(grade_name), bill_date, site:sites(site_name)');

      const asphaltBills = asphaltData?.length || 0;
      const asphaltAmount = asphaltData?.reduce((sum, b) => sum + (b.total_amount || 0), 0) || 0;
      const asphaltTons = asphaltData?.reduce((sum, b) => sum + (b.quantity_ton || 0), 0) || 0;

      // Asphalt grade breakdown
      const asphaltGrades: Record<string, number> = {};
      asphaltData?.forEach(b => {
        const gName = (b.bituminous_grade as any)?.grade_name || 'Unknown';
        asphaltGrades[gName] = (asphaltGrades[gName] || 0) + (b.total_amount || 0);
      });

      // Asphalt monthly
      asphaltData?.forEach(b => {
        const d = new Date(b.bill_date);
        const key = months[d.getMonth()];
        if (!monthAgg[key]) monthAgg[key] = { month: key, aggregate: 0, stone: 0, asphalt: 0, rmc: 0 };
        monthAgg[key].asphalt += (b.total_amount || 0);
      });

      // Asphalt top sites
      const asphaltSites: Record<string, number> = {};
      asphaltData?.forEach(b => {
        const sName = (b.site as any)?.site_name || 'Unknown';
        asphaltSites[sName] = (asphaltSites[sName] || 0) + (b.total_amount || 0);
      });

      // RMC bills
      const { data: rmcData } = await supabase
        .from('rmc_bills')
        .select('total_amount, quantity_mqb, concrete_grade:concrete_grades(grade_name), bill_date, site:sites(site_name)');

      const rmcBills = rmcData?.length || 0;
      const rmcAmount = rmcData?.reduce((sum, b) => sum + (b.total_amount || 0), 0) || 0;
      const rmcMqb = rmcData?.reduce((sum, b) => sum + (b.quantity_mqb || 0), 0) || 0;

      // RMC grade breakdown
      const rmcGrades: Record<string, number> = {};
      rmcData?.forEach(b => {
        const gName = (b.concrete_grade as any)?.grade_name || 'Unknown';
        rmcGrades[gName] = (rmcGrades[gName] || 0) + (b.total_amount || 0);
      });

      // RMC monthly
      rmcData?.forEach(b => {
        const d = new Date(b.bill_date);
        const key = months[d.getMonth()];
        if (!monthAgg[key]) monthAgg[key] = { month: key, aggregate: 0, stone: 0, asphalt: 0, rmc: 0 };
        monthAgg[key].rmc += (b.total_amount || 0);
      });

      // RMC top sites
      const rmcSites: Record<string, number> = {};
      rmcData?.forEach(b => {
        const sName = (b.site as any)?.site_name || 'Unknown';
        rmcSites[sName] = (rmcSites[sName] || 0) + (b.total_amount || 0);
      });

      // Combine top sites
      const allSites: Record<string, number> = {};
      Object.entries(asphaltSites).forEach(([k, v]) => { allSites[k] = (allSites[k] || 0) + v; });
      Object.entries(rmcSites).forEach(([k, v]) => { allSites[k] = (allSites[k] || 0) + v; });

      setStats({ totalBills, totalAmount, totalTons, pendingAmount, asphaltBills, asphaltAmount, asphaltTons, rmcBills, rmcAmount, rmcMqb });

      setBillTypeData(Object.entries(typeBreakdown).map(([k, v]) => ({
        name: BILL_TYPE_LABELS[k as BillType] || k,
        value: Math.round(v)
      })));

      setMaterialData(Object.entries(matBreakdown).map(([k, v]) => ({
        name: k,
        value: Math.round(v.qty * 100) / 100,
        amount: Math.round(v.amount)
      })).sort((a, b) => b.amount - a.amount).slice(0, 6));

      setMonthlyData(months.map(m => monthAgg[m] || { month: m, aggregate: 0, stone: 0, asphalt: 0, rmc: 0 }));

      setAsphaltGradeData(Object.entries(asphaltGrades).map(([k, v]) => ({ name: k, value: Math.round(v) })));
      setRmcGradeData(Object.entries(rmcGrades).map(([k, v]) => ({ name: k, value: Math.round(v) })));

      setTopParties(Object.entries(partyBreakdown)
        .map(([k, v]) => ({ name: k, amount: Math.round(v) }))
        .sort((a, b) => b.amount - a.amount).slice(0, 5));

      setTopSites(Object.entries(allSites)
        .map(([k, v]) => ({ name: k, amount: Math.round(v) }))
        .sort((a, b) => b.amount - a.amount).slice(0, 5));

      // Get recent bills
      const { data: recentData } = await supabase
        .from('bills')
        .select(`
          id,
          bill_number,
          bill_date,
          bill_type,
          total_amount,
          pending_amount,
          party:parties(name),
          material:materials(name)
        `)
        .order('created_at', { ascending: false })
        .limit(10);

      setRecentBills(recentData || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const newFormatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
          <p className="font-semibold text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {newFormatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  const grandTotal = stats.totalAmount + stats.asphaltAmount + stats.rmcAmount;

  return (
    <div className="space-y-6">
      {/* Company Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center gap-6">
          <img
            src={COMPANY_PROFILE.logo}
            alt={COMPANY_PROFILE.name}
            className="w-24 h-24 object-contain bg-white rounded-xl p-2"
          />
          <div>
            <h1 className="text-3xl font-bold">{COMPANY_PROFILE.name}</h1>
            <p className="text-slate-300 mt-1">Parent: {COMPANY_PROFILE.parentCompany}</p>
            <div className="flex gap-6 mt-3 text-sm">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                {COMPANY_PROFILE.location}
              </span>
              <span>GST: {COMPANY_PROFILE.gst}</span>
              <span>Ph: {COMPANY_PROFILE.contact}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grand Total Banner */}
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-300 text-sm font-medium">Total Business Revenue (All Categories)</p>
            <p className="text-4xl font-bold mt-1">{newFormatCurrency(grandTotal)}</p>
          </div>
          <div className="bg-white/10 p-4 rounded-xl">
            <IndianRupee className="w-10 h-10 text-white" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-white/10">
          <div className="text-center">
            <p className="text-gray-400 text-xs">Aggregate & Stone</p>
            <p className="text-lg font-semibold">{newFormatCurrency(stats.totalAmount)}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-xs">Asphalt</p>
            <p className="text-lg font-semibold">{newFormatCurrency(stats.asphaltAmount)}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-xs">RMC</p>
            <p className="text-lg font-semibold">{newFormatCurrency(stats.rmcAmount)}</p>
          </div>
        </div>
      </div>

      {/* Category Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Aggregate */}
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-blue-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-3 rounded-xl">
                <HardHat className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm font-medium">Aggregate & Stone</p>
                <p className="text-2xl font-bold text-gray-900">{newFormatCurrency(stats.totalAmount)}</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-blue-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Bills</p>
              <p className="font-bold text-blue-700">{stats.totalBills}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Tons</p>
              <p className="font-bold text-blue-700">{stats.totalTons.toFixed(2)}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Pending</p>
              <p className="font-bold text-red-600">{newFormatCurrency(stats.pendingAmount)}</p>
            </div>
          </div>
        </div>

        {/* Asphalt */}
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-cyan-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-cyan-100 p-3 rounded-xl">
                <Droplets className="w-6 h-6 text-cyan-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm font-medium">Asphalt</p>
                <p className="text-2xl font-bold text-gray-900">{newFormatCurrency(stats.asphaltAmount)}</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-cyan-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Bills</p>
              <p className="font-bold text-cyan-700">{stats.asphaltBills}</p>
            </div>
            <div className="bg-cyan-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Tons</p>
              <p className="font-bold text-cyan-700">{stats.asphaltTons.toFixed(2)}</p>
            </div>
            <div className="bg-cyan-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Avg/Ton</p>
              <p className="font-bold text-cyan-700">{stats.asphaltTons > 0 ? newFormatCurrency(stats.asphaltAmount / stats.asphaltTons) : 'N/A'}</p>
            </div>
          </div>
        </div>

        {/* RMC */}
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-purple-100 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-3 rounded-xl">
                <Layers className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm font-medium">Ready Mix Concrete</p>
                <p className="text-2xl font-bold text-gray-900">{newFormatCurrency(stats.rmcAmount)}</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-purple-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Bills</p>
              <p className="font-bold text-purple-700">{stats.rmcBills}</p>
            </div>
            <div className="bg-purple-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">MQB</p>
              <p className="font-bold text-purple-700">{stats.rmcMqb.toFixed(3)}</p>
            </div>
            <div className="bg-purple-50 rounded-lg p-2">
              <p className="text-xs text-gray-500">Avg/MQB</p>
              <p className="font-bold text-purple-700">{stats.rmcMqb > 0 ? newFormatCurrency(stats.rmcAmount / stats.rmcMqb) : 'N/A'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row 1: Monthly Revenue Trend + Revenue Breakdown Pie */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue Trend */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-green-100 p-2 rounded-lg">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Monthly Revenue Trend</h2>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₹${(v / 100000).toFixed(1)}L`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area type="monotone" dataKey="aggregate" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} name="Aggregate" />
                <Area type="monotone" dataKey="asphalt" stackId="1" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.6} name="Asphalt" />
                <Area type="monotone" dataKey="rmc" stackId="1" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} name="RMC" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue Breakdown Pie */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-amber-100 p-2 rounded-lg">
              <BarChart3 className="w-5 h-5 text-amber-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Revenue by Category</h2>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[
                    { name: 'Aggregate & Stone', value: stats.totalAmount },
                    { name: 'Asphalt', value: stats.asphaltAmount },
                    { name: 'RMC', value: stats.rmcAmount }
                  ].filter(d => d.value > 0)}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={4}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  <Cell fill={PIE_COLORS.aggregate} />
                  <Cell fill={PIE_COLORS.asphalt} />
                  <Cell fill={PIE_COLORS.rmc} />
                </Pie>
                <Tooltip formatter={(value: number) => newFormatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Charts Row 2: Bill Type Breakdown + Material Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bill Type Bar Chart */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-blue-100 p-2 rounded-lg">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Aggregate Bills by Type</h2>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={billTypeData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={60} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(value: number) => newFormatCurrency(value)} />
                <Bar dataKey="value" name="Amount" radius={[6, 6, 0, 0]}>
                  {billTypeData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Material Breakdown */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-green-100 p-2 rounded-lg">
              <Package className="w-5 h-5 text-green-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Top Materials by Revenue</h2>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={materialData} layout="vertical" margin={{ top: 5, right: 5, left: 40, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" tick={{ fontSize: 12 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={100} />
                <Tooltip formatter={(value: number) => newFormatCurrency(value)} />
                <Bar dataKey="amount" name="Revenue" radius={[0, 6, 6, 0]} fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Charts Row 3: Asphalt Grades + RMC Grades */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Asphalt Grade Breakdown */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-cyan-100 p-2 rounded-lg">
              <Droplets className="w-5 h-5 text-cyan-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Asphalt by Grade</h2>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={asphaltGradeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {asphaltGradeData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => newFormatCurrency(value)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* RMC Grade Breakdown */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-purple-100 p-2 rounded-lg">
              <Layers className="w-5 h-5 text-purple-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">RMC by Concrete Grade</h2>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={rmcGradeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {rmcGradeData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => newFormatCurrency(value)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Charts Row 4: Top Parties + Top Sites */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Parties */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-indigo-100 p-2 rounded-lg">
              <Users className="w-5 h-5 text-indigo-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Top Parties by Revenue</h2>
          </div>
          <div className="space-y-3">
            {topParties.map((party, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-900">{party.name}</span>
                    <span className="font-bold text-indigo-700">{newFormatCurrency(party.amount)}</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mt-1">
                    <div
                      className="bg-indigo-500 h-2 rounded-full transition-all"
                      style={{ width: `${topParties[0]?.amount ? (party.amount / topParties[0].amount) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
            {topParties.length === 0 && (
              <p className="text-gray-500 text-center py-4">No party data available</p>
            )}
          </div>
        </div>

        {/* Top Sites */}
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-rose-100 p-2 rounded-lg">
              <MapPin className="w-5 h-5 text-rose-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900">Top Sites by Revenue</h2>
          </div>
          <div className="space-y-3">
            {topSites.map((site, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-700 font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-900">{site.name}</span>
                    <span className="font-bold text-rose-700">{newFormatCurrency(site.amount)}</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mt-1">
                    <div
                      className="bg-rose-500 h-2 rounded-full transition-all"
                      style={{ width: `${topSites[0]?.amount ? (site.amount / topSites[0].amount) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
            {topSites.length === 0 && (
              <p className="text-gray-500 text-center py-4">No site data available</p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-4 mb-6">
          <TrendingUp className="w-6 h-6 text-amber-500" />
          <h2 className="text-xl font-bold text-gray-900">Quick Actions</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            onClick={() => onNavigate('new-bill')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg"
          >
            <Plus className="w-5 h-5" />
            New Bill
          </button>
          <button
            onClick={() => onNavigate('parties')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-all"
          >
            <Users className="w-5 h-5" />
            Parties
          </button>
          <button
            onClick={() => onNavigate('materials')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-all"
          >
            <Package className="w-5 h-5" />
            Materials
          </button>
          <button
            onClick={() => onNavigate('trucks')}
            className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-all"
          >
            <Truck className="w-5 h-5" />
            Trucks
          </button>
        </div>
      </div>

      {/* Recent Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Recent Bills</h2>
            <button
              onClick={() => onNavigate('bills')}
              className="text-amber-600 hover:text-amber-700 font-semibold text-sm"
            >
              View All
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Bill No.</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Party</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Material</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Pending</th>
                <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {recentBills.map((bill) => (
                <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap font-semibold text-gray-900">#{bill.bill_number}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      bill.bill_type?.includes('stone') ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {BILL_TYPE_LABELS[bill.bill_type as BillType] || 'N/A'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">{bill.party?.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">{bill.material?.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right font-semibold text-gray-900">{newFormatCurrency(bill.total_amount)}</td>
                  <td className={`px-6 py-4 whitespace-nowrap text-right font-semibold ${bill.pending_amount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {newFormatCurrency(bill.pending_amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <button
                      onClick={() => onNavigate('view-bill', bill.id)}
                      className="text-amber-600 hover:text-amber-700 font-semibold text-sm"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
              {recentBills.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    No bills found. Create your first bill to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
