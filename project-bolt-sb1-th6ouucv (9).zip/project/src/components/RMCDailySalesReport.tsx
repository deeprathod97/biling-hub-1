import { useEffect, useState } from 'react';
import {
  Printer,
  FileText,
  Calendar,
  MapPin,
  Layers,
  Truck,
  Scale,
  IndianRupee,
  Filter,
  X
} from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

interface Site {
  id: string;
  site_name: string;
  site_number: string;
  site_location: string | null;
}

interface TM {
  id: string;
  tm_number: string;
  tm_code: string | null;
}

interface ConcreteGrade {
  id: string;
  grade_name: string;
}

interface RMCBillReport {
  id: string;
  bill_number: string;
  bill_date: string;
  quantity_mqb: number;
  rate_per_mqb: number;
  carting_bhadu: number;
  material_amount: number;
  carting_amount: number;
  total_amount: number;
  site: Site | null;
  tm: TM | null;
  concrete_grade: ConcreteGrade | null;
}

export default function RMCDailySalesReport() {
  const [loading, setLoading] = useState(true);
  const [sites, setSites] = useState<Site[]>([]);
  const [tms, setTMs] = useState<TM[]>([]);
  const [grades, setGrades] = useState<ConcreteGrade[]>([]);
  const [bills, setBills] = useState<RMCBillReport[]>([]);
  const [filteredBills, setFilteredBills] = useState<RMCBillReport[]>([]);

  const [filters, setFilters] = useState({
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    site_id: '',
    tm_id: '',
    concrete_grade_id: ''
  });

  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [bills, filters]);

  const fetchData = async () => {
    try {
      const [sitesRes, tmsRes, gradesRes, billsRes] = await Promise.all([
        supabase.from('sites').select('*').order('site_name'),
        supabase.from('tms').select('*').order('tm_number'),
        supabase.from('concrete_grades').select('*').order('grade_name'),
        supabase
          .from('rmc_bills')
          .select(`
            id,
            bill_number,
            bill_date,
            quantity_mqb,
            rate_per_mqb,
            carting_bhadu,
            material_amount,
            carting_amount,
            total_amount,
            site:sites(id, site_name, site_number, site_location),
            tm:tms(id, tm_number, tm_code),
            concrete_grade:concrete_grades(id, grade_name)
          `)
          .order('bill_date', { ascending: false })
          .order('bill_number', { ascending: false })
      ]);

      setSites(sitesRes.data || []);
      setTMs(tmsRes.data || []);
      setGrades(gradesRes.data || []);

      const formattedBills: RMCBillReport[] = (billsRes.data || []).map((bill: any) => ({
        id: bill.id,
        bill_number: bill.bill_number,
        bill_date: bill.bill_date,
        quantity_mqb: bill.quantity_mqb || 0,
        rate_per_mqb: bill.rate_per_mqb || 0,
        carting_bhadu: bill.carting_bhadu || 0,
        material_amount: bill.material_amount || 0,
        carting_amount: bill.carting_amount || 0,
        total_amount: bill.total_amount || 0,
        site: bill.site as Site | null,
        tm: bill.tm as TM | null,
        concrete_grade: bill.concrete_grade as ConcreteGrade | null
      }));

      setBills(formattedBills);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...bills];

    if (filters.startDate) {
      filtered = filtered.filter(bill => bill.bill_date >= filters.startDate);
    }
    if (filters.endDate) {
      filtered = filtered.filter(bill => bill.bill_date <= filters.endDate);
    }
    if (filters.site_id) {
      filtered = filtered.filter(bill => bill.site?.id === filters.site_id);
    }
    if (filters.tm_id) {
      filtered = filtered.filter(bill => bill.tm?.id === filters.tm_id);
    }
    if (filters.concrete_grade_id) {
      filtered = filtered.filter(bill => bill.concrete_grade?.id === filters.concrete_grade_id);
    }

    setFilteredBills(filtered);
  };

  const clearFilters = () => {
    setFilters({
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      site_id: '',
      tm_id: '',
      concrete_grade_id: ''
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatNumber = (num: number, decimals: number = 3) => {
    return new Intl.NumberFormat('en-IN', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(num);
  };

  // Calculate totals
  const totals = filteredBills.reduce(
    (acc, bill) => ({
      totalMqb: acc.totalMqb + (bill.quantity_mqb || 0),
      totalMaterialAmount: acc.totalMaterialAmount + (bill.material_amount || 0),
      totalCartingAmount: acc.totalCartingAmount + (bill.carting_amount || 0),
      totalAmount: acc.totalAmount + (bill.total_amount || 0),
      count: acc.count + 1
    }),
    { totalMqb: 0, totalMaterialAmount: 0, totalCartingAmount: 0, totalAmount: 0, count: 0 }
  );

  const handlePrint = () => {
    const siteName = filters.site_id
      ? sites.find(s => s.id === filters.site_id)?.site_name || 'All Sites'
      : 'All Sites';
    const tmName = filters.tm_id
      ? tms.find(t => t.id === filters.tm_id)?.tm_number || 'All TMs'
      : 'All TMs';
    const gradeName = filters.concrete_grade_id
      ? grades.find(g => g.id === filters.concrete_grade_id)?.grade_name || 'All Grades'
      : 'All Grades';

    const tableRows = filteredBills
      .map(
        (bill, index) => `
        <tr>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${index + 1}</td>
          <td style="padding: 8px; border: 1px solid #000; font-weight: bold;">${bill.bill_number}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${bill.bill_date}</td>
          <td style="padding: 8px; border: 1px solid #000;">${bill.site?.site_name || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000;">${bill.site?.site_location || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${bill.concrete_grade?.grade_name || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: center;">${bill.tm?.tm_number || '-'}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: right;">${formatNumber(bill.quantity_mqb)}</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: right;">${formatCurrency(bill.carting_bhadu)}/MQB</td>
          <td style="padding: 8px; border: 1px solid #000; text-align: right;">${formatCurrency(bill.total_amount)}</td>
        </tr>
      `
      )
      .join('');

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>RMC Daily Sales Report</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 1200px; margin: 0 auto; font-size: 12px; }
          .header { text-align: center; border-bottom: 3px solid #1e293b; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; color: #1e293b; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .title { font-size: 18px; font-weight: bold; text-align: center; margin: 20px 0; border: 2px solid #1e293b; padding: 10px; color: #1e293b; }
          .filters { display: flex; justify-content: space-between; margin: 15px 0; font-size: 12px; flex-wrap: wrap; }
          .filter-item { margin-right: 20px; margin-bottom: 5px; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          th { background: #1e293b; color: #fff; padding: 10px; border: 1px solid #000; font-weight: bold; text-align: center; font-size: 11px; }
          td { border: 1px solid #000; }
          tr:nth-child(even) { background: #f9fafb; }
          .totals { margin-top: 20px; padding: 15px; border: 2px solid #1e293b; background: #f9f9f9; }
          .totals-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .totals-row.final { font-weight: bold; font-size: 16px; border-top: 1px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
          .summary-box { display: flex; justify-content: space-around; margin: 20px 0; padding: 15px; background: linear-gradient(135deg, #1e293b 0%, #334155 100%); color: #fff; border-radius: 10px; }
          .summary-item { text-align: center; }
          .summary-label { font-size: 11px; opacity: 0.8; }
          .summary-value { font-size: 20px; font-weight: bold; margin-top: 5px; }
          @media print { body { padding: 0; } @page { margin: 10mm; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title">READY MIX CONCRETE DAILY SALES REPORT</div>

        <div class="filters">
          <div class="filter-item"><strong>Site:</strong> ${siteName}</div>
          <div class="filter-item"><strong>TM:</strong> ${tmName}</div>
          <div class="filter-item"><strong>Grade:</strong> ${gradeName}</div>
          <div class="filter-item"><strong>From:</strong> ${filters.startDate || 'N/A'}</div>
          <div class="filter-item"><strong>To:</strong> ${filters.endDate || 'N/A'}</div>
          <div class="filter-item"><strong>Total Bills:</strong> ${totals.count}</div>
        </div>

        <div class="summary-box">
          <div class="summary-item">
            <div class="summary-label">Total MQB</div>
            <div class="summary-value">${formatNumber(totals.totalMqb)} MQB</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Material Amount</div>
            <div class="summary-value">${formatCurrency(totals.totalMaterialAmount)}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Carting Bhadu</div>
            <div class="summary-value">${formatCurrency(totals.totalCartingAmount)}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Grand Total</div>
            <div class="summary-value">${formatCurrency(totals.totalAmount)}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 40px;">#</th>
              <th>Bill No.</th>
              <th>Date</th>
              <th>Site Name</th>
              <th>Site Location</th>
              <th>Concrete Grade</th>
              <th>TM No.</th>
              <th>MQB</th>
              <th>Carting Bhadu</th>
              <th>Total Amount</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
        </table>

        <div class="totals">
          <div class="totals-row">
            <span>Total Bills:</span>
            <span>${totals.count}</span>
          </div>
          <div class="totals-row">
            <span>Total MQB:</span>
            <span>${formatNumber(totals.totalMqb)} MQB</span>
          </div>
          <div class="totals-row">
            <span>Total Material Amount:</span>
            <span>${formatCurrency(totals.totalMaterialAmount)}</span>
          </div>
          <div class="totals-row">
            <span>Total Carting Bhadu:</span>
            <span>${formatCurrency(totals.totalCartingAmount)}</span>
          </div>
          <div class="totals-row final">
            <span>Grand Total Amount:</span>
            <span>${formatCurrency(totals.totalAmount)}</span>
          </div>
        </div>

        <div class="footer">
          <p>Generated on: ${new Date().toLocaleString('en-IN')}</p>
          <p>This is a computer generated report from ${COMPANY_PROFILE.name} Billing System.</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-gray-800 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">RMC Daily Sales Report</h1>
            <p className="text-gray-500 text-sm">Ready Mix Concrete Sales Report</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all ${
              showFilters
                ? 'bg-gray-200 text-gray-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Filter className="w-5 h-5" />
            Filters
          </button>
          <button
            onClick={handlePrint}
            disabled={filteredBills.length === 0}
            className="flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-xl font-semibold hover:bg-gray-800 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Printer className="w-5 h-5" />
            Print Report
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className={`bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden transition-all ${showFilters ? 'block' : 'hidden'}`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-500" />
              Filter Report
            </h3>
            <button
              onClick={clearFilters}
              className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
            >
              <X className="w-4 h-4" />
              Clear All
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Start Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4 inline mr-1" />
                Start Date
              </label>
              <input
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent outline-none"
              />
            </div>

            {/* End Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4 inline mr-1" />
                End Date
              </label>
              <input
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent outline-none"
              />
            </div>

            {/* Site Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <MapPin className="w-4 h-4 inline mr-1" />
                Site
              </label>
              <select
                value={filters.site_id}
                onChange={(e) => setFilters({ ...filters, site_id: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent outline-none"
              >
                <option value="">All Sites</option>
                {sites.map((site) => (
                  <option key={site.id} value={site.id}>
                    {site.site_name} - #{site.site_number}
                  </option>
                ))}
              </select>
            </div>

            {/* TM Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Truck className="w-4 h-4 inline mr-1" />
                TM Number
              </label>
              <select
                value={filters.tm_id}
                onChange={(e) => setFilters({ ...filters, tm_id: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent outline-none"
              >
                <option value="">All TMs</option>
                {tms.map((tm) => (
                  <option key={tm.id} value={tm.id}>
                    {tm.tm_number} {tm.tm_code ? `(${tm.tm_code})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Concrete Grade Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Layers className="w-4 h-4 inline mr-1" />
                Concrete Grade
              </label>
              <select
                value={filters.concrete_grade_id}
                onChange={(e) => setFilters({ ...filters, concrete_grade_id: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent outline-none"
              >
                <option value="">All Grades</option>
                {grades.map((grade) => (
                  <option key={grade.id} value={grade.id}>
                    {grade.grade_name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Total Bills</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{totals.count}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Total MQB</p>
          <p className="text-2xl font-bold text-gray-900 mt-2">{formatNumber(totals.totalMqb)}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Material Amt</p>
          <p className="text-xl font-bold text-gray-900 mt-2">{formatCurrency(totals.totalMaterialAmount)}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-lg border-2 border-gray-900">
          <p className="text-gray-600 text-sm font-medium">Carting Bhadu</p>
          <p className="text-xl font-bold text-gray-900 mt-2">{formatCurrency(totals.totalCartingAmount)}</p>
        </div>
        <div className="bg-gray-900 rounded-xl p-5 shadow-lg text-white">
          <p className="text-gray-300 text-sm font-medium">Grand Total</p>
          <p className="text-2xl font-bold mt-2">{formatCurrency(totals.totalAmount)}</p>
        </div>
      </div>

      {/* Reports Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">RMC Sales Report Details</h3>
            <span className="text-sm text-gray-500">
              Period: {filters.startDate} to {filters.endDate}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-900">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">#</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Bill No.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Site Name</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Site Location</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">Grade</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-white uppercase">TM No.</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">MQB</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Carting Bhadu</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-white uppercase">Total Amt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredBills.map((bill, index) => (
                <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-gray-500">{index + 1}</td>
                  <td className="px-4 py-3 whitespace-nowrap font-bold text-gray-900">#{bill.bill_number}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.site?.site_name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.site?.site_location || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.concrete_grade?.grade_name || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.tm?.tm_number || '-'}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatNumber(bill.quantity_mqb)}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right text-gray-600">{formatCurrency(bill.carting_bhadu)}/MQB</td>
                  <td className="px-4 py-3 whitespace-nowrap text-right font-bold text-gray-900">{formatCurrency(bill.total_amount)}</td>
                </tr>
              ))}
              {filteredBills.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-gray-500">
                    No RMC bills found for the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
            {filteredBills.length > 0 && (
              <tfoot className="bg-gray-100">
                <tr>
                  <td colSpan={7} className="px-4 py-3 text-right font-semibold text-gray-900">
                    TOTAL
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-gray-900">
                    {formatNumber(totals.totalMqb)}
                  </td>
                  <td className="px-4 py-3 text-right text-gray-600">-</td>
                  <td className="px-4 py-3 text-right font-bold text-gray-900">
                    {formatCurrency(totals.totalAmount)}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
}
