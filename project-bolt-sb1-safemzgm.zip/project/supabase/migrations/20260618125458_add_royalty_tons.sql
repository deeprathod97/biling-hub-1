/*
# Add royalty_tons column to bills table

1. Changes
- Add `royalty_tons` column to bills table
- This allows separate royalty tons calculation independent of net weight ton
- royalty_amount = royalty_tons × royalty_per_ton

2. Important Notes
- Existing bills will have royalty_tons set to their net_weight_ton value for backward compatibility
*/

ALTER TABLE bills ADD COLUMN IF NOT EXISTS royalty_tons numeric NOT NULL DEFAULT 0;

-- Update existing bills to use net_weight_ton as royalty_tons for backward compatibility
UPDATE bills SET royalty_tons = net_weight_ton WHERE royalty_tons = 0;
