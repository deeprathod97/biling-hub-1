/*
# D MINERALS CO. - Complete Database Schema

1. New Tables
- `materials`: Stores material types with price per ton and royalty per ton
  - id (uuid, PK), name (text), price_per_ton (numeric), royalty_per_ton (numeric), created_at (timestamptz)
- `trucks`: Stores truck details with number, code, and wheel count
  - id (uuid, PK), truck_number (text), code_number (text), wheels (integer), created_at (timestamptz)
- `parties`: Stores party/customer details
  - id (uuid, PK), name (text), mobile (text), address (text), created_at (timestamptz)
- `bills`: Stores aggregate bills with all calculation fields
  - id (uuid, PK), bill_number (text, unique), party_id (FK to parties), party_name (text), party_mobile (text), party_address (text), material_id (FK to materials), material_name (text), material_price (numeric), truck_id (FK to trucks), truck_number (text), royalty_number (text), gross_weight_kg (numeric), tare_weight_kg (numeric), net_weight_ton (numeric), royalty_per_ton (numeric), royalty_amount (numeric), total_amount (numeric), payment (numeric, default 0), pending_amount (numeric), date (date), created_at (timestamptz)

2. Security
- Single-tenant app (no auth) - RLS enabled with anon+authenticated full access on all tables.

3. Important Notes
- Bill number auto-increments starting from 00000
- net_weight_ton = (gross_weight_kg - tare_weight_kg) / 1000
- royalty_amount = net_weight_ton * royalty_per_ton
- total_amount = (net_weight_ton * material_price) + royalty_amount
- pending_amount = total_amount - payment
*/

CREATE TABLE IF NOT EXISTS materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price_per_ton numeric NOT NULL DEFAULT 0,
  royalty_per_ton numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE materials ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_crud_materials" ON materials;
CREATE POLICY "anon_crud_materials" ON materials FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_materials" ON materials;
CREATE POLICY "anon_insert_materials" ON materials FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_materials" ON materials;
CREATE POLICY "anon_update_materials" ON materials FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_materials" ON materials;
CREATE POLICY "anon_delete_materials" ON materials FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS trucks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  truck_number text NOT NULL,
  code_number text DEFAULT '',
  wheels integer NOT NULL DEFAULT 6,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trucks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_crud_trucks" ON trucks;
CREATE POLICY "anon_crud_trucks" ON trucks FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_trucks" ON trucks;
CREATE POLICY "anon_insert_trucks" ON trucks FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_trucks" ON trucks;
CREATE POLICY "anon_update_trucks" ON trucks FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_trucks" ON trucks;
CREATE POLICY "anon_delete_trucks" ON trucks FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS parties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  mobile text DEFAULT '',
  address text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE parties ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_crud_parties" ON parties;
CREATE POLICY "anon_crud_parties" ON parties FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_parties" ON parties;
CREATE POLICY "anon_insert_parties" ON parties FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_parties" ON parties;
CREATE POLICY "anon_update_parties" ON parties FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_parties" ON parties;
CREATE POLICY "anon_delete_parties" ON parties FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL UNIQUE,
  party_id uuid REFERENCES parties(id) ON DELETE SET NULL,
  party_name text NOT NULL,
  party_mobile text DEFAULT '',
  party_address text DEFAULT '',
  material_id uuid REFERENCES materials(id) ON DELETE SET NULL,
  material_name text NOT NULL,
  material_price numeric NOT NULL DEFAULT 0,
  truck_id uuid REFERENCES trucks(id) ON DELETE SET NULL,
  truck_number text DEFAULT '',
  royalty_number text DEFAULT '',
  gross_weight_kg numeric NOT NULL DEFAULT 0,
  tare_weight_kg numeric NOT NULL DEFAULT 0,
  net_weight_ton numeric NOT NULL DEFAULT 0,
  royalty_per_ton numeric NOT NULL DEFAULT 0,
  royalty_amount numeric NOT NULL DEFAULT 0,
  total_amount numeric NOT NULL DEFAULT 0,
  payment numeric NOT NULL DEFAULT 0,
  pending_amount numeric NOT NULL DEFAULT 0,
  date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_crud_bills" ON bills;
CREATE POLICY "anon_crud_bills" ON bills FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_bills" ON bills;
CREATE POLICY "anon_insert_bills" ON bills FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_bills" ON bills;
CREATE POLICY "anon_update_bills" ON bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_bills" ON bills;
CREATE POLICY "anon_delete_bills" ON bills FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_bills_bill_number ON bills(bill_number);
CREATE INDEX IF NOT EXISTS idx_bills_party_id ON bills(party_id);
CREATE INDEX IF NOT EXISTS idx_bills_date ON bills(date);
