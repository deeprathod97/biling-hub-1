import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import CompanyProfile from './pages/CompanyProfile';
import Bills from './pages/Bills';
import CreateBill from './pages/CreateBill';
import EditBill from './pages/EditBill';
import PrintBill from './pages/PrintBill';
import PrintSlip from './pages/PrintSlip';
import AddPayment from './pages/AddPayment';
import Parties from './pages/Parties';
import Materials from './pages/Materials';
import Trucks from './pages/Trucks';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<CompanyProfile />} />
          <Route path="bills" element={<Bills />} />
          <Route path="bills/create" element={<CreateBill />} />
          <Route path="bills/:id/edit" element={<EditBill />} />
          <Route path="bills/:id/print" element={<PrintBill />} />
          <Route path="bills/:id/slip" element={<PrintSlip />} />
          <Route path="bills/:id/payment" element={<AddPayment />} />
          <Route path="parties" element={<Parties />} />
          <Route path="materials" element={<Materials />} />
          <Route path="trucks" element={<Trucks />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
