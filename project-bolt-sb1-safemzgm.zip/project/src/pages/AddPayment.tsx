import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Bill } from '../lib/types';
import { useParams, useNavigate } from 'react-router-dom';
import { DollarSign, Save, ArrowLeft } from 'lucide-react';

export default function AddPayment() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [bill, setBill] = useState<Bill | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');

  useEffect(() => {
    async function fetchBill() {
      const { data } = await supabase.from('bills').select('*').eq('id', id).maybeSingle();
      if (data) {
        setBill(data as Bill);
        setPaymentAmount(String((data as Bill).pending_amount));
      }
      setLoading(false);
    }
    fetchBill();
  }, [id]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!bill) return;
    setSaving(true);

    const newPayment = Number(bill.payment) + (parseFloat(paymentAmount) || 0);
    const newPending = Number(bill.total_amount) - newPayment;

    const { error } = await supabase
      .from('bills')
      .update({
        payment: Math.round(newPayment * 100) / 100,
        pending_amount: Math.round(newPending * 100) / 100,
      })
      .eq('id', id);

    if (error) {
      alert('Error updating payment: ' + error.message);
    } else {
      navigate('/bills');
    }
    setSaving(false);
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;
  if (!bill) return <div className="text-center py-12 text-slate-400">Bill not found</div>;

  const currentPayment = Number(bill.payment);
  const currentPending = Number(bill.pending_amount);
  const additionalPayment = parseFloat(paymentAmount) || 0;
  const newTotalPayment = currentPayment + additionalPayment;
  const newPendingAmount = Number(bill.total_amount) - newTotalPayment;

  return (
    <div className="max-w-lg mx-auto">
      <button onClick={() => navigate('/bills')} className="flex items-center gap-2 text-slate-600 hover:text-slate-800 text-sm font-medium mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to Bills
      </button>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">Add Payment</h2>
              <p className="text-sm text-slate-500">Bill #{bill.bill_number} - {bill.party_name}</p>
            </div>
          </div>

          <div className="space-y-4 mb-6">
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Total Amount</p>
                  <p className="font-bold text-slate-800">Rs. {Number(bill.total_amount).toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Already Paid</p>
                  <p className="font-bold text-green-700">Rs. {currentPayment.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Current Pending</p>
                  <p className="font-bold text-red-700">Rs. {currentPending.toFixed(2)}</p>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Payment Amount (Rs.)</label>
              <input
                type="number"
                step="0.01"
                value={paymentAmount}
                onChange={e => setPaymentAmount(e.target.value)}
                required
                className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none"
              />
            </div>

            <div className="bg-slate-50 rounded-xl p-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">New Total Payment</p>
                  <p className="font-bold text-green-700">Rs. {newTotalPayment.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Remaining Pending</p>
                  <p className={`font-bold ${newPendingAmount > 0 ? 'text-red-700' : 'text-green-700'}`}>
                    Rs. {newPendingAmount.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 px-6 py-4 border-t border-gray-100 flex justify-end gap-3">
          <button onClick={() => navigate('/bills')} className="px-4 py-2.5 text-sm text-slate-600 hover:text-slate-800 font-medium">Cancel</button>
          <button onClick={handleSubmit} disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50 transition-colors">
            <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Save Payment'}
          </button>
        </div>
      </div>
    </div>
  );
}
