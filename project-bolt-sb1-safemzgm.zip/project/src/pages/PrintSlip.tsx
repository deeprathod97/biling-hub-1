import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import type { Bill } from '../lib/types';
import { useParams, useNavigate } from 'react-router-dom';
import { Printer, ArrowLeft } from 'lucide-react';

export default function PrintSlip() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const printRef = useRef<HTMLDivElement>(null);
  const [bill, setBill] = useState<Bill | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchBill() {
      const { data } = await supabase.from('bills').select('*').eq('id', id).maybeSingle();
      if (data) setBill(data as Bill);
      setLoading(false);
    }
    fetchBill();
  }, [id]);

  function handlePrint() {
    const printContent = printRef.current;
    if (!printContent) return;
    const printWindow = window.open('', '_blank', 'width=600,height=400');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Slip - ${bill?.bill_number || ''}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Courier New', monospace; font-size: 11px; padding: 10px; color: #000; }
            .slip { max-width: 350px; margin: 0 auto; border: 1px solid #000; padding: 10px; }
            .slip-header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; }
            .slip-header h2 { font-size: 12px; font-weight: bold; }
            .slip-row { display: flex; justify-content: space-between; margin: 2px 0; }
            .slip-row .label { font-weight: bold; }
            .slip-divider { border-top: 1px dashed #000; margin: 6px 0; }
            .slip-total { font-weight: bold; font-size: 13px; }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;
  if (!bill) return <div className="text-center py-12 text-slate-400">Bill not found</div>;

  const royaltyTons = Number(bill.royalty_tons) || Number(bill.net_weight_ton);
  const materialAmount = Number(bill.net_weight_ton) * Number(bill.material_price);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button onClick={() => navigate('/bills')} className="flex items-center gap-2 text-slate-600 hover:text-slate-800 text-sm font-medium">
          <ArrowLeft className="w-4 h-4" /> Back to Bills
        </button>
        <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 text-white rounded-xl text-sm font-medium hover:bg-slate-700 transition-colors">
          <Printer className="w-4 h-4" /> Print Slip
        </button>
      </div>

      <div ref={printRef} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 font-mono text-sm">
        <div className="slip max-w-sm mx-auto border border-black p-4">
          <div className="slip-header text-center border-b border-dashed border-black pb-2 mb-2">
            <h2 className="text-xs font-bold">D MINERALS CO.</h2>
            <p className="text-xs">SEVALIYA</p>
            <p className="text-xs font-bold mt-1">DELIVERY SLIP</p>
          </div>

          <div className="space-y-0.5 text-xs">
            <div className="flex justify-between"><span className="font-bold">Slip No:</span> <span>{bill.bill_number}</span></div>
            <div className="flex justify-between"><span className="font-bold">Date:</span> <span>{bill.date}</span></div>
            <div className="border-t border-dashed border-black my-1"></div>
            <div className="flex justify-between"><span className="font-bold">Party:</span> <span>{bill.party_name}</span></div>
            <div className="flex justify-between"><span className="font-bold">Material:</span> <span>{bill.material_name}</span></div>
            <div className="flex justify-between"><span className="font-bold">Truck:</span> <span>{bill.truck_number || '-'}</span></div>
            <div className="border-t border-dashed border-black my-1"></div>
            <div className="flex justify-between"><span className="font-bold">Gross Wt:</span> <span>{Number(bill.gross_weight_kg).toFixed(2)} Kg</span></div>
            <div className="flex justify-between"><span className="font-bold">Tare Wt:</span> <span>{Number(bill.tare_weight_kg).toFixed(2)} Kg</span></div>
            <div className="flex justify-between font-bold"><span>Net Wt:</span> <span>{Number(bill.net_weight_ton).toFixed(3)} Ton</span></div>
            <div className="border-t border-dashed border-black my-1"></div>
            <div className="flex justify-between"><span className="font-bold">Material Amt:</span> <span>Rs. {materialAmount.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="font-bold">Royalty Tons:</span> <span>{royaltyTons.toFixed(3)}</span></div>
            <div className="flex justify-between"><span className="font-bold">Royalty Amt:</span> <span>Rs. {Number(bill.royalty_amount).toFixed(2)}</span></div>
            <div className="flex justify-between font-bold text-sm mt-1"><span>Total:</span> <span>Rs. {Number(bill.total_amount).toFixed(2)}</span></div>
          </div>

          <div className="border-t border-dashed border-black mt-3 pt-2 flex justify-between text-xs">
            <div className="border-t border-black pt-1 w-24 text-center">Signatory</div>
            <div className="border-t border-black pt-1 w-24 text-center">Receiver</div>
          </div>
        </div>
      </div>
    </div>
  );
}
