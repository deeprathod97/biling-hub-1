import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import type { Bill } from '../lib/types';
import { useParams, useNavigate } from 'react-router-dom';
import { Printer, ArrowLeft } from 'lucide-react';

export default function PrintBill() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const printRef = useRef<HTMLDivElement>(null);
  const [bill, setBill] = useState<Bill | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchBill() {
      const { data } = await supabase.from('bills').select('*').eq('id', id).maybeSingle();
      if (data) setBill(data as Bill);
      setLoading(false);
    }
    fetchBill();
  }, [id]);

  function handlePrint() {
    const printContent = printRef.current;
    if (!printContent) return;
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Bill - ${bill?.bill_number || ''}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Courier New', monospace; font-size: 12px; padding: 20px; color: #000; }
            .container { max-width: 750px; margin: 0 auto; border: 2px solid #000; padding: 20px; }
            .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 12px; margin-bottom: 12px; }
            .header img { width: 60px; height: 60px; margin-bottom: 6px; }
            .header h1 { font-size: 18px; font-weight: bold; margin-bottom: 2px; }
            .header p { font-size: 10px; margin: 1px 0; }
            .bill-title { text-align: center; font-size: 14px; font-weight: bold; margin: 10px 0; border: 1px solid #000; padding: 4px; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 20px; margin-bottom: 12px; font-size: 11px; }
            .info-grid .label { font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 12px; font-size: 11px; }
            table th, table td { border: 1px solid #000; padding: 4px 6px; text-align: left; }
            table th { background: #eee; font-weight: bold; }
            table td.right { text-align: right; }
            .total-section { border-top: 2px solid #000; margin-top: 8px; padding-top: 8px; }
            .total-row { display: flex; justify-content: space-between; font-size: 11px; margin: 2px 0; }
            .total-row.grand { font-weight: bold; font-size: 14px; border-top: 1px solid #000; padding-top: 4px; margin-top: 4px; }
            .footer { margin-top: 20px; display: flex; justify-content: space-between; font-size: 10px; }
            .signature { border-top: 1px solid #000; padding-top: 4px; width: 150px; text-align: center; }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;
  if (!bill) return <div className="text-center py-12 text-slate-400">Bill not found</div>;

  const royaltyTons = Number(bill.royalty_tons) || Number(bill.net_weight_ton);
  const materialAmount = Number(bill.net_weight_ton) * Number(bill.material_price);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button onClick={() => navigate('/bills')} className="flex items-center gap-2 text-slate-600 hover:text-slate-800 text-sm font-medium">
          <ArrowLeft className="w-4 h-4" /> Back to Bills
        </button>
        <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 text-white rounded-xl text-sm font-medium hover:bg-slate-700 transition-colors">
          <Printer className="w-4 h-4" /> Print Bill (A4)
        </button>
      </div>

      {/* Printable content - black & white A4 style */}
      <div ref={printRef} className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 font-mono text-sm">
        <div className="container">
          {/* Header */}
          <div className="header text-center border-b-2 border-black pb-3 mb-3">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png"
              alt="D MINERALS CO."
              className="w-16 h-16 mx-auto mb-2"
            />
            <h1 className="text-lg font-bold">D MINERALS CO.</h1>
            <p className="text-xs text-gray-600">( A unit of D ROCK SAND )</p>
            <p className="text-xs text-gray-600">SEVALIYA | GST: 24NTF192Q7GM1Z | Ph: 9737468847</p>
          </div>

          {/* Bill Title */}
          <div className="bill-title text-center text-sm font-bold border border-black py-1 mb-3">
            AGGREGATE BILL - #{bill.bill_number}
          </div>

          {/* Party & Date Info */}
          <div className="info-grid grid grid-cols-2 gap-1 mb-3 text-xs">
            <div><span className="font-bold">Party Name:</span> {bill.party_name}</div>
            <div><span className="font-bold">Date:</span> {bill.date}</div>
            <div><span className="font-bold">Mobile:</span> {bill.party_mobile || '-'}</div>
            <div><span className="font-bold">Royalty No.:</span> {bill.royalty_number || '-'}</div>
            <div><span className="font-bold">Address:</span> {bill.party_address || '-'}</div>
            <div><span className="font-bold">Truck No.:</span> {bill.truck_number || '-'}</div>
          </div>

          {/* Weight Table */}
          <table className="w-full border-collapse mb-3 text-xs">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-black px-2 py-1 text-left">Description</th>
                <th className="border border-black px-2 py-1 text-right">Gross Wt (Kg)</th>
                <th className="border border-black px-2 py-1 text-right">Tare Wt (Kg)</th>
                <th className="border border-black px-2 py-1 text-right">Net Wt (Ton)</th>
                <th className="border border-black px-2 py-1 text-right">Rate/Ton</th>
                <th className="border border-black px-2 py-1 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-black px-2 py-1">{bill.material_name}</td>
                <td className="border border-black px-2 py-1 text-right">{Number(bill.gross_weight_kg).toFixed(2)}</td>
                <td className="border border-black px-2 py-1 text-right">{Number(bill.tare_weight_kg).toFixed(2)}</td>
                <td className="border border-black px-2 py-1 text-right font-bold">{Number(bill.net_weight_ton).toFixed(3)}</td>
                <td className="border border-black px-2 py-1 text-right">{Number(bill.material_price).toFixed(2)}</td>
                <td className="border border-black px-2 py-1 text-right">{materialAmount.toFixed(2)}</td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-bold">Royalty</td>
                <td className="border border-black px-2 py-1"></td>
                <td className="border border-black px-2 py-1"></td>
                <td className="border border-black px-2 py-1 text-right font-bold">{royaltyTons.toFixed(3)}</td>
                <td className="border border-black px-2 py-1 text-right">{Number(bill.royalty_per_ton).toFixed(2)}</td>
                <td className="border border-black px-2 py-1 text-right">{Number(bill.royalty_amount).toFixed(2)}</td>
              </tr>
            </tbody>
          </table>

          {/* Totals */}
          <div className="total-section border-t-2 border-black mt-2 pt-2 space-y-1 text-xs">
            <div className="flex justify-between">
              <span>Material Amount ({Number(bill.net_weight_ton).toFixed(3)} Ton x {Number(bill.material_price).toFixed(2)}):</span>
              <span>Rs. {materialAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Royalty Amount ({royaltyTons.toFixed(3)} Ton x {Number(bill.royalty_per_ton).toFixed(2)}):</span>
              <span>Rs. {Number(bill.royalty_amount).toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold text-base border-t border-black pt-1 mt-1">
              <span>Total Amount:</span>
              <span>Rs. {Number(bill.total_amount).toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-green-700">
              <span>Payment Received:</span>
              <span>Rs. {Number(bill.payment).toFixed(2)}</span>
            </div>
            <div className={`flex justify-between font-bold ${Number(bill.pending_amount) > 0 ? 'text-red-700' : 'text-green-700'}`}>
              <span>Pending Amount:</span>
              <span>Rs. {Number(bill.pending_amount).toFixed(2)}</span>
            </div>
          </div>

          {/* Footer */}
          <div className="footer flex justify-between mt-8 text-xs">
            <div className="signature border-t border-black pt-1 w-36 text-center">Authorized Signatory</div>
            <div className="signature border-t border-black pt-1 w-36 text-center">Party Signature</div>
          </div>
        </div>
      </div>
    </div>
  );
}
