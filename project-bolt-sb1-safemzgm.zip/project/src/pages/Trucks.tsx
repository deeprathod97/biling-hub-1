import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Truck } from '../lib/types';
import { Plus, Pencil, Trash2, TruckIcon, X, Check } from 'lucide-react';

export default function Trucks() {
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [truckNumber, setTruckNumber] = useState('');
  const [codeNumber, setCodeNumber] = useState('');
  const [wheels, setWheels] = useState('6');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchTrucks();
  }, []);

  async function fetchTrucks() {
    const { data } = await supabase.from('trucks').select('*').order('created_at', { ascending: true });
    if (data) setTrucks(data);
    setLoading(false);
  }

  function resetForm() {
    setTruckNumber('');
    setCodeNumber('');
    setWheels('6');
    setEditingId(null);
    setShowForm(false);
  }

  function startEdit(t: Truck) {
    setTruckNumber(t.truck_number);
    setCodeNumber(t.code_number);
    setWheels(String(t.wheels));
    setEditingId(t.id);
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = {
      truck_number: truckNumber,
      code_number: codeNumber,
      wheels: parseInt(wheels) || 6,
    };

    if (editingId) {
      await supabase.from('trucks').update(payload).eq('id', editingId);
    } else {
      await supabase.from('trucks').insert(payload);
    }
    resetForm();
    await fetchTrucks();
    setSaving(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this truck?')) return;
    await supabase.from('trucks').delete().eq('id', id);
    await fetchTrucks();
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center">
            <TruckIcon className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Trucks</h1>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 text-white rounded-xl text-sm font-medium hover:bg-slate-700 transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Truck
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-800">{editingId ? 'Edit Truck' : 'New Truck'}</h2>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
          </div>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Truck Number</label>
              <input value={truckNumber} onChange={e => setTruckNumber(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Code Number</label>
              <input value={codeNumber} onChange={e => setCodeNumber(e.target.value)} className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Wheels</label>
              <select value={wheels} onChange={e => setWheels(e.target.value)} className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none bg-white">
                <option value="4">4</option>
                <option value="6">6</option>
                <option value="8">8</option>
                <option value="10">10</option>
                <option value="12">12</option>
                <option value="14">14</option>
                <option value="16">16</option>
                <option value="18">18</option>
                <option value="20">20</option>
                <option value="22">22</option>
              </select>
            </div>
            <div className="sm:col-span-3 flex justify-end gap-3">
              <button type="button" onClick={resetForm} className="px-4 py-2.5 text-sm text-slate-600 hover:text-slate-800 font-medium">Cancel</button>
              <button type="submit" disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50 transition-colors">
                <Check className="w-4 h-4" /> {editingId ? 'Update' : 'Save'}
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading...</div>
      ) : trucks.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <TruckIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No trucks added yet</p>
          <p className="text-slate-400 text-sm mt-1">Click "Add Truck" to get started</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-gray-100">
                <th className="text-left px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Truck Number</th>
                <th className="text-left px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Code Number</th>
                <th className="text-left px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Wheels</th>
                <th className="text-right px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {trucks.map(t => (
                <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-slate-800">{t.truck_number}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{t.code_number || '-'}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{t.wheels}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => startEdit(t)} className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(t.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
