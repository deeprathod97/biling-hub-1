import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Material, Truck, Party, Bill } from '../lib/types';
import { FileText, Save, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function CreateBill() {
  const navigate = useNavigate();
  const [parties, setParties] = useState<Party[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [selectedPartyId, setSelectedPartyId] = useState('');
  const [selectedMaterialId, setSelectedMaterialId] = useState('');
  const [selectedTruckId, setSelectedTruckId] = useState('');
  const [royaltyNumber, setRoyaltyNumber] = useState('');
  const [grossWeightKg, setGrossWeightKg] = useState('');
  const [tareWeightKg, setTareWeightKg] = useState('');
  const [royaltyTons, setRoyaltyTons] = useState('');
  const [payment, setPayment] = useState('0');
  const [billDate, setBillDate] = useState(new Date().toISOString().split('T')[0]);

  const selectedParty = parties.find(p => p.id === selectedPartyId);
  const selectedMaterial = materials.find(m => m.id === selectedMaterialId);
  const selectedTruck = trucks.find(t => t.id === selectedTruckId);

  const grossWeight = parseFloat(grossWeightKg) || 0;
  const tareWeight = parseFloat(tareWeightKg) || 0;
  const netWeightTon = (grossWeight - tareWeight) / 1000;
  const materialPrice = selectedMaterial?.price_per_ton || 0;
  const royaltyPerTon = selectedMaterial?.royalty_per_ton || 0;
  const royaltyTonsValue = parseFloat(royaltyTons) || 0;
  const royaltyAmount = royaltyTonsValue * royaltyPerTon;
  const materialAmount = netWeightTon * materialPrice;
  const totalAmount = materialAmount + royaltyAmount;
  const paymentAmount = parseFloat(payment) || 0;
  const pendingAmount = totalAmount - paymentAmount;

  useEffect(() => {
    async function fetchData() {
      const [partiesRes, materialsRes, trucksRes] = await Promise.all([
        supabase.from('parties').select('*').order('name'),
        supabase.from('materials').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
      ]);
      setParties(partiesRes.data || []);
      setMaterials(materialsRes.data || []);
      setTrucks(trucksRes.data || []);
      setLoading(false);
    }
    fetchData();
  }, []);

  // Auto-fill royalty tons with net weight when material changes
  useEffect(() => {
    if (selectedMaterialId && netWeightTon > 0) {
      setRoyaltyTons(netWeightTon.toFixed(3));
    }
  }, [selectedMaterialId, grossWeightKg, tareWeightKg]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedPartyId || !selectedMaterialId) {
      alert('Please select a party and material');
      return;
    }
    setSaving(true);

    const { data: lastBill } = await supabase
      .from('bills')
      .select('bill_number')
      .order('bill_number', { ascending: false })
      .limit(1)
      .maybeSingle();

    let nextNum = 1;
    if (lastBill?.bill_number) {
      nextNum = parseInt(lastBill.bill_number, 10) + 1;
    }
    const billNumber = String(nextNum).padStart(5, '0');

    const payload: Omit<Bill, 'id' | 'created_at'> = {
      bill_number: billNumber,
      party_id: selectedPartyId,
      party_name: selectedParty?.name || '',
      party_mobile: selectedParty?.mobile || '',
      party_address: selectedParty?.address || '',
      material_id: selectedMaterialId,
      material_name: selectedMaterial?.name || '',
      material_price: materialPrice,
      truck_id: selectedTruckId || null,
      truck_number: selectedTruck?.truck_number || '',
      royalty_number: royaltyNumber,
      gross_weight_kg: grossWeight,
      tare_weight_kg: tareWeight,
      net_weight_ton: Math.round(netWeightTon * 100) / 100,
      royalty_tons: Math.round(royaltyTonsValue * 100) / 100,
      royalty_per_ton: royaltyPerTon,
      royalty_amount: Math.round(royaltyAmount * 100) / 100,
      total_amount: Math.round(totalAmount * 100) / 100,
      payment: paymentAmount,
      pending_amount: Math.round(pendingAmount * 100) / 100,
      date: billDate,
    };

    const { error } = await supabase.from('bills').insert(payload);
    if (error) {
      alert('Error creating bill: ' + error.message);
    } else {
      navigate('/bills');
    }
    setSaving(false);
  }

  if (loading) {
    return <div className="text-center py-12 text-slate-400">Loading data...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center">
          <FileText className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-slate-800">Create Bill</h1>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 space-y-6">
          {/* Party Selection */}
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Party Details</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Select Party</label>
                <select value={selectedPartyId} onChange={e => setSelectedPartyId(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none bg-white">
                  <option value="">-- Select Party --</option>
                  {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mobile</label>
                  <input value={selectedParty?.mobile || ''} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-gray-50 text-sm text-slate-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Address</label>
                  <input value={selectedParty?.address || ''} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-gray-50 text-sm text-slate-500" />
                </div>
              </div>
            </div>
          </div>

          {/* Material & Truck */}
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Material & Transport</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Select Material</label>
                <select value={selectedMaterialId} onChange={e => setSelectedMaterialId(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none bg-white">
                  <option value="">-- Select Material --</option>
                  {materials.map(m => <option key={m.id} value={m.id}>{m.name} (Rs.{m.price_per_ton}/ton)</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Select Truck</label>
                <select value={selectedTruckId} onChange={e => setSelectedTruckId(e.target.value)} className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none bg-white">
                  <option value="">-- Select Truck --</option>
                  {trucks.map(t => <option key={t.id} value={t.id}>{t.truck_number} ({t.wheels} wheels)</option>)}
                </select>
                {selectedTruck && (
                  <p className="text-xs text-slate-500 mt-1.5 bg-slate-100 px-2 py-1 rounded inline-block">Wheels: <span className="font-bold text-slate-800">{selectedTruck.wheels}</span></p>
                )}
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Royalty Number</label>
                <input value={royaltyNumber} onChange={e => setRoyaltyNumber(e.target.value)} className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
              </div>
            </div>
          </div>

          {/* Weight Details */}
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Weight & Calculation</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Gross Weight (Kg)</label>
                <input type="number" step="0.01" value={grossWeightKg} onChange={e => setGrossWeightKg(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Tare Weight (Kg)</label>
                <input type="number" step="0.01" value={tareWeightKg} onChange={e => setTareWeightKg(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Net Weight (Ton)</label>
                <input value={netWeightTon.toFixed(3)} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-slate-50 text-sm font-semibold text-slate-800" />
              </div>
            </div>
          </div>

          {/* Royalty Calculation */}
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Royalty Details</h3>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Royalty Tons</label>
                <input type="number" step="0.001" value={royaltyTons} onChange={e => setRoyaltyTons(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
                <p className="text-xs text-slate-400 mt-1">Enter tons for royalty calculation</p>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Royalty Rate/Ton</label>
                <input value={royaltyPerTon} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-gray-50 text-sm text-slate-500" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Royalty Amount</label>
                <input value={royaltyAmount.toFixed(2)} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-amber-50 text-sm font-semibold text-amber-800" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Material Amount</label>
                <input value={materialAmount.toFixed(2)} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-green-50 text-sm font-semibold text-green-700" />
              </div>
            </div>
          </div>

          {/* Amount Calculation */}
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Amount Details</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Material Price/Ton</label>
                <input value={materialPrice} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-gray-50 text-sm text-slate-500" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Net Weight (Ton)</label>
                <input value={netWeightTon.toFixed(3)} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-gray-50 text-sm text-slate-500" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Royalty Tons</label>
                <input value={royaltyTonsValue.toFixed(3)} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-gray-50 text-sm text-slate-500" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Total Amount</label>
                <input value={totalAmount.toFixed(2)} readOnly className="w-full px-3 py-2.5 rounded-lg border border-gray-100 bg-slate-50 text-sm font-bold text-slate-800" />
              </div>
            </div>
          </div>

          {/* Payment */}
          <div>
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Payment</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Payment Amount (Rs.)</label>
                <input type="number" step="0.01" value={payment} onChange={e => setPayment(e.target.value)} className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Pending Amount</label>
                <input value={pendingAmount.toFixed(2)} readOnly className={`w-full px-3 py-2.5 rounded-lg border text-sm font-semibold ${pendingAmount > 0 ? 'bg-red-50 border-red-100 text-red-700' : 'bg-green-50 border-green-100 text-green-700'}`} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Bill Date</label>
                <input type="date" value={billDate} onChange={e => setBillDate(e.target.value)} className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-gray-100 flex items-center justify-between">
          <button type="button" onClick={() => navigate('/bills')} className="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-600 hover:text-slate-800 font-medium">
            <X className="w-4 h-4" /> Cancel
          </button>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-xs text-slate-400">Total Amount</p>
              <p className="text-xl font-bold text-slate-800">Rs. {totalAmount.toFixed(2)}</p>
            </div>
            <button type="submit" disabled={saving} className="flex items-center gap-2 px-6 py-2.5 bg-slate-800 text-white rounded-xl text-sm font-medium hover:bg-slate-700 disabled:opacity-50 transition-colors">
              <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Create Bill'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
