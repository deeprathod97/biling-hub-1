import { Building2, MapPin, Phone, Hash, Briefcase } from 'lucide-react';

export default function CompanyProfile() {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-8 py-10">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center p-2 border border-white/20">
              <img
                src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png"
                alt="D MINERALS CO. Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white tracking-tight">D MINERALS CO.</h1>
              <p className="text-slate-300 mt-1 text-sm font-medium tracking-wide">Mineral & Aggregate Suppliers</p>
            </div>
          </div>
        </div>

        <div className="px-8 py-8 space-y-5">
          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Parent Company</p>
              <p className="text-slate-800 font-semibold text-lg mt-0.5">D ROCK SAND</p>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Location</p>
              <p className="text-slate-800 font-semibold text-lg mt-0.5">SEVALIYA</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
                <Hash className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">GST Number</p>
                <p className="text-slate-800 font-semibold mt-0.5 text-sm">24NTF192Q7GM1Z</p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Contact Number</p>
                <p className="text-slate-800 font-semibold mt-0.5 text-sm">9737468847</p>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Business Type</p>
              <p className="text-slate-800 font-semibold mt-0.5">Mineral Mining & Aggregate Supply</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
