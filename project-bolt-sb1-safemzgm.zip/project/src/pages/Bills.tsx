import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Bill } from '../lib/types';
import { Plus, FileText, Pencil, Trash2, Printer, Receipt, DollarSign, Weight, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Bills() {
  const navigate = useNavigate();
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [partyFilter, setPartyFilter] = useState('');
  const [partyNames, setPartyNames] = useState<string[]>([]);

  useEffect(() => {
    fetchBills();
  }, []);

  async function fetchBills() {
    const { data } = await supabase.from('bills').select('*').order('bill_number', { ascending: false });
    if (data) {
      setBills(data as Bill[]);
      const names = [...new Set(data.map((b: Bill) => b.party_name))];
      setPartyNames(names.sort());
    }
    setLoading(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this bill?')) return;
    await supabase.from('bills').delete().eq('id', id);
    await fetchBills();
  }

  const filteredBills = partyFilter ? bills.filter(b => b.party_name === partyFilter) : bills;
  const totalBills = filteredBills.length;
  const totalAmount = filteredBills.reduce((sum, b) => sum + Number(b.total_amount), 0);
  const totalTons = filteredBills.reduce((sum, b) => sum + Number(b.net_weight_ton), 0);
  const totalPending = filteredBills.reduce((sum, b) => sum + Number(b.pending_amount), 0);
  const totalPayment = filteredBills.reduce((sum, b) => sum + Number(b.payment), 0);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Bills</h1>
        </div>
        <button
          onClick={() => navigate('/bills/create')}
          className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 text-white rounded-xl text-sm font-medium hover:bg-slate-700 transition-colors"
        >
          <Plus className="w-4 h-4" /> Create Bill
        </button>
      </div>

      {/* Dashboard Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center">
              <FileText className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Bills</p>
          </div>
          <p className="text-2xl font-bold text-slate-800">{totalBills}</p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-green-50 flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-green-600" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Amount</p>
          </div>
          <p className="text-2xl font-bold text-slate-800">Rs. {totalAmount.toFixed(2)}</p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-amber-50 flex items-center justify-center">
              <Weight className="w-4 h-4 text-amber-600" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Tons</p>
          </div>
          <p className="text-2xl font-bold text-slate-800">{totalTons.toFixed(3)}</p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-red-50 flex items-center justify-center">
              <AlertCircle className="w-4 h-4 text-red-600" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Pending</p>
          </div>
          <p className="text-2xl font-bold text-red-700">Rs. {totalPending.toFixed(2)}</p>
          <p className="text-xs text-slate-400 mt-1">Paid: Rs. {totalPayment.toFixed(2)}</p>
        </div>
      </div>

      {/* Filter */}
      {partyNames.length > 0 && (
        <div className="mb-4">
          <select
            value={partyFilter}
            onChange={e => setPartyFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none bg-white"
          >
            <option value="">All Parties</option>
            {partyNames.map(name => <option key={name} value={name}>{name}</option>)}
          </select>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading bills...</div>
      ) : bills.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No bills created yet</p>
          <p className="text-slate-400 text-sm mt-1">Click "Create Bill" to get started</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 border-b border-gray-100">
                  <th className="text-left px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Bill No.</th>
                  <th className="text-left px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Date</th>
                  <th className="text-left px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Party</th>
                  <th className="text-left px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Material</th>
                  <th className="text-left px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Truck</th>
                  <th className="text-right px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Net Wt (Ton)</th>
                  <th className="text-right px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Total Amt</th>
                  <th className="text-right px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Paid</th>
                  <th className="text-right px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Pending</th>
                  <th className="text-center px-4 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredBills.map(b => (
                  <tr key={b.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-4 py-3.5 text-sm font-mono font-semibold text-slate-800">{b.bill_number}</td>
                    <td className="px-4 py-3.5 text-sm text-slate-600 whitespace-nowrap">{b.date}</td>
                    <td className="px-4 py-3.5 text-sm font-medium text-slate-800">{b.party_name}</td>
                    <td className="px-4 py-3.5 text-sm text-slate-600">{b.material_name}</td>
                    <td className="px-4 py-3.5 text-sm text-slate-600">{b.truck_number || '-'}</td>
                    <td className="px-4 py-3.5 text-sm text-slate-600 text-right">{Number(b.net_weight_ton).toFixed(3)}</td>
                    <td className="px-4 py-3.5 text-sm font-semibold text-slate-800 text-right">{Number(b.total_amount).toFixed(2)}</td>
                    <td className="px-4 py-3.5 text-sm text-green-700 text-right">{Number(b.payment).toFixed(2)}</td>
                    <td className={`px-4 py-3.5 text-sm text-right font-semibold ${Number(b.pending_amount) > 0 ? 'text-red-700' : 'text-green-700'}`}>
                      {Number(b.pending_amount).toFixed(2)}
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center justify-center gap-0.5">
                        <button onClick={() => navigate(`/bills/${b.id}/print`)} title="Print Bill" className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"><Printer className="w-3.5 h-3.5" /></button>
                        <button onClick={() => navigate(`/bills/${b.id}/slip`)} title="Print Slip" className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"><Receipt className="w-3.5 h-3.5" /></button>
                        <button onClick={() => navigate(`/bills/${b.id}/payment`)} title="Add Payment" className="p-1.5 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"><DollarSign className="w-3.5 h-3.5" /></button>
                        <button onClick={() => navigate(`/bills/${b.id}/edit`)} title="Edit Bill" className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                        <button onClick={() => handleDelete(b.id)} title="Delete Bill" className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
