import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Material } from '../lib/types';
import { Plus, Pencil, Trash2, Package, X, Check } from 'lucide-react';

export default function Materials() {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [pricePerTon, setPricePerTon] = useState('');
  const [royaltyPerTon, setRoyaltyPerTon] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchMaterials();
  }, []);

  async function fetchMaterials() {
    const { data } = await supabase.from('materials').select('*').order('created_at', { ascending: true });
    if (data) setMaterials(data);
    setLoading(false);
  }

  function resetForm() {
    setName('');
    setPricePerTon('');
    setRoyaltyPerTon('');
    setEditingId(null);
    setShowForm(false);
  }

  function startEdit(m: Material) {
    setName(m.name);
    setPricePerTon(String(m.price_per_ton));
    setRoyaltyPerTon(String(m.royalty_per_ton));
    setEditingId(m.id);
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = {
      name,
      price_per_ton: parseFloat(pricePerTon) || 0,
      royalty_per_ton: parseFloat(royaltyPerTon) || 0,
    };

    if (editingId) {
      await supabase.from('materials').update(payload).eq('id', editingId);
    } else {
      await supabase.from('materials').insert(payload);
    }
    resetForm();
    await fetchMaterials();
    setSaving(false);
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this material?')) return;
    await supabase.from('materials').delete().eq('id', id);
    await fetchMaterials();
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center">
            <Package className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Materials</h1>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 text-white rounded-xl text-sm font-medium hover:bg-slate-700 transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Material
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-slate-800">{editingId ? 'Edit Material' : 'New Material'}</h2>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
          </div>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Material Name</label>
              <input value={name} onChange={e => setName(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Price Per Ton</label>
              <input type="number" step="0.01" value={pricePerTon} onChange={e => setPricePerTon(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase tracking-wider">Royalty Per Ton</label>
              <input type="number" step="0.01" value={royaltyPerTon} onChange={e => setRoyaltyPerTon(e.target.value)} required className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:ring-2 focus:ring-slate-800 focus:border-transparent outline-none" />
            </div>
            <div className="sm:col-span-3 flex justify-end gap-3">
              <button type="button" onClick={resetForm} className="px-4 py-2.5 text-sm text-slate-600 hover:text-slate-800 font-medium">Cancel</button>
              <button type="submit" disabled={saving} className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 disabled:opacity-50 transition-colors">
                <Check className="w-4 h-4" /> {editingId ? 'Update' : 'Save'}
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading...</div>
      ) : materials.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No materials added yet</p>
          <p className="text-slate-400 text-sm mt-1">Click "Add Material" to get started</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-gray-100">
                <th className="text-left px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Name</th>
                <th className="text-left px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Price/Ton</th>
                <th className="text-left px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Royalty/Ton</th>
                <th className="text-right px-6 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {materials.map(m => (
                <tr key={m.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-slate-800">{m.name}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{Number(m.price_per_ton).toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{Number(m.royalty_per_ton).toLocaleString()}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => startEdit(m)} className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(m.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
