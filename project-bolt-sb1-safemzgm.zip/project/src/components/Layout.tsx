import { NavLink, Outlet } from 'react-router-dom';
import { Building2, FileText, Package, TruckIcon, Users, Menu } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/', icon: Building2, label: 'Company' },
  { to: '/bills', icon: FileText, label: 'Bills' },
  { to: '/parties', icon: Users, label: 'Parties' },
  { to: '/materials', icon: Package, label: 'Materials' },
  { to: '/trucks', icon: TruckIcon, label: 'Trucks' },
];

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-full w-64 bg-slate-900 z-50 transform transition-transform duration-200 ease-in-out lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEir58RaiNmktpFL4Kap_NJBXDQTKfPQkdEOHc7eV757m3fqizhSu6mQLm9XF5fn0avWI-pSUKxKzgWqTkWiAG4FyNr5s8nmLfRUN9oJdbIYpl_jl2Unrv0uauwMlbKMCxL76R64ssmXw1PTVVbI01SIu-nLYGd_VuMkHW6s4LTAcCLMhr8_WlRzfcW65Tdt/s320/ChatGPT_Image_Jun_15__2026__09_47_08_PM-removebg-preview.png"
              alt="Logo"
              className="w-9 h-9"
            />
            <div>
              <h1 className="text-white font-bold text-sm leading-tight">D MINERALS CO.</h1>
              <p className="text-slate-400 text-xs">D ROCK SAND</p>
            </div>
          </div>
        </div>

        <nav className="p-3 space-y-1">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="lg:ml-64">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-100 px-4 lg:px-8 py-3.5 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-slate-600 hover:text-slate-800">
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex-1" />
            <p className="text-xs text-slate-400 hidden sm:block">D MINERALS CO. - SEVALIYA</p>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
