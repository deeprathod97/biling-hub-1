export interface Material {
  id: string;
  name: string;
  price_per_ton: number;
  royalty_per_ton: number;
  created_at: string;
}

export interface Truck {
  id: string;
  truck_number: string;
  code_number: string;
  wheels: number;
  created_at: string;
}

export interface Party {
  id: string;
  name: string;
  mobile: string;
  address: string;
  created_at: string;
}

export interface Bill {
  id: string;
  bill_number: string;
  party_id: string | null;
  party_name: string;
  party_mobile: string;
  party_address: string;
  material_id: string | null;
  material_name: string;
  material_price: number;
  truck_id: string | null;
  truck_number: string;
  royalty_number: string;
  gross_weight_kg: number;
  tare_weight_kg: number;
  net_weight_ton: number;
  royalty_tons: number;
  royalty_per_ton: number;
  royalty_amount: number;
  total_amount: number;
  payment: number;
  pending_amount: number;
  date: string;
  created_at: string;
}

export interface BillFormData {
  party_id: string;
  material_id: string;
  truck_id: string;
  royalty_number: string;
  gross_weight_kg: number;
  tare_weight_kg: number;
  royalty_tons: number;
  payment: number;
  date: string;
}
