
-- Trucks table
CREATE TABLE trucks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  truck_number text NOT NULL,
  code text NOT NULL,
  wheels integer DEFAULT 6,
  created_at timestamptz DEFAULT now()
);

-- Bituminous Grades table
CREATE TABLE bituminous_grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grade text NOT NULL UNIQUE,
  price_per_tone numeric NOT NULL DEFAULT 0,
  carting_bhadu_per_tone numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Asphalt Bill Counter
CREATE TABLE asphalt_bill_counter (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  current_value integer DEFAULT 0
);

INSERT INTO asphalt_bill_counter (id, current_value) VALUES (1, 0);

-- Asphalt Bills table
CREATE TABLE asphalt_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text UNIQUE NOT NULL,
  date date DEFAULT CURRENT_DATE,
  site_id uuid REFERENCES sites(id),
  truck_id uuid REFERENCES trucks(id),
  grade_id uuid REFERENCES bituminous_grades(id),
  carting_bhadu numeric DEFAULT 0,
  quantity_tone numeric DEFAULT 0,
  total_tone numeric DEFAULT 0,
  amount numeric DEFAULT 0,
  payment_status text DEFAULT 'unpaid',
  created_at timestamptz DEFAULT now()
);

-- Asphalt Payments table
CREATE TABLE asphalt_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id uuid REFERENCES asphalt_bills(id),
  amount numeric NOT NULL,
  payment_date date DEFAULT CURRENT_DATE,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE trucks ENABLE ROW LEVEL SECURITY;
ALTER TABLE bituminous_grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE asphalt_bill_counter ENABLE ROW LEVEL SECURITY;
ALTER TABLE asphalt_bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE asphalt_payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for anon
CREATE POLICY "anon_select_trucks" ON trucks FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_trucks" ON trucks FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_trucks" ON trucks FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_trucks" ON trucks FOR DELETE TO anon USING (true);

CREATE POLICY "anon_select_bit_grades" ON bituminous_grades FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_bit_grades" ON bituminous_grades FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_bit_grades" ON bituminous_grades FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_bit_grades" ON bituminous_grades FOR DELETE TO anon USING (true);

CREATE POLICY "anon_select_asphalt_counter" ON asphalt_bill_counter FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_asphalt_counter" ON asphalt_bill_counter FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_asphalt_counter" ON asphalt_bill_counter FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY "anon_select_asphalt_bills" ON asphalt_bills FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_asphalt_bills" ON asphalt_bills FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_asphalt_bills" ON asphalt_bills FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_asphalt_bills" ON asphalt_bills FOR DELETE TO anon USING (true);

CREATE POLICY "anon_select_asphalt_payments" ON asphalt_payments FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_asphalt_payments" ON asphalt_payments FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_asphalt_payments" ON asphalt_payments FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_asphalt_payments" ON asphalt_payments FOR DELETE TO anon USING (true);

-- RLS Policies for authenticated (for completeness)
CREATE POLICY "auth_select_trucks" ON trucks FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_trucks" ON trucks FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_trucks" ON trucks FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_trucks" ON trucks FOR DELETE TO authenticated USING (true);

CREATE POLICY "auth_select_bit_grades" ON bituminous_grades FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_bit_grades" ON bituminous_grades FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_bit_grades" ON bituminous_grades FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_bit_grades" ON bituminous_grades FOR DELETE TO authenticated USING (true);

CREATE POLICY "auth_select_asphalt_counter" ON asphalt_bill_counter FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_asphalt_counter" ON asphalt_bill_counter FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_asphalt_counter" ON asphalt_bill_counter FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "auth_select_asphalt_bills" ON asphalt_bills FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_asphalt_bills" ON asphalt_bills FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_asphalt_bills" ON asphalt_bills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_asphalt_bills" ON asphalt_bills FOR DELETE TO authenticated USING (true);

CREATE POLICY "auth_select_asphalt_payments" ON asphalt_payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_asphalt_payments" ON asphalt_payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_asphalt_payments" ON asphalt_payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_asphalt_payments" ON asphalt_payments FOR DELETE TO authenticated USING (true);

-- RPC function for asphalt bill number
CREATE OR REPLACE FUNCTION get_next_asphalt_bill_number()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  next_num integer;
  result text;
BEGIN
  UPDATE asphalt_bill_counter SET current_value = current_value + 1 WHERE id = 1 RETURNING current_value INTO next_num;
  result := lpad(next_num::text, 5, '0');
  RETURN result;
END;
$$;

GRANT EXECUTE ON FUNCTION get_next_asphalt_bill_number() TO anon;
GRANT EXECUTE ON FUNCTION get_next_asphalt_bill_number() TO authenticated;
