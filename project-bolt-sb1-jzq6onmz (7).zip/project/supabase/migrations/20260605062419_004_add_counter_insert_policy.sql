
-- Add insert policy for bill_counter for anon
CREATE POLICY "anon_insert_counter" ON bill_counter FOR INSERT TO anon WITH CHECK (true);
