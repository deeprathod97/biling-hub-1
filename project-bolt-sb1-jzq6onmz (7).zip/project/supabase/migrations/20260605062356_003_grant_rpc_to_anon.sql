
-- Grant execute on the bill number function to anon and authenticated
GRANT EXECUTE ON FUNCTION get_next_bill_number() TO anon;
GRANT EXECUTE ON FUNCTION get_next_bill_number() TO authenticated;
