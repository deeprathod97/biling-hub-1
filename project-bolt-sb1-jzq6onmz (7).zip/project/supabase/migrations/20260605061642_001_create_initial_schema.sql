
-- Sites table
CREATE TABLE sites (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  site_number TEXT NOT NULL,
  location TEXT NOT NULL,
  incharge TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE sites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_sites" ON sites FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_sites" ON sites FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_sites" ON sites FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_sites" ON sites FOR DELETE TO authenticated USING (true);

-- Transit Mixers (TM) table
CREATE TABLE transit_mixers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  tm_number TEXT NOT NULL,
  code TEXT NOT NULL,
  wheels INTEGER NOT NULL DEFAULT 6,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE transit_mixers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_tms" ON transit_mixers FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_tms" ON transit_mixers FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_tms" ON transit_mixers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_tms" ON transit_mixers FOR DELETE TO authenticated USING (true);

-- Concrete Grades table
CREATE TABLE concrete_grades (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  grade TEXT NOT NULL,
  price_per_mqb NUMERIC(10,2) NOT NULL,
  carting_bhadu_per_mqb NUMERIC(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE concrete_grades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_grades" ON concrete_grades FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_grades" ON concrete_grades FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_grades" ON concrete_grades FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_grades" ON concrete_grades FOR DELETE TO authenticated USING (true);

-- RMC Bills table
CREATE TABLE rmc_bills (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  bill_number TEXT NOT NULL UNIQUE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  site_id UUID REFERENCES sites(id) ON DELETE SET NULL,
  tm_id UUID REFERENCES transit_mixers(id) ON DELETE SET NULL,
  grade_id UUID REFERENCES concrete_grades(id) ON DELETE SET NULL,
  carting_bhadu NUMERIC(10,2) NOT NULL DEFAULT 0,
  quantity_mqb NUMERIC(10,2) NOT NULL DEFAULT 0,
  total_mqb NUMERIC(10,2) NOT NULL DEFAULT 0,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  payment_status TEXT NOT NULL DEFAULT 'unpaid',
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE rmc_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_bills" ON rmc_bills FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_bills" ON rmc_bills FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_bills" ON rmc_bills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_bills" ON rmc_bills FOR DELETE TO authenticated USING (true);

-- Bill counter for auto-incrementing bill number
CREATE TABLE bill_counter (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  current_value INTEGER NOT NULL DEFAULT 0
);

INSERT INTO bill_counter (current_value) VALUES (0);

ALTER TABLE bill_counter ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_counter" ON bill_counter FOR SELECT TO authenticated USING (true);
CREATE POLICY "update_counter" ON bill_counter FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- Payments table
CREATE TABLE payments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  bill_id UUID REFERENCES rmc_bills(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  payment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_payments" ON payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_payments" ON payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_payments" ON payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_payments" ON payments FOR DELETE TO authenticated USING (true);

-- Function to get next bill number
CREATE OR REPLACE FUNCTION get_next_bill_number()
RETURNS TEXT AS $$
DECLARE
  next_val INTEGER;
  bill_num TEXT;
BEGIN
  UPDATE bill_counter SET current_value = current_value + 1 WHERE id = 1 RETURNING current_value INTO next_val;
  bill_num := LPAD(next_val::TEXT, 5, '0');
  RETURN bill_num;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
