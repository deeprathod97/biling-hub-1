
-- The app uses the anon key (no auth flow), so we need policies for anon role too.
-- Add anon policies for all tables.

-- Sites
CREATE POLICY "anon_select_sites" ON sites FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_sites" ON sites FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_sites" ON sites FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_sites" ON sites FOR DELETE TO anon USING (true);

-- Transit Mixers
CREATE POLICY "anon_select_tms" ON transit_mixers FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_tms" ON transit_mixers FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_tms" ON transit_mixers FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_tms" ON transit_mixers FOR DELETE TO anon USING (true);

-- Concrete Grades
CREATE POLICY "anon_select_grades" ON concrete_grades FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_grades" ON concrete_grades FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_grades" ON concrete_grades FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_grades" ON concrete_grades FOR DELETE TO anon USING (true);

-- RMC Bills
CREATE POLICY "anon_select_bills" ON rmc_bills FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_bills" ON rmc_bills FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_bills" ON rmc_bills FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_bills" ON rmc_bills FOR DELETE TO anon USING (true);

-- Bill Counter
CREATE POLICY "anon_select_counter" ON bill_counter FOR SELECT TO anon USING (true);
CREATE POLICY "anon_update_counter" ON bill_counter FOR UPDATE TO anon USING (true) WITH CHECK (true);

-- Payments
CREATE POLICY "anon_select_payments" ON payments FOR SELECT TO anon USING (true);
CREATE POLICY "anon_insert_payments" ON payments FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon_update_payments" ON payments FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_payments" ON payments FOR DELETE TO anon USING (true);
