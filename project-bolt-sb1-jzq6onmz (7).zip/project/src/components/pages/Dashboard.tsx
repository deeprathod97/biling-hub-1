import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { FileText, IndianRupee, Truck, Building2, Layers, TrendingUp } from 'lucide-react';

interface Stats {
  totalBills: number;
  totalAmount: number;
  totalQuantity: number;
  totalSites: number;
  totalTMs: number;
  totalGrades: number;
  paidAmount: number;
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats>({
    totalBills: 0,
    totalAmount: 0,
    totalQuantity: 0,
    totalSites: 0,
    totalTMs: 0,
    totalGrades: 0,
    paidAmount: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    try {
      const [billsRes, sitesRes, tmsRes, gradesRes, paymentsRes] = await Promise.all([
        supabase.from('rmc_bills').select('amount, quantity_mqb, payment_status'),
        supabase.from('sites').select('id', { count: 'exact' }),
        supabase.from('transit_mixers').select('id', { count: 'exact' }),
        supabase.from('concrete_grades').select('id', { count: 'exact' }),
        supabase.from('payments').select('amount'),
      ]);

      const bills = billsRes.data || [];
      const payments = paymentsRes.data || [];

      setStats({
        totalBills: bills.length,
        totalAmount: bills.reduce((s, b) => s + Number(b.amount), 0),
        totalQuantity: bills.reduce((s, b) => s + Number(b.quantity_mqb), 0),
        totalSites: sitesRes.count || 0,
        totalTMs: tmsRes.count || 0,
        totalGrades: gradesRes.count || 0,
        paidAmount: payments.reduce((s, p) => s + Number(p.amount), 0),
      });
    } catch (err) {
      console.error('Failed to load stats', err);
    } finally {
      setLoading(false);
    }
  }

  const statCards = [
    {
      label: 'Total Bills',
      value: stats.totalBills,
      icon: FileText,
      color: 'bg-slate-900',
    },
    {
      label: 'Total Amount',
      value: `₹${stats.totalAmount.toLocaleString('en-IN')}`,
      icon: IndianRupee,
      color: 'bg-emerald-600',
    },
    {
      label: 'Total Quantity (MQB)',
      value: stats.totalQuantity.toLocaleString('en-IN'),
      icon: TrendingUp,
      color: 'bg-blue-600',
    },
    {
      label: 'Paid Amount',
      value: `₹${stats.paidAmount.toLocaleString('en-IN')}`,
      icon: IndianRupee,
      color: 'bg-teal-600',
    },
    {
      label: 'Sites',
      value: stats.totalSites,
      icon: Building2,
      color: 'bg-amber-600',
    },
    {
      label: 'Transit Mixers',
      value: stats.totalTMs,
      icon: Truck,
      color: 'bg-rose-600',
    },
  ];

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-400 mt-1">
          Overview of D Concrete Pvt. Ltd. operations
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="card p-5 animate-slide-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                    {card.label}
                  </p>
                  <p className="text-2xl font-bold text-slate-900 mt-1">
                    {loading ? '...' : card.value}
                  </p>
                </div>
                <div className={`${card.color} p-2.5 rounded-xl`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Outstanding section */}
      <div className="card mt-6 p-6 animate-slide-up" style={{ animationDelay: '360ms' }}>
        <h3 className="text-base font-semibold text-slate-900 mb-3">
          Outstanding Amount
        </h3>
        <div className="flex items-end gap-3">
          <p className="text-3xl font-bold text-slate-900">
            ₹{(stats.totalAmount - stats.paidAmount).toLocaleString('en-IN')}
          </p>
          <p className="text-sm text-slate-400 mb-1">unpaid</p>
        </div>
        <div className="mt-4 w-full bg-slate-100 rounded-full h-2">
          <div
            className="bg-emerald-500 h-2 rounded-full transition-all duration-700"
            style={{
              width: stats.totalAmount
                ? `${Math.min((stats.paidAmount / stats.totalAmount) * 100, 100)}%`
                : '0%',
            }}
          />
        </div>
        <p className="text-xs text-slate-400 mt-2">
          {stats.totalAmount
            ? `${Math.round((stats.paidAmount / stats.totalAmount) * 100)}% collected`
            : 'No bills yet'}
        </p>
      </div>
    </div>
  );
}
