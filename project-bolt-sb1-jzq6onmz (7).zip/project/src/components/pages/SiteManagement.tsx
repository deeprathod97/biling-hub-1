import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Site } from '../../lib/types';
import { Plus, Pencil, Trash2, X, MapPin, User, Hash } from 'lucide-react';

export default function SiteManagement() {
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Site | null>(null);
  const [form, setForm] = useState({ name: '', site_number: '', location: '', incharge: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSites();
  }, []);

  async function loadSites() {
    try {
      const { data } = await supabase.from('sites').select('*').order('created_at', { ascending: false });
      setSites(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  function openCreate() {
    setEditing(null);
    setForm({ name: '', site_number: '', location: '', incharge: '' });
    setShowForm(true);
  }

  function openEdit(site: Site) {
    setEditing(site);
    setForm({ name: site.name, site_number: site.site_number, location: site.location, incharge: site.incharge });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await supabase.from('sites').update(form).eq('id', editing.id);
      } else {
        await supabase.from('sites').insert(form);
      }
      setShowForm(false);
      loadSites();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this site?')) return;
    await supabase.from('sites').delete().eq('id', id);
    loadSites();
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Sites</h1>
          <p className="text-sm text-slate-400 mt-1">Manage construction sites</p>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Site
        </button>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                {editing ? 'Edit Site' : 'Add Site'}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Site Name</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-field" required placeholder="e.g. Dholera Smart City Phase 1" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Site Number</label>
                <input value={form.site_number} onChange={(e) => setForm({ ...form, site_number: e.target.value })} className="input-field" required placeholder="e.g. S-001" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Location</label>
                <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="input-field" required placeholder="e.g. Dholera" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Site In-charge</label>
                <input value={form.incharge} onChange={(e) => setForm({ ...form, incharge: e.target.value })} className="input-field" required placeholder="e.g. Ramesh Kumar" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? 'Saving...' : editing ? 'Update' : 'Add Site'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Table */}
      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading...</div>
      ) : sites.length === 0 ? (
        <div className="card p-12 text-center">
          <MapPin className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No sites added yet</p>
          <button onClick={openCreate} className="btn-primary mt-4 btn-sm">Add your first site</button>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-header">Site Name</th>
                  <th className="table-header">Number</th>
                  <th className="table-header">Location</th>
                  <th className="table-header">In-charge</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sites.map((site, i) => (
                  <tr key={site.id} className="animate-slide-up" style={{ animationDelay: `${i * 40}ms` }}>
                    <td className="table-cell">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                          <MapPin className="w-4 h-4 text-slate-500" />
                        </div>
                        <span className="font-medium text-slate-900">{site.name}</span>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className="inline-flex items-center gap-1 text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md">
                        <Hash className="w-3 h-3" />{site.site_number}
                      </span>
                    </td>
                    <td className="table-cell">{site.location}</td>
                    <td className="table-cell">
                      <span className="inline-flex items-center gap-1">
                        <User className="w-3 h-3 text-slate-400" />{site.incharge}
                      </span>
                    </td>
                    <td className="table-cell text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => openEdit(site)} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                          <Pencil className="w-4 h-4 text-slate-400" />
                        </button>
                        <button onClick={() => handleDelete(site.id)} className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
