import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { AsphaltBill, Site, Truck, BituminousGrade } from '../../lib/types';
import { FileBarChart, Printer, Calendar, Filter, X } from 'lucide-react';

export default function AsphaltDailySalesReport() {
  const [bills, setBills] = useState<AsphaltBill[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    site_id: '',
    truck_id: '',
    grade_id: '',
  });

  useEffect(() => {
    loadMasterData();
  }, []);

  useEffect(() => {
    loadReport();
  }, [filters]);

  async function loadMasterData() {
    try {
      const [sitesRes, trucksRes, gradesRes] = await Promise.all([
        supabase.from('sites').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('bituminous_grades').select('*').order('grade'),
      ]);
      setSites(sitesRes.data || []);
      setTrucks(trucksRes.data || []);
      setGrades(gradesRes.data || []);
    } finally {
      setLoading(false);
    }
  }

  async function loadReport() {
    try {
      let query = supabase
        .from('asphalt_bills')
        .select('*, site:sites(*), truck:trucks(*), grade:bituminous_grades(*)')
        .gte('date', filters.startDate)
        .lte('date', filters.endDate)
        .order('date', { ascending: true });

      if (filters.site_id) query = query.eq('site_id', filters.site_id);
      if (filters.truck_id) query = query.eq('truck_id', filters.truck_id);
      if (filters.grade_id) query = query.eq('grade_id', filters.grade_id);

      const { data } = await query;
      setBills((data as any) || []);
    } catch (err) {
      console.error(err);
    }
  }

  function clearFilters() {
    setFilters({
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      site_id: '',
      truck_id: '',
      grade_id: '',
    });
  }

  const totalTone = bills.reduce((sum, b) => sum + Number(b.quantity_tone), 0);
  const totalAmount = bills.reduce((sum, b) => sum + Number(b.amount), 0);

  function printReport() {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const activeFilters: string[] = [];
    if (filters.site_id) activeFilters.push(`Site: ${sites.find(s => s.id === filters.site_id)?.name}`);
    if (filters.truck_id) activeFilters.push(`Truck: ${trucks.find(t => t.id === filters.truck_id)?.truck_number}`);
    if (filters.grade_id) activeFilters.push(`Grade: ${grades.find(g => g.id === filters.grade_id)?.grade}`);

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Asphalt Daily Sales Report</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; padding: 15mm; font-size: 10pt; color: #000; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 15px; }
          .header h1 { font-size: 18pt; margin-bottom: 3px; }
          .header h2 { font-size: 12pt; font-weight: normal; color: #555; margin-bottom: 5px; }
          .header p { font-size: 9pt; color: #666; }
          .report-info { display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 9pt; }
          .filters { background: #f5f5f5; padding: 8px; border-radius: 4px; margin-bottom: 15px; font-size: 9pt; }
          .filters span { margin-right: 15px; }
          .summary { display: flex; justify-content: space-between; margin-bottom: 20px; border: 1px solid #000; padding: 10px; }
          .summary-item { text-align: center; flex: 1; }
          .summary-item .label { font-size: 8pt; color: #555; }
          .summary-item .value { font-size: 14pt; font-weight: bold; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 9pt; }
          th, td { border: 1px solid #000; padding: 6px 8px; text-align: left; }
          th { background: #f0f0f0; font-weight: bold; }
          .text-right { text-align: right; }
          .text-center { text-align: center; }
          .total-row { background: #f0f0f0; font-weight: bold; }
          .footer { margin-top: 20px; text-align: center; font-size: 8pt; color: #888; border-top: 1px solid #ccc; padding-top: 10px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>D CONCRETE PVT. LTD.</h1>
          <h2>Asphalt / Bituminous Mix - Daily Sales Report</h2>
          <p>Dholera, Gujarat | GST: 24BM3LOIBL2W1Z</p>
        </div>

        <div class="report-info">
          <div><strong>Report Period:</strong> ${filters.startDate} to ${filters.endDate}</div>
          <div><strong>Generated:</strong> ${new Date().toLocaleString('en-IN')}</div>
        </div>

        ${activeFilters.length > 0 ? `
        <div class="filters">
          <strong>Filters:</strong> ${activeFilters.map(f => `<span>${f}</span>`).join('')}
        </div>
        ` : ''}

        <div class="summary">
          <div class="summary-item">
            <div class="label">TOTAL BILLS</div>
            <div class="value">${bills.length}</div>
          </div>
          <div class="summary-item">
            <div class="label">TOTAL TONE</div>
            <div class="value">${totalTone.toLocaleString('en-IN')}</div>
          </div>
          <div class="summary-item">
            <div class="label">TOTAL AMOUNT</div>
            <div class="value">&#8377;${totalAmount.toLocaleString('en-IN')}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th class="text-center" style="width:30px">#</th>
              <th class="text-center">Bill #</th>
              <th>Date</th>
              <th>Site</th>
              <th>Location</th>
              <th>Grade</th>
              <th>Truck</th>
              <th class="text-right">Qty (T)</th>
              <th class="text-right">Amount (&#8377;)</th>
            </tr>
          </thead>
          <tbody>
            ${bills.map((bill, idx) => `
              <tr>
                <td class="text-center">${idx + 1}</td>
                <td class="text-center">${bill.bill_number}</td>
                <td>${bill.date}</td>
                <td>${(bill as any).site?.name || '-'}</td>
                <td>${(bill as any).site?.location || '-'}</td>
                <td>${(bill as any).grade?.grade || '-'}</td>
                <td>${(bill as any).truck?.truck_number || '-'}</td>
                <td class="text-right">${Number(bill.quantity_tone).toLocaleString('en-IN')}</td>
                <td class="text-right">${Number(bill.amount).toLocaleString('en-IN')}</td>
              </tr>
            `).join('')}
            <tr class="total-row">
              <td colspan="7" class="text-right">TOTAL</td>
              <td class="text-right">${totalTone.toLocaleString('en-IN')}</td>
              <td class="text-right">&#8377;${totalAmount.toLocaleString('en-IN')}</td>
            </tr>
          </tbody>
        </table>

        <div class="footer">
          <p>This is a computer-generated report. | D CONCRETE PVT. LTD. | Dholera, Gujarat</p>
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
            <FileBarChart className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Asphalt Daily Sales Report</h1>
            <p className="text-sm text-slate-400">Bituminous mix sales analytics</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowFilters(!showFilters)} className="btn-secondary flex items-center gap-2">
            <Filter className="w-4 h-4" /> Filters
          </button>
          <button onClick={printReport} className="btn-primary flex items-center gap-2">
            <Printer className="w-4 h-4" /> Print Report
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className={`card p-4 mb-6 ${showFilters ? 'animate-slide-up' : 'hidden'}`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4" /> Filter Options
          </h3>
          <button onClick={clearFilters} className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1">
            <X className="w-3 h-3" /> Clear All
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Start Date</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
              className="input-field"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">End Date</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
              className="input-field"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Site</label>
            <select
              value={filters.site_id}
              onChange={(e) => setFilters({ ...filters, site_id: e.target.value })}
              className="input-field"
            >
              <option value="">All Sites</option>
              {sites.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Bituminous Grade</label>
            <select
              value={filters.grade_id}
              onChange={(e) => setFilters({ ...filters, grade_id: e.target.value })}
              className="input-field"
            >
              <option value="">All Grades</option>
              {grades.map((g) => (
                <option key={g.id} value={g.id}>{g.grade}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Truck</label>
            <select
              value={filters.truck_id}
              onChange={(e) => setFilters({ ...filters, truck_id: e.target.value })}
              className="input-field"
            >
              <option value="">All Trucks</option>
              {trucks.map((t) => (
                <option key={t.id} value={t.id}>{t.truck_number} - {t.code}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
        <div className="card p-4 text-center">
          <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Total Bills</p>
          <p className="text-2xl font-bold text-slate-900">{bills.length}</p>
        </div>
        <div className="card p-4 text-center">
          <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Total Tone</p>
          <p className="text-2xl font-bold text-slate-900">{totalTone.toLocaleString('en-IN')}</p>
        </div>
        <div className="card p-4 text-center col-span-2 sm:col-span-1 bg-gradient-to-br from-amber-50 to-orange-100 border-orange-200">
          <p className="text-xs text-orange-600 uppercase tracking-wider mb-1">Total Amount</p>
          <p className="text-2xl font-bold text-orange-700">₹{totalAmount.toLocaleString('en-IN')}</p>
        </div>
      </div>

      {/* Report Period */}
      <div className="bg-slate-50 rounded-lg px-4 py-2 mb-4 flex items-center gap-4 text-sm">
        <span className="text-slate-500">Report Period:</span>
        <span className="font-medium text-slate-900">{filters.startDate}</span>
        <span className="text-slate-300">to</span>
        <span className="font-medium text-slate-900">{filters.endDate}</span>
      </div>

      {/* Report Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="table-header w-10 text-center">#</th>
                <th className="table-header">Bill #</th>
                <th className="table-header">Date</th>
                <th className="table-header">Site</th>
                <th className="table-header">Location</th>
                <th className="table-header">Grade</th>
                <th className="table-header">Truck</th>
                <th className="table-header text-right">Qty (T)</th>
                <th className="table-header text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {bills.map((bill, idx) => (
                <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                  <td className="table-cell text-center text-slate-400">{idx + 1}</td>
                  <td className="table-cell">
                    <span className="font-mono font-semibold text-slate-900">{bill.bill_number}</span>
                  </td>
                  <td className="table-cell text-slate-600">{bill.date}</td>
                  <td className="table-cell">
                    <div className="font-medium text-slate-900">{bill.site?.name || '-'}</div>
                    <div className="text-xs text-slate-400">{bill.site?.site_number || ''}</div>
                  </td>
                  <td className="table-cell text-slate-600">{bill.site?.location || '-'}</td>
                  <td className="table-cell">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">
                      {bill.grade?.grade || '-'}
                    </span>
                  </td>
                  <td className="table-cell">
                    <div className="text-slate-900">{bill.truck?.truck_number || '-'}</div>
                    <div className="text-xs text-slate-400">{bill.truck?.code || ''}</div>
                  </td>
                  <td className="table-cell text-right font-medium text-slate-900">{Number(bill.quantity_tone).toLocaleString('en-IN')}</td>
                  <td className="table-cell text-right font-bold text-orange-600">₹{Number(bill.amount).toLocaleString('en-IN')}</td>
                </tr>
              ))}
              {bills.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center py-12 text-slate-400">
                    No sales data found for the selected period
                  </td>
                </tr>
              )}
              {bills.length > 0 && (
                <tr className="bg-slate-100 font-bold">
                  <td colSpan={7} className="table-cell text-right text-slate-700">TOTAL</td>
                  <td className="table-cell text-right text-slate-900">{totalTone.toLocaleString('en-IN')}</td>
                  <td className="table-cell text-right text-orange-700">₹{totalAmount.toLocaleString('en-IN')}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
