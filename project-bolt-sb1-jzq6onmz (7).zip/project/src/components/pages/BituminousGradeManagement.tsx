import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { BituminousGrade } from '../../lib/types';
import { Layers, Plus, Pencil, Trash2, X } from 'lucide-react';

export default function BituminousGradeManagement() {
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingGrade, setEditingGrade] = useState<BituminousGrade | null>(null);
  const [form, setForm] = useState({ grade: '', price_per_tone: 0, carting_bhadu_per_tone: 0 });

  useEffect(() => {
    loadGrades();
  }, []);

  async function loadGrades() {
    try {
      const { data } = await supabase.from('bituminous_grades').select('*').order('grade');
      setGrades(data || []);
    } finally {
      setLoading(false);
    }
  }

  function openAddModal() {
    setEditingGrade(null);
    setForm({ grade: '', price_per_tone: 0, carting_bhadu_per_tone: 0 });
    setShowModal(true);
  }

  function openEditModal(grade: BituminousGrade) {
    setEditingGrade(grade);
    setForm({ grade: grade.grade, price_per_tone: Number(grade.price_per_tone), carting_bhadu_per_tone: Number(grade.carting_bhadu_per_tone) });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (editingGrade) {
        await supabase.from('bituminous_grades').update(form).eq('id', editingGrade.id);
      } else {
        await supabase.from('bituminous_grades').insert(form);
      }
      setShowModal(false);
      loadGrades();
    } catch (err) {
      console.error(err);
      alert('Error saving grade');
    }
  }

  async function deleteGrade(id: string) {
    if (!confirm('Delete this grade?')) return;
    try {
      await supabase.from('bituminous_grades').delete().eq('id', id);
      loadGrades();
    } catch (err) {
      console.error(err);
      alert('Error deleting grade');
    }
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Bituminous Grades</h1>
            <p className="text-sm text-slate-400">Manage bituminous mix grades & pricing</p>
          </div>
        </div>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Grade
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {grades.map((grade) => (
          <div key={grade.id} className="card p-5 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className="w-12 h-12 rounded-xl bg-slate-900 flex items-center justify-center">
                <span className="text-white font-bold text-xs">{grade.grade}</span>
              </div>
              <div className="flex gap-1">
                <button onClick={() => openEditModal(grade)} className="text-slate-400 hover:text-slate-600 p-1">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => deleteGrade(grade.id)} className="text-slate-400 hover:text-red-500 p-1">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <h3 className="font-bold text-slate-900 mb-2">{grade.grade}</h3>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Price/Tone</span>
                <span className="font-medium text-slate-900">₹{Number(grade.price_per_tone).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Carting Bhadu/Tone</span>
                <span className="font-medium text-slate-900">₹{Number(grade.carting_bhadu_per_tone).toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        ))}
        {grades.length === 0 && (
          <div className="col-span-full text-center py-12 text-slate-400">No grades added yet</div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">{editingGrade ? 'Edit Grade' : 'Add Grade'}</h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Grade Name</label>
                <input type="text" value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="input-field" required placeholder="VG-30" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Price per Tone (₹)</label>
                <input type="number" value={form.price_per_tone || ''} onChange={(e) => setForm({ ...form, price_per_tone: Number(e.target.value) })} className="input-field" required min="0" placeholder="0" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Carting Bhadu per Tone (₹)</label>
                <input type="number" value={form.carting_bhadu_per_tone || ''} onChange={(e) => setForm({ ...form, carting_bhadu_per_tone: Number(e.target.value) })} className="input-field" min="0" placeholder="0" />
              </div>
              <button type="submit" className="btn-primary w-full">{editingGrade ? 'Update' : 'Add'} Grade</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
