import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Site, TransitMixer, ConcreteGrade } from '../../lib/types';
import { Save, Layers } from 'lucide-react';

export default function CreateBill({ onCreated }: { onCreated?: () => void }) {
  const [sites, setSites] = useState<Site[]>([]);
  const [tms, setTms] = useState<TransitMixer[]>([]);
  const [grades, setGrades] = useState<ConcreteGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');

  const [form, setForm] = useState({
    site_id: '',
    tm_id: '',
    grade_id: '',
    date: new Date().toISOString().split('T')[0],
    carting_bhadu: 0,
    quantity_mqb: 0,
  });

  useEffect(() => {
    loadMasterData();
  }, []);

  async function loadMasterData() {
    try {
      const [sitesRes, tmsRes, gradesRes] = await Promise.all([
        supabase.from('sites').select('*').order('name'),
        supabase.from('transit_mixers').select('*').order('tm_number'),
        supabase.from('concrete_grades').select('*').order('grade'),
      ]);
      setSites(sitesRes.data || []);
      setTms(tmsRes.data || []);
      setGrades(gradesRes.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const selectedGrade = grades.find((g) => g.id === form.grade_id);
  const pricePerMqb = selectedGrade ? Number(selectedGrade.price_per_mqb) : 0;
  const cartingPerMqb = selectedGrade ? Number(selectedGrade.carting_bhadu_per_mqb) : 0;
  const cartingBhaduTotal = form.carting_bhadu * cartingPerMqb;
  const concreteAmount = form.quantity_mqb * pricePerMqb;
  const totalMqb = form.quantity_mqb + form.carting_bhadu;
  const amount = concreteAmount + cartingBhaduTotal;

  function handleGradeChange(gradeId: string) {
    setForm({ ...form, grade_id: gradeId, carting_bhadu: 0, quantity_mqb: 0 });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSuccess('');
    try {
      const { data: billNumData, error: billNumErr } = await supabase.rpc('get_next_bill_number');
      if (billNumErr) throw billNumErr;

      const bill = {
        bill_number: billNumData,
        date: form.date,
        site_id: form.site_id,
        tm_id: form.tm_id,
        grade_id: form.grade_id,
        carting_bhadu: Number(form.carting_bhadu),
        quantity_mqb: Number(form.quantity_mqb),
        total_mqb: totalMqb,
        amount,
        payment_status: 'unpaid' as const,
      };

      const { error } = await supabase.from('rmc_bills').insert(bill);
      if (error) throw error;

      setSuccess(`Bill #${billNumData} created successfully! Amount: ₹${amount.toLocaleString('en-IN')}`);
      setForm({
        site_id: form.site_id,
        tm_id: '',
        grade_id: form.grade_id,
        date: form.date,
        carting_bhadu: 0,
        quantity_mqb: 0,
      });
      onCreated?.();
    } catch (err) {
      console.error(err);
      alert('Error creating bill. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="text-center py-12 text-slate-400">Loading master data...</div>;
  }

  return (
    <div className="animate-fade-in max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Create RMC Bill</h1>
        <p className="text-sm text-slate-400 mt-1">Generate a new ready-mix concrete bill</p>
      </div>

      {success && (
        <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-sm font-medium animate-slide-up">
          {success}
        </div>
      )}

      <form onSubmit={handleSubmit} className="card p-6 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Date</label>
            <input
              type="date"
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
              className="input-field"
              required
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Site</label>
            <select
              value={form.site_id}
              onChange={(e) => setForm({ ...form, site_id: e.target.value })}
              className="input-field"
              required
            >
              <option value="">Select Site</option>
              {sites.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.site_number})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Transit Mixer</label>
            <select
              value={form.tm_id}
              onChange={(e) => setForm({ ...form, tm_id: e.target.value })}
              className="input-field"
              required
            >
              <option value="">Select TM</option>
              {tms.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.tm_number} - {t.code}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Concrete Grade</label>
            <select
              value={form.grade_id}
              onChange={(e) => handleGradeChange(e.target.value)}
              className="input-field"
              required
            >
              <option value="">Select Grade</option>
              {grades.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.grade} - ₹{Number(g.price_per_mqb).toLocaleString('en-IN')}/MQB
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Auto-filled pricing from grade */}
        {selectedGrade && (
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 animate-slide-up">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-slate-400" />
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {selectedGrade.grade} - Auto Pricing
              </h4>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Price / MQB</p>
                <p className="text-lg font-bold text-slate-900">₹{pricePerMqb.toLocaleString('en-IN')}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Carting Bhadu / MQB</p>
                <p className="text-lg font-bold text-slate-900">₹{cartingPerMqb.toLocaleString('en-IN')}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Quantity (MQB)</label>
            <input
              type="number"
              value={form.quantity_mqb || ''}
              onChange={(e) => setForm({ ...form, quantity_mqb: Number(e.target.value) })}
              className="input-field"
              required
              min="0"
              step="0.01"
              placeholder="0"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Carting Bhadu (MQB)</label>
            <input
              type="number"
              value={form.carting_bhadu || ''}
              onChange={(e) => setForm({ ...form, carting_bhadu: Number(e.target.value) })}
              className="input-field"
              min="0"
              step="0.01"
              placeholder="0"
            />
          </div>
        </div>

        {/* Calculation summary */}
        <div className="bg-slate-50 rounded-xl p-5 space-y-3 border border-slate-100">
          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Calculation</h4>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Price per MQB</span>
              <span className="font-medium text-slate-900">₹{pricePerMqb.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Concrete ({form.quantity_mqb} MQB x ₹{pricePerMqb.toLocaleString('en-IN')})</span>
              <span className="font-medium text-slate-900">₹{concreteAmount.toLocaleString('en-IN')}</span>
            </div>
            {form.carting_bhadu > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Carting Bhadu ({form.carting_bhadu} MQB x ₹{cartingPerMqb.toLocaleString('en-IN')})</span>
                <span className="font-medium text-slate-900">₹{cartingBhaduTotal.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Total MQB</span>
              <span className="font-medium text-slate-900">{totalMqb}</span>
            </div>
            <div className="border-t border-slate-200 pt-2 flex justify-between">
              <span className="font-semibold text-slate-900">Total Amount</span>
              <span className="text-xl font-bold text-emerald-600">₹{amount.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="btn-primary w-full flex items-center justify-center gap-2 py-3"
        >
          {saving ? (
            'Creating Bill...'
          ) : (
            <>
              <Save className="w-4 h-4" />
              Create Bill
            </>
          )}
        </button>
      </form>
    </div>
  );
}
