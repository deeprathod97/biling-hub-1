import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { RmcBill, Site, TransitMixer, ConcreteGrade } from '../../lib/types';
import { X, Save } from 'lucide-react';

interface EditBillProps {
  bill: RmcBill;
  onClose: () => void;
  onSaved: () => void;
}

export default function EditBill({ bill, onClose, onSaved }: EditBillProps) {
  const [sites, setSites] = useState<Site[]>([]);
  const [tms, setTms] = useState<TransitMixer[]>([]);
  const [grades, setGrades] = useState<ConcreteGrade[]>([]);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    date: bill.date,
    site_id: bill.site_id,
    tm_id: bill.tm_id,
    grade_id: bill.grade_id,
    quantity_mqb: Number(bill.quantity_mqb),
    carting_bhadu: Number(bill.carting_bhadu),
  });

  useEffect(() => {
    supabase.from('sites').select('*').order('name').then(({ data }) => setSites(data || []));
    supabase.from('transit_mixers').select('*').order('tm_number').then(({ data }) => setTms(data || []));
    supabase.from('concrete_grades').select('*').order('grade').then(({ data }) => setGrades(data || []));
  }, []);

  const selectedGrade = grades.find((g) => g.id === form.grade_id);
  const pricePerMqb = selectedGrade ? Number(selectedGrade.price_per_mqb) : 0;
  const cartingPerMqb = selectedGrade ? Number(selectedGrade.carting_bhadu_per_mqb) : 0;
  const cartingBhaduTotal = form.carting_bhadu * cartingPerMqb;
  const totalMqb = form.quantity_mqb + form.carting_bhadu;
  const amount = form.quantity_mqb * pricePerMqb + cartingBhaduTotal;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await supabase.from('rmc_bills').update({
        date: form.date,
        site_id: form.site_id,
        tm_id: form.tm_id,
        grade_id: form.grade_id,
        quantity_mqb: form.quantity_mqb,
        carting_bhadu: form.carting_bhadu,
        total_mqb: totalMqb,
        amount,
      }).eq('id', bill.id);
      onSaved();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg animate-scale-in max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Edit Bill</h3>
            <p className="text-xs text-slate-400">Bill #{bill.bill_number}</p>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5 text-slate-400" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Date</label>
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="input-field" required />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Site</label>
              <select value={form.site_id} onChange={(e) => setForm({ ...form, site_id: e.target.value })} className="input-field" required>
                <option value="">Select</option>
                {sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">TM</label>
              <select value={form.tm_id} onChange={(e) => setForm({ ...form, tm_id: e.target.value })} className="input-field" required>
                <option value="">Select</option>
                {tms.map((t) => <option key={t.id} value={t.id}>{t.tm_number}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Grade</label>
              <select value={form.grade_id} onChange={(e) => setForm({ ...form, grade_id: e.target.value })} className="input-field" required>
                <option value="">Select</option>
                {grades.map((g) => <option key={g.id} value={g.id}>{g.grade}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Quantity (MQB)</label>
              <input type="number" value={form.quantity_mqb || ''} onChange={(e) => setForm({ ...form, quantity_mqb: Number(e.target.value) })} className="input-field" required min="0" step="0.01" />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">Carting Bhadu</label>
              <input type="number" value={form.carting_bhadu || ''} onChange={(e) => setForm({ ...form, carting_bhadu: Number(e.target.value) })} className="input-field" min="0" step="0.01" />
            </div>
          </div>
          <div className="bg-slate-50 rounded-xl p-4 space-y-2 border border-slate-100">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Total MQB</span>
              <span className="font-medium">{totalMqb}</span>
            </div>
            <div className="flex justify-between text-sm border-t border-slate-200 pt-2">
              <span className="font-semibold text-slate-900">Total Amount</span>
              <span className="text-lg font-bold text-emerald-600">₹{amount.toLocaleString('en-IN')}</span>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
              <Save className="w-4 h-4" />{saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
