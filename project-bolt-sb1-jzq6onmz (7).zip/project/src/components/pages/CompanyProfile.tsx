import { Building, Users, MapPin, Hash, Briefcase, Globe } from 'lucide-react';

const COMPANY_LOGO = 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj5m4IoG1JS37j-ZWdejm2yBrFZVrv_MgO8tulIsz4A7HEK47tYw6IWDU8vPenDrnDdthVURhHgYqY0q1osLe121lCYdN67MX_t0nFMn5vCTCgHLK02XIAx84J4N6fEsWFw4tes784tJvnBddDuW_gQ7VqUTi_6ZVh94cFkD1QcU6xfwN7Rf-IWz_0SZf7a/s320/ChatGPT_Image_Jun_5__2026__11_40_06_AM-removebg-preview%20(1).png';

export default function CompanyProfile() {
  return (
    <div className="animate-fade-in max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Company Profile</h1>
        <p className="text-sm text-slate-400 mt-1">D CONCRETE PVT. LTD. details</p>
      </div>

      <div className="card overflow-hidden">
        {/* Header with logo */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-8 text-center">
          <div className="bg-white rounded-2xl w-24 h-24 mx-auto flex items-center justify-center shadow-lg shadow-black/20 p-2">
            <img src={COMPANY_LOGO} alt="D Concrete" className="w-20 h-20 object-contain" />
          </div>
          <h2 className="text-xl font-bold text-white mt-4 font-['Playfair_Display']">D CONCRETE PVT. LTD.</h2>
          <p className="text-slate-300 text-xs mt-1 tracking-widest uppercase">Ready Mix Concrete Solutions</p>
        </div>

        {/* Details */}
        <div className="p-6 space-y-0">
          <ProfileRow icon={Building} label="Company Name" value="D CONCRETE PVT. LTD." />
          <ProfileRow icon={MapPin} label="Location" value="Dholera, Gujarat" />
          <ProfileRow icon={Hash} label="GST Number" value="24BM3LOIBL2W1Z" />
          <ProfileRow icon={Users} label="Co-Founder" value="Mr. Deep Bhai Rathod" />
          <ProfileRow icon={Users} label="Co-Founder" value="Mr. Vinod Bhai Rathod" />
          <ProfileRow icon={Briefcase} label="CEO" value="Mr. Vinod Bhai Rathod" />
          <ProfileRow icon={Briefcase} label="CTO" value="Mr. Deep Bhai Rathod" />
        </div>
      </div>

      {/* Company description */}
      <div className="card mt-5 p-6 animate-slide-up" style={{ animationDelay: '200ms' }}>
        <h3 className="text-sm font-bold text-slate-900 mb-2">About</h3>
        <p className="text-sm text-slate-500 leading-relaxed">
          D Concrete Pvt. Ltd. is a leading ready-mix concrete supplier based in Dholera, Gujarat.
          We provide high-quality concrete solutions for construction projects of all sizes,
          with a focus on timely delivery and consistent quality standards.
        </p>
      </div>
    </div>
  );
}

function ProfileRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-center gap-4 py-3.5 border-b border-slate-50 last:border-b-0">
      <div className="w-9 h-9 bg-slate-50 rounded-lg flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-slate-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">{label}</p>
        <p className="text-sm font-medium text-slate-900 truncate">{value}</p>
      </div>
    </div>
  );
}
