import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { RmcBill, Payment, Site, TransitMixer, ConcreteGrade } from '../../lib/types';
import { Printer, Pencil, Trash2, IndianRupee, X, Eye, FileText, FileCheck } from 'lucide-react';

interface BillListProps {
  onPrintBill?: (bill: RmcBill) => void;
  onPrintSlip?: (bill: RmcBill) => void;
  onEditBill?: (bill: RmcBill) => void;
}

export default function BillList({ onPrintBill, onPrintSlip, onEditBill }: BillListProps) {
  const [bills, setBills] = useState<RmcBill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentBill, setPaymentBill] = useState<RmcBill | null>(null);
  const [paymentAmt, setPaymentAmt] = useState(0);
  const [paymentNotes, setPaymentNotes] = useState('');
  const [payments, setPayments] = useState<Payment[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadBills();
  }, []);

  async function loadBills() {
    try {
      const { data } = await supabase
        .from('rmc_bills')
        .select('*, site:sites(*), tm:transit_mixers(*), grade:concrete_grades(*)')
        .order('created_at', { ascending: false });
      setBills((data as any) || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  async function openPayments(bill: RmcBill) {
    setPaymentBill(bill);
    setPaymentAmt(0);
    setPaymentNotes('');
    const { data } = await supabase.from('payments').select('*').eq('bill_id', bill.id).order('payment_date', { ascending: false });
    setPayments(data || []);
    setShowPayment(true);
  }

  async function handlePayment(e: React.FormEvent) {
    e.preventDefault();
    if (!paymentBill) return;
    setSaving(true);
    try {
      await supabase.from('payments').insert({
        bill_id: paymentBill.id,
        amount: paymentAmt,
        payment_date: new Date().toISOString().split('T')[0],
        notes: paymentNotes || null,
      });

      const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0) + paymentAmt;
      const billAmount = Number(paymentBill.amount);
      const status = totalPaid >= billAmount ? 'paid' : totalPaid > 0 ? 'partial' : 'unpaid';

      await supabase.from('rmc_bills').update({ payment_status: status }).eq('id', paymentBill.id);

      setShowPayment(false);
      loadBills();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function deletePayment(paymentId: string, billId: string) {
    if (!confirm('Delete this payment?')) return;
    await supabase.from('payments').delete().eq('id', paymentId);
    openPayments(bills.find(b => b.id === billId)!);
    loadBills();
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this bill? This cannot be undone.')) return;
    await supabase.from('payments').delete().eq('bill_id', id);
    await supabase.from('rmc_bills').delete().eq('id', id);
    loadBills();
  }

  const statusBadge = (status: string) => {
    if (status === 'paid') return 'bg-emerald-50 text-emerald-700 border border-emerald-200';
    if (status === 'partial') return 'bg-amber-50 text-amber-700 border border-amber-200';
    return 'bg-red-50 text-red-700 border border-red-200';
  };

  async function printBillA4(bill: RmcBill) {
    const { data: payData } = await supabase.from('payments').select('*').eq('bill_id', bill.id).order('payment_date');
    const paymentsList = payData || [];
    const totalPaid = paymentsList.reduce((s, p) => s + Number(p.amount), 0);
    const balance = Number(bill.amount) - totalPaid;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>RMC Bill #${bill.bill_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; padding: 15mm; font-size: 11pt; color: #000; }
          .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .company { display: flex; align-items: center; gap: 15px; }
          .company img { width: 60px; height: 60px; object-fit: contain; }
          .company h1 { font-size: 18pt; margin-bottom: 3px; }
          .company p { font-size: 9pt; color: #555; }
          .invoice-title { text-align: right; }
          .invoice-title h2 { font-size: 14pt; margin-bottom: 5px; }
          .invoice-box { border: 1px solid #000; padding: 8px 12px; font-size: 10pt; }
          .bill-to { border: 1px solid #000; margin-bottom: 20px; }
          .bill-to-header { background: #f0f0f0; padding: 5px 10px; font-weight: bold; font-size: 10pt; border-bottom: 1px solid #000; }
          .bill-to-content { padding: 10px; font-size: 10pt; line-height: 1.6; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 10pt; }
          th, td { border: 1px solid #000; padding: 8px 10px; text-align: left; }
          th { background: #f0f0f0; font-weight: bold; }
          .text-right { text-align: right; }
          .total-row { background: #f0f0f0; font-weight: bold; }
          .summary { display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 10pt; }
          .payment-history { border: 1px solid #000; margin-bottom: 20px; }
          .payment-header { background: #f0f0f0; padding: 5px 10px; font-weight: bold; font-size: 10pt; border-bottom: 1px solid #000; }
          .payment-content { padding: 10px; font-size: 10pt; }
          .payment-row { display: flex; justify-content: space-between; padding: 3px 0; }
          .balance-row { border-top: 1px solid #000; padding-top: 5px; margin-top: 5px; font-weight: bold; }
          .amount-words { margin-bottom: 20px; font-size: 10pt; }
          .signatures { display: flex; justify-content: space-between; margin-top: 60px; }
          .signature-box { width: 180px; text-align: center; }
          .signature-line { border-top: 1px solid #000; padding-top: 5px; font-size: 9pt; }
          .footer { margin-top: 40px; text-align: center; font-size: 8pt; color: #888; border-top: 1px solid #ccc; padding-top: 10px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company">
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj5m4IoG1JS37j-ZWdejm2yBrFZVrv_MgO8tulIsz4A7HEK47tYw6IWDU8vPenDrnDdthVURhHgYqY0q1osLe121lCYdN67MX_t0nFMn5vCTCgHLK02XIAx84J4N6fEsWFw4tes784tJvnBddDuW_gQ7VqUTi_6ZVh94cFkD1QcU6xfwN7Rf-IWz_0SZf7a/s320/ChatGPT_Image_Jun_5__2026__11_40_06_AM-removebg-preview%20(1).png" alt="Logo" />
            <div>
              <h1>D CONCRETE PVT. LTD.</h1>
              <p>Dholera, Gujarat</p>
              <p>GSTIN: 24BM3LOIBL2W1Z</p>
            </div>
          </div>
          <div class="invoice-title">
            <h2>TAX INVOICE</h2>
            <div class="invoice-box">
              <p>Bill No: <strong>${bill.bill_number}</strong></p>
              <p>Date: <strong>${bill.date}</strong></p>
            </div>
          </div>
        </div>

        <div class="bill-to">
          <div class="bill-to-header">BILL TO</div>
          <div class="bill-to-content">
            <p><strong>Site:</strong> ${bill.site?.name || '-'}</p>
            <p><strong>Site No:</strong> ${bill.site?.site_number || '-'}</p>
            <p><strong>Location:</strong> ${bill.site?.location || '-'}</p>
            <p><strong>In-charge:</strong> ${bill.site?.incharge || '-'}</p>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 30px;">#</th>
              <th>Description</th>
              <th class="text-right">MQB</th>
              <th class="text-right">Rate (₹)</th>
              <th class="text-right">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>
                Ready Mix Concrete - ${bill.grade?.grade || '-'} Grade
                <br/><span style="font-size: 9pt; color: #555;">TM: ${bill.tm?.tm_number || '-'} (${bill.tm?.code || '-'})</span>
              </td>
              <td class="text-right">${Number(bill.quantity_mqb)}</td>
              <td class="text-right">${Number(bill.grade?.price_per_mqb || 0).toLocaleString('en-IN')}</td>
              <td class="text-right">${(Number(bill.quantity_mqb) * Number(bill.grade?.price_per_mqb || 0)).toLocaleString('en-IN')}</td>
            </tr>
            ${Number(bill.carting_bhadu) > 0 ? `
            <tr>
              <td>2</td>
              <td>Carting Bhadu</td>
              <td class="text-right">${Number(bill.carting_bhadu)}</td>
              <td class="text-right">${Number(bill.grade?.carting_bhadu_per_mqb || 0).toLocaleString('en-IN')}</td>
              <td class="text-right">${(Number(bill.carting_bhadu) * Number(bill.grade?.carting_bhadu_per_mqb || 0)).toLocaleString('en-IN')}</td>
            </tr>
            ` : ''}
          </tbody>
          <tfoot>
            <tr class="total-row">
              <td colspan="4" class="text-right">Total Amount</td>
              <td class="text-right">₹${Number(bill.amount).toLocaleString('en-IN')}</td>
            </tr>
          </tfoot>
        </table>

        <div class="summary">
          <span>Total MQB: <strong>${Number(bill.total_mqb)}</strong></span>
        </div>

        ${paymentsList.length > 0 ? `
        <div class="payment-history">
          <div class="payment-header">PAYMENT HISTORY</div>
          <div class="payment-content">
            ${paymentsList.map((p: any) => `
              <div class="payment-row">
                <span>${p.payment_date}${p.notes ? ` (${p.notes})` : ''}</span>
                <span>₹${Number(p.amount).toLocaleString('en-IN')}</span>
              </div>
            `).join('')}
            <div class="payment-row balance-row">
              <span>Balance Due</span>
              <span>₹${balance.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>
        ` : ''}

        <div class="amount-words">
          <p style="color: #555; font-size: 9pt;">Amount in words:</p>
          <p><strong>Rupees ${Number(bill.amount).toLocaleString('en-IN')} Only</strong></p>
        </div>

        <div class="signatures">
          <div class="signature-box">
            <div class="signature-line">Authorized Signatory</div>
          </div>
          <div class="signature-box">
            <div class="signature-line">For D Concrete Pvt. Ltd.</div>
          </div>
        </div>

        <div class="footer">
          <p>This is a computer-generated invoice. | D CONCRETE PVT. LTD. | Dholera, Gujarat | GST: 24BM3LOIBL2W1Z</p>
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  }

  async function printSlip(bill: RmcBill) {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Slip #${bill.bill_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Courier New', monospace; padding: 10mm; font-size: 10pt; }
          .header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
          .header h1 { font-size: 14pt; }
          .header p { font-size: 8pt; }
          .content { line-height: 1.8; }
          .row { display: flex; justify-content: space-between; }
          .total { border-top: 1px dashed #000; margin-top: 10px; padding-top: 10px; font-weight: bold; }
          .footer { border-top: 1px dashed #000; margin-top: 15px; padding-top: 5px; text-align: center; font-size: 8pt; }
          @media print { body { padding: 5mm; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>D CONCRETE PVT. LTD.</h1>
          <p>Dholera, Gujarat | GST: 24BM3LOIBL2W1Z</p>
        </div>
        <div class="content">
          <div class="row"><span>Bill No:</span><span>${bill.bill_number}</span></div>
          <div class="row"><span>Date:</span><span>${bill.date}</span></div>
          <div class="row"><span>Site:</span><span>${bill.site?.name || '-'}</span></div>
          <div class="row"><span>TM:</span><span>${bill.tm?.tm_number || '-'}</span></div>
          <div class="row"><span>Grade:</span><span>${bill.grade?.grade || '-'}</span></div>
          <div class="row"><span>Qty:</span><span>${Number(bill.quantity_mqb)} MQB</span></div>
          <div class="row"><span>Carting:</span><span>${Number(bill.carting_bhadu)} MQB</span></div>
          <div class="row"><span>Total MQB:</span><span>${Number(bill.total_mqb)}</span></div>
        </div>
        <div class="total">
          <div class="row"><span>AMOUNT:</span><span>₹${Number(bill.amount).toLocaleString('en-IN')}</span></div>
        </div>
        <div class="footer">
          D CONCRETE PVT. LTD.
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">All RMC Bills</h1>
        <p className="text-sm text-slate-400 mt-1">Manage and print bills</p>
      </div>

      {/* Payment Modal */}
      {showPayment && paymentBill && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowPayment(false)}>
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg animate-scale-in max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Payments</h3>
                <p className="text-xs text-slate-400">Bill #{paymentBill.bill_number}</p>
              </div>
              <button onClick={() => setShowPayment(false)} className="p-1 hover:bg-slate-100 rounded-lg">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-500">Bill Amount</span>
                  <span className="font-bold text-slate-900">₹{Number(paymentBill.amount).toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Total Paid</span>
                  <span className="font-medium text-emerald-600">
                    ₹{payments.reduce((s, p) => s + Number(p.amount), 0).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between text-sm mt-2 pt-2 border-t border-slate-200">
                  <span className="text-slate-500">Balance</span>
                  <span className="font-bold text-red-600">
                    ₹{(Number(paymentBill.amount) - payments.reduce((s, p) => s + Number(p.amount), 0)).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {payments.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-semibold text-slate-500 uppercase">Payment History</h4>
                  {payments.map((p) => (
                    <div key={p.id} className="flex justify-between items-center text-sm bg-white border border-slate-100 rounded-lg p-3">
                      <div>
                        <p className="font-medium text-slate-900">₹{Number(p.amount).toLocaleString('en-IN')}</p>
                        <p className="text-xs text-slate-400">{p.payment_date} {p.notes && `• ${p.notes}`}</p>
                      </div>
                      <button onClick={() => deletePayment(p.id, paymentBill.id)} className="text-red-400 hover:text-red-600 p-1">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <form onSubmit={handlePayment} className="space-y-3 pt-2 border-t border-slate-100">
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Payment Amount (₹)</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={paymentAmt || ''}
                      onChange={(e) => setPaymentAmt(Number(e.target.value))}
                      className="input-field flex-1"
                      required
                      min="1"
                      step="0.01"
                      placeholder="0"
                    />
                    <button
                      type="button"
                      onClick={() => setPaymentAmt(Number(paymentBill.amount) - payments.reduce((s, p) => s + Number(p.amount), 0))}
                      className="btn-secondary whitespace-nowrap text-xs"
                    >
                      Full Amount
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-500 mb-1 block">Notes (optional)</label>
                  <input value={paymentNotes} onChange={(e) => setPaymentNotes(e.target.value)} className="input-field" placeholder="e.g. Cash, Bank transfer" />
                </div>
                <button type="submit" disabled={saving} className="btn-primary w-full">
                  {saving ? 'Recording...' : 'Record Payment'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {bills.length === 0 ? (
        <div className="card p-12 text-center">
          <FileText className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No bills created yet</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-header">Bill #</th>
                  <th className="table-header">Date</th>
                  <th className="table-header">Site</th>
                  <th className="table-header">TM</th>
                  <th className="table-header">Grade</th>
                  <th className="table-header">Qty (MQB)</th>
                  <th className="table-header">Amount</th>
                  <th className="table-header">Status</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {bills.map((bill, i) => (
                  <tr key={bill.id} className="hover:bg-slate-50 transition-colors animate-slide-up" style={{ animationDelay: `${i * 30}ms` }}>
                    <td className="table-cell">
                      <span className="font-mono font-bold text-slate-900">{bill.bill_number}</span>
                    </td>
                    <td className="table-cell text-slate-600">{bill.date}</td>
                    <td className="table-cell">
                      <div className="text-sm font-medium text-slate-900">{bill.site?.name || '-'}</div>
                      <div className="text-xs text-slate-400">{bill.site?.location || '-'}</div>
                    </td>
                    <td className="table-cell">
                      <div className="text-sm">{bill.tm?.tm_number || '-'}</div>
                      <div className="text-xs text-slate-400">{bill.tm?.code || '-'}</div>
                    </td>
                    <td className="table-cell">
                      <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium">
                        {bill.grade?.grade || '-'}
                      </span>
                    </td>
                    <td className="table-cell">
                      <div className="font-medium">{Number(bill.quantity_mqb)}</div>
                      {Number(bill.carting_bhadu) > 0 && <div className="text-xs text-slate-400">+{Number(bill.carting_bhadu)} CB</div>}
                    </td>
                    <td className="table-cell">
                      <span className="font-bold text-slate-900">₹{Number(bill.amount).toLocaleString('en-IN')}</span>
                    </td>
                    <td className="table-cell">
                      <span className={`text-xs font-medium px-2 py-1 rounded-md ${statusBadge(bill.payment_status)}`}>
                        {bill.payment_status.charAt(0).toUpperCase() + bill.payment_status.slice(1)}
                      </span>
                    </td>
                    <td className="table-cell text-right">
                      <div className="flex items-center justify-end gap-0.5">
                        <button
                          onClick={() => printBillA4(bill)}
                          className="p-1.5 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Print A4 Bill"
                        >
                          <Printer className="w-3.5 h-3.5 text-blue-500" />
                        </button>
                        <button
                          onClick={() => printSlip(bill)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Print Slip"
                        >
                          <FileText className="w-3.5 h-3.5 text-slate-400" />
                        </button>
                        <button
                          onClick={() => onEditBill?.(bill)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Edit"
                        >
                          <Pencil className="w-3.5 h-3.5 text-slate-400" />
                        </button>
                        <button
                          onClick={() => openPayments(bill)}
                          className="p-1.5 hover:bg-emerald-50 rounded-lg transition-colors"
                          title="Payment"
                        >
                          <IndianRupee className="w-3.5 h-3.5 text-emerald-500" />
                        </button>
                        <button
                          onClick={() => handleDelete(bill.id)}
                          className="p-1.5 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
