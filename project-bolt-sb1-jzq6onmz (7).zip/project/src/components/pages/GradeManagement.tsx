import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { ConcreteGrade } from '../../lib/types';
import { Plus, Pencil, Trash2, X, Layers } from 'lucide-react';

export default function GradeManagement() {
  const [grades, setGrades] = useState<ConcreteGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<ConcreteGrade | null>(null);
  const [form, setForm] = useState({ grade: '', price_per_mqb: 0, carting_bhadu_per_mqb: 0 });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadGrades();
  }, []);

  async function loadGrades() {
    try {
      const { data } = await supabase.from('concrete_grades').select('*').order('created_at', { ascending: false });
      setGrades(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  function openCreate() {
    setEditing(null);
    setForm({ grade: '', price_per_mqb: 0, carting_bhadu_per_mqb: 0 });
    setShowForm(true);
  }

  function openEdit(grade: ConcreteGrade) {
    setEditing(grade);
    setForm({
      grade: grade.grade,
      price_per_mqb: Number(grade.price_per_mqb),
      carting_bhadu_per_mqb: Number(grade.carting_bhadu_per_mqb),
    });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        grade: form.grade,
        price_per_mqb: Number(form.price_per_mqb),
        carting_bhadu_per_mqb: Number(form.carting_bhadu_per_mqb),
      };
      if (editing) {
        await supabase.from('concrete_grades').update(payload).eq('id', editing.id);
      } else {
        await supabase.from('concrete_grades').insert(payload);
      }
      setShowForm(false);
      loadGrades();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this concrete grade?')) return;
    await supabase.from('concrete_grades').delete().eq('id', id);
    loadGrades();
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Concrete Grades</h1>
          <p className="text-sm text-slate-400 mt-1">Manage concrete grade pricing</p>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Grade
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                {editing ? 'Edit Grade' : 'Add Grade'}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Grade</label>
                <input value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="input-field" required placeholder="e.g. M20, M25, M30" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Price per MQB (₹)</label>
                <input type="number" value={form.price_per_mqb} onChange={(e) => setForm({ ...form, price_per_mqb: Number(e.target.value) })} className="input-field" required min="0" step="0.01" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Carting Bhadu per MQB (₹)</label>
                <input type="number" value={form.carting_bhadu_per_mqb} onChange={(e) => setForm({ ...form, carting_bhadu_per_mqb: Number(e.target.value) })} className="input-field" required min="0" step="0.01" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? 'Saving...' : editing ? 'Update' : 'Add Grade'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading...</div>
      ) : grades.length === 0 ? (
        <div className="card p-12 text-center">
          <Layers className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No concrete grades added yet</p>
          <button onClick={openCreate} className="btn-primary mt-4 btn-sm">Add your first grade</button>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-header">Grade</th>
                  <th className="table-header">Price/MQB</th>
                  <th className="table-header">Carting Bhadu/MQB</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {grades.map((grade, i) => (
                  <tr key={grade.id} className="animate-slide-up" style={{ animationDelay: `${i * 40}ms` }}>
                    <td className="table-cell">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                          <Layers className="w-4 h-4 text-slate-500" />
                        </div>
                        <span className="font-medium text-slate-900">{grade.grade}</span>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className="font-medium text-emerald-700">₹{Number(grade.price_per_mqb).toLocaleString('en-IN')}</span>
                    </td>
                    <td className="table-cell">
                      <span className="font-medium text-blue-700">₹{Number(grade.carting_bhadu_per_mqb).toLocaleString('en-IN')}</span>
                    </td>
                    <td className="table-cell text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => openEdit(grade)} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                          <Pencil className="w-4 h-4 text-slate-400" />
                        </button>
                        <button onClick={() => handleDelete(grade.id)} className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
