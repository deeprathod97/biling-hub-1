import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Site, Truck, BituminousGrade, AsphaltBill } from '../../lib/types';
import { Save, ArrowLeft, Layers, MapPin } from 'lucide-react';

interface Props {
  billId: string;
  onSaved: () => void;
  onBack: () => void;
}

export default function EditAsphaltBill({ billId, onSaved, onBack }: Props) {
  const [sites, setSites] = useState<Site[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [bill, setBill] = useState<AsphaltBill | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    site_id: '',
    truck_id: '',
    grade_id: '',
    date: '',
    quantity_tone: 0,
  });

  useEffect(() => {
    loadData();
  }, [billId]);

  async function loadData() {
    try {
      const [sitesRes, trucksRes, gradesRes, billRes] = await Promise.all([
        supabase.from('sites').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('bituminous_grades').select('*').order('grade'),
        supabase.from('asphalt_bills').select('*, site:sites(*), truck:trucks(*), grade:bituminous_grades(*)').eq('id', billId).single(),
      ]);
      setSites(sitesRes.data || []);
      setTrucks(trucksRes.data || []);
      setGrades(gradesRes.data || []);
      setBill(billRes.data);
      if (billRes.data) {
        setForm({
          site_id: billRes.data.site_id,
          truck_id: billRes.data.truck_id,
          grade_id: billRes.data.grade_id,
          date: billRes.data.date,
          quantity_tone: Number(billRes.data.quantity_tone),
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const selectedGrade = grades.find((g) => g.id === form.grade_id);
  const selectedSite = sites.find((s) => s.id === form.site_id);
  const pricePerTone = selectedGrade ? Number(selectedGrade.price_per_tone) : 0;
  const cartingPerTone = selectedGrade ? Number(selectedGrade.carting_bhadu_per_tone) : 0;
  // Carting bhadu = quantity_tone (auto-equal)
  const cartingBhadu = form.quantity_tone;
  const cartingBhaduTotal = cartingBhadu * cartingPerTone;
  const concreteAmount = form.quantity_tone * pricePerTone;
  const totalTone = form.quantity_tone;
  const amount = concreteAmount + cartingBhaduTotal;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase
        .from('asphalt_bills')
        .update({
          date: form.date,
          site_id: form.site_id,
          truck_id: form.truck_id,
          grade_id: form.grade_id,
          carting_bhadu: cartingBhadu,
          quantity_tone: Number(form.quantity_tone),
          total_tone: totalTone,
          amount,
        })
        .eq('id', billId);
      if (error) throw error;
      onSaved();
    } catch (err) {
      console.error(err);
      alert('Error updating bill. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;
  if (!bill) return <div className="text-center py-12 text-slate-400">Bill not found</div>;

  return (
    <div className="animate-fade-in max-w-2xl">
      <div className="mb-6">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-slate-700 mb-3 text-sm">
          <ArrowLeft className="w-4 h-4" /> Back to Bills
        </button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center">
            <span className="text-white font-mono text-sm">{bill.bill_number}</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Edit Asphalt Bill</h1>
            <p className="text-sm text-slate-400">Bill #{bill.bill_number}</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="card p-6 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Date</label>
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="input-field" required />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Site</label>
            <select value={form.site_id} onChange={(e) => setForm({ ...form, site_id: e.target.value })} className="input-field" required>
              <option value="">Select Site</option>
              {sites.map((s) => (
                <option key={s.id} value={s.id}>{s.name} ({s.site_number})</option>
              ))}
            </select>
          </div>
        </div>

        {selectedSite && (
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-slate-400" />
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Site Details</h4>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white rounded-lg p-2 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase">Location</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.location}</p>
              </div>
              <div className="bg-white rounded-lg p-2 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase">Incharge</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.incharge}</p>
              </div>
              <div className="bg-white rounded-lg p-2 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase">Site No</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.site_number}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Truck</label>
            <select value={form.truck_id} onChange={(e) => setForm({ ...form, truck_id: e.target.value })} className="input-field" required>
              <option value="">Select Truck</option>
              {trucks.map((t) => (
                <option key={t.id} value={t.id}>{t.truck_number} - {t.code}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Bituminous Grade</label>
            <select value={form.grade_id} onChange={(e) => setForm({ ...form, grade_id: e.target.value })} className="input-field" required>
              <option value="">Select Grade</option>
              {grades.map((g) => (
                <option key={g.id} value={g.id}>{g.grade} - ₹{Number(g.price_per_tone).toLocaleString('en-IN')}/Tone</option>
              ))}
            </select>
          </div>
        </div>

        {selectedGrade && (
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 animate-slide-up">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-slate-400" />
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{selectedGrade.grade} - Auto Pricing</h4>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Price / Tone</p>
                <p className="text-lg font-bold text-slate-900">₹{pricePerTone.toLocaleString('en-IN')}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Carting Bhadu / Tone</p>
                <p className="text-lg font-bold text-slate-900">₹{cartingPerTone.toLocaleString('en-IN')}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Quantity (Tone)</label>
            <input type="number" value={form.quantity_tone || ''} onChange={(e) => setForm({ ...form, quantity_tone: Number(e.target.value) })} className="input-field" required min="0" step="0.01" />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Carting Bhadu (Tone)</label>
            <div className="input-field bg-slate-50 text-slate-600 cursor-not-allowed flex items-center">
              {cartingBhadu} <span className="text-xs text-slate-400 ml-2">(auto = Quantity)</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-5 space-y-3 border border-slate-100">
          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Calculation</h4>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Bituminous ({form.quantity_tone} Tone x ₹{pricePerTone.toLocaleString('en-IN')})</span>
              <span className="font-medium text-slate-900">₹{concreteAmount.toLocaleString('en-IN')}</span>
            </div>
            {cartingBhadu > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Carting Bhadu ({cartingBhadu} Tone x ₹{cartingPerTone.toLocaleString('en-IN')})</span>
                <span className="font-medium text-slate-900">₹{cartingBhaduTotal.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Total Tone</span>
              <span className="font-medium text-slate-900">{totalTone}</span>
            </div>
            <div className="border-t border-slate-200 pt-2 flex justify-between">
              <span className="font-semibold text-slate-900">Total Amount</span>
              <span className="text-xl font-bold text-emerald-600">₹{amount.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        <button type="submit" disabled={saving} className="btn-primary w-full flex items-center justify-center gap-2 py-3">
          {saving ? 'Saving...' : (<><Save className="w-4 h-4" /> Save Changes</>)}
        </button>
      </form>
    </div>
  );
}
