import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Site, Truck, BituminousGrade } from '../../lib/types';
import { Save, Layers, MapPin, User, Hash } from 'lucide-react';

export default function CreateAsphaltBill({ onCreated, onCancel }: { onCreated?: () => void; onCancel?: () => void }) {
  const [sites, setSites] = useState<Site[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');

  const [form, setForm] = useState({
    site_id: '',
    truck_id: '',
    grade_id: '',
    date: new Date().toISOString().split('T')[0],
    quantity_tone: 0,
  });

  useEffect(() => {
    loadMasterData();
  }, []);

  async function loadMasterData() {
    try {
      const [sitesRes, trucksRes, gradesRes] = await Promise.all([
        supabase.from('sites').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number'),
        supabase.from('bituminous_grades').select('*').order('grade'),
      ]);
      setSites(sitesRes.data || []);
      setTrucks(trucksRes.data || []);
      setGrades(gradesRes.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  const selectedGrade = grades.find((g) => g.id === form.grade_id);
  const selectedSite = sites.find((s) => s.id === form.site_id);
  const pricePerTone = selectedGrade ? Number(selectedGrade.price_per_tone) : 0;
  const cartingPerTone = selectedGrade ? Number(selectedGrade.carting_bhadu_per_tone) : 0;
  // Carting bhadu = quantity_tone (auto-equal)
  const cartingBhadu = form.quantity_tone;
  const cartingBhaduTotal = cartingBhadu * cartingPerTone;
  const concreteAmount = form.quantity_tone * pricePerTone;
  const totalTone = form.quantity_tone;
  const amount = concreteAmount + cartingBhaduTotal;

  function handleGradeChange(gradeId: string) {
    setForm({ ...form, grade_id: gradeId, quantity_tone: 0 });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSuccess('');
    try {
      const { data: billNumData, error: billNumErr } = await supabase.rpc('get_next_asphalt_bill_number');
      if (billNumErr) throw billNumErr;

      const bill = {
        bill_number: billNumData,
        date: form.date,
        site_id: form.site_id,
        truck_id: form.truck_id,
        grade_id: form.grade_id,
        carting_bhadu: cartingBhadu,
        quantity_tone: Number(form.quantity_tone),
        total_tone: totalTone,
        amount,
        payment_status: 'unpaid' as const,
      };

      const { error } = await supabase.from('asphalt_bills').insert(bill);
      if (error) throw error;

      setSuccess(`Bill #${billNumData} created successfully! Amount: ₹${amount.toLocaleString('en-IN')}`);
      setForm({
        site_id: form.site_id,
        truck_id: '',
        grade_id: form.grade_id,
        date: form.date,
        quantity_tone: 0,
      });
      onCreated?.();
    } catch (err) {
      console.error(err);
      alert('Error creating bill. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading master data...</div>;

  return (
    <div className="animate-fade-in max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Create Asphalt Bill</h1>
        <p className="text-sm text-slate-400 mt-1">Generate a new bituminous mix bill</p>
      </div>

      {success && (
        <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-sm font-medium animate-slide-up">
          {success}
        </div>
      )}

      <form onSubmit={handleSubmit} className="card p-6 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Date</label>
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="input-field" required />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Site</label>
            <select value={form.site_id} onChange={(e) => setForm({ ...form, site_id: e.target.value })} className="input-field" required>
              <option value="">Select Site</option>
              {sites.map((s) => (
                <option key={s.id} value={s.id}>{s.name} ({s.site_number})</option>
              ))}
            </select>
          </div>
        </div>

        {selectedSite && (
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 animate-slide-up">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-slate-400" />
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Site Details</h4>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Site Number</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.site_number}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Location</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.location}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Incharge</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.incharge}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider flex items-center gap-1"><Hash className="w-3 h-3" /> Site ID</p>
                <p className="text-sm font-bold text-slate-900">{selectedSite.site_number}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Truck</label>
            <select value={form.truck_id} onChange={(e) => setForm({ ...form, truck_id: e.target.value })} className="input-field" required>
              <option value="">Select Truck</option>
              {trucks.map((t) => (
                <option key={t.id} value={t.id}>{t.truck_number} - {t.code} ({t.wheels} wheels)</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Bituminous Grade</label>
            <select value={form.grade_id} onChange={(e) => handleGradeChange(e.target.value)} className="input-field" required>
              <option value="">Select Grade</option>
              {grades.map((g) => (
                <option key={g.id} value={g.id}>{g.grade} - ₹{Number(g.price_per_tone).toLocaleString('en-IN')}/Tone</option>
              ))}
            </select>
          </div>
        </div>

        {selectedGrade && (
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 animate-slide-up">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-slate-400" />
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{selectedGrade.grade} - Auto Pricing</h4>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Price / Tone</p>
                <p className="text-lg font-bold text-slate-900">₹{pricePerTone.toLocaleString('en-IN')}</p>
              </div>
              <div className="bg-white rounded-lg p-3 border border-slate-100">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Carting Bhadu / Tone</p>
                <p className="text-lg font-bold text-slate-900">₹{cartingPerTone.toLocaleString('en-IN')}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Quantity (Tone)</label>
            <input type="number" value={form.quantity_tone || ''} onChange={(e) => setForm({ ...form, quantity_tone: Number(e.target.value) })} className="input-field" required min="0" step="0.01" placeholder="0" />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 mb-1 block">Carting Bhadu (Tone)</label>
            <div className="input-field bg-slate-50 text-slate-600 cursor-not-allowed flex items-center">
              {cartingBhadu} <span className="text-xs text-slate-400 ml-2">(auto = Quantity)</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-5 space-y-3 border border-slate-100">
          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Calculation</h4>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Price per Tone</span>
              <span className="font-medium text-slate-900">₹{pricePerTone.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Bituminous ({form.quantity_tone} Tone x ₹{pricePerTone.toLocaleString('en-IN')})</span>
              <span className="font-medium text-slate-900">₹{concreteAmount.toLocaleString('en-IN')}</span>
            </div>
            {cartingBhadu > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Carting Bhadu ({cartingBhadu} Tone x ₹{cartingPerTone.toLocaleString('en-IN')})</span>
                <span className="font-medium text-slate-900">₹{cartingBhaduTotal.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Total Tone</span>
              <span className="font-medium text-slate-900">{totalTone}</span>
            </div>
            <div className="border-t border-slate-200 pt-2 flex justify-between">
              <span className="font-semibold text-slate-900">Total Amount</span>
              <span className="text-xl font-bold text-emerald-600">₹{amount.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          {onCancel && (
            <button type="button" onClick={onCancel} className="btn-secondary flex-1">Cancel</button>
          )}
          <button type="submit" disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2 py-3">
            {saving ? 'Creating Bill...' : (<><Save className="w-4 h-4" /> Create Bill</>)}
          </button>
        </div>
      </form>
    </div>
  );
}
