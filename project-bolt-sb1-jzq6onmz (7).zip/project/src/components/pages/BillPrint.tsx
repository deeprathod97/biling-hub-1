import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { RmcBill, Payment } from '../../lib/types';
import { X, Printer } from 'lucide-react';

const COMPANY_LOGO = 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj5m4IoG1JS37j-ZWdejm2yBrFZVrv_MgO8tulIsz4A7HEK47tYw6IWDU8vPenDrnDdthVURhHgYqY0q1osLe121lCYdN67MX_t0nFMn5vCTCgHLK02XIAx84J4N6fEsWFw4tes784tJvnBddDuW_gQ7VqUTi_6ZVh94cFkD1QcU6xfwN7Rf-IWz_0SZf7a/s320/ChatGPT_Image_Jun_5__2026__11_40_06_AM-removebg-preview%20(1).png';

interface BillPrintProps {
  bill: RmcBill;
  mode: 'a4' | 'slip';
  onClose: () => void;
}

export default function BillPrint({ bill, mode, onClose }: BillPrintProps) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [fullBill, setFullBill] = useState<RmcBill>(bill);

  useEffect(() => {
    loadData();
  }, [bill.id]);

  async function loadData() {
    const [billRes, payRes] = await Promise.all([
      supabase.from('rmc_bills').select('*, site:sites(*), tm:transit_mixers(*), grade:concrete_grades(*)').eq('id', bill.id).single(),
      supabase.from('payments').select('*').eq('bill_id', bill.id).order('payment_date'),
    ]);
    if (billRes.data) setFullBill(billRes.data as any);
    setPayments(payRes.data || []);
  }

  const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);
  const balance = Number(fullBill.amount) - totalPaid;

  function handlePrint() {
    window.print();
  }

  if (mode === 'slip') {
    return (
      <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 no-print" onClick={onClose}>
        <div className="bg-white rounded-lg shadow-xl w-full max-w-sm animate-scale-in" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between p-3 border-b no-print">
            <h3 className="text-sm font-bold text-slate-900">Print Slip</h3>
            <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded"><X className="w-4 h-4 text-slate-400" /></button>
          </div>
          <div className="print-area p-4 text-black font-mono text-xs">
            <div className="text-center mb-3">
              <p className="font-bold text-sm">D CONCRETE PVT. LTD.</p>
              <p className="text-[10px]">Dholera, Gujarat</p>
              <p className="text-[10px]">GST: 24BM3LOIBL2W1Z</p>
            </div>
            <div className="border-t border-black pt-2 space-y-1">
              <p>Bill No: {fullBill.bill_number}</p>
              <p>Date: {fullBill.date}</p>
              <p>Site: {fullBill.site?.name || '-'}</p>
              <p>TM: {fullBill.tm?.tm_number || '-'}</p>
              <p>Grade: {fullBill.grade?.grade || '-'}</p>
              <p>Qty: {Number(fullBill.quantity_mqb)} MQB</p>
              <p>Carting: {Number(fullBill.carting_bhadu)} MQB</p>
            </div>
            <div className="border-t border-black mt-2 pt-2">
              <p className="font-bold">Amount: ₹{Number(fullBill.amount).toLocaleString('en-IN')}</p>
            </div>
            <div className="border-t border-dashed border-black mt-4 pt-2 text-center text-[10px]">
              <p>D CONCRETE PVT. LTD.</p>
            </div>
          </div>
          <div className="p-3 border-t no-print flex justify-end">
            <button onClick={handlePrint} className="btn-primary btn-sm flex items-center gap-2">
              <Printer className="w-3 h-3" /> Print
            </button>
          </div>
        </div>
      </div>
    );
  }

  // A4 Bill
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 no-print" onClick={onClose}>
      <div className="bg-white shadow-xl w-full max-w-[210mm] animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-3 border-b no-print">
          <h3 className="text-sm font-bold text-slate-900">Print A4 Bill</h3>
          <div className="flex gap-2">
            <button onClick={handlePrint} className="btn-primary btn-sm flex items-center gap-2">
              <Printer className="w-3 h-3" /> Print
            </button>
            <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded"><X className="w-4 h-4 text-slate-400" /></button>
          </div>
        </div>
        <div className="print-area p-8 text-black" style={{ fontFamily: 'Inter, sans-serif' }}>
          {/* Header */}
          <div className="flex items-start justify-between border-b-2 border-black pb-4 mb-6">
            <div className="flex items-center gap-4">
              <img src={COMPANY_LOGO} alt="D Concrete" className="w-16 h-16 object-contain" />
              <div>
                <h1 className="text-xl font-bold tracking-wide">D CONCRETE PVT. LTD.</h1>
                <p className="text-xs text-gray-600 mt-0.5">Dholera, Gujarat</p>
                <p className="text-xs text-gray-600">GSTIN: 24BM3LOIBL2W1Z</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold">TAX INVOICE</p>
              <div className="border border-black px-3 py-1 mt-1 text-xs">
                <p>Bill No: <strong>{fullBill.bill_number}</strong></p>
                <p>Date: <strong>{fullBill.date}</strong></p>
              </div>
            </div>
          </div>

          {/* Bill To */}
          <div className="border border-black rounded mb-6">
            <div className="bg-gray-100 px-3 py-1 text-xs font-bold border-b border-black">BILL TO</div>
            <div className="p-3 text-sm">
              <p><strong>Site:</strong> {fullBill.site?.name || '-'}</p>
              <p><strong>Site No:</strong> {fullBill.site?.site_number || '-'}</p>
              <p><strong>Location:</strong> {fullBill.site?.location || '-'}</p>
              <p><strong>In-charge:</strong> {fullBill.site?.incharge || '-'}</p>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full border-collapse border border-black text-sm mb-6">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-black px-3 py-2 text-left text-xs font-bold">#</th>
                <th className="border border-black px-3 py-2 text-left text-xs font-bold">Description</th>
                <th className="border border-black px-3 py-2 text-right text-xs font-bold">MQB</th>
                <th className="border border-black px-3 py-2 text-right text-xs font-bold">Rate (₹)</th>
                <th className="border border-black px-3 py-2 text-right text-xs font-bold">Amount (₹)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-black px-3 py-2">1</td>
                <td className="border border-black px-3 py-2">
                  Ready Mix Concrete - {fullBill.grade?.grade || '-'} Grade
                  <br /><span className="text-xs text-gray-500">TM: {fullBill.tm?.tm_number || '-'} ({fullBill.tm?.code || '-'})</span>
                </td>
                <td className="border border-black px-3 py-2 text-right">{Number(fullBill.quantity_mqb)}</td>
                <td className="border border-black px-3 py-2 text-right">{Number(fullBill.grade?.price_per_mqb || 0).toLocaleString('en-IN')}</td>
                <td className="border border-black px-3 py-2 text-right">
                  {(Number(fullBill.quantity_mqb) * Number(fullBill.grade?.price_per_mqb || 0)).toLocaleString('en-IN')}
                </td>
              </tr>
              {Number(fullBill.carting_bhadu) > 0 && (
                <tr>
                  <td className="border border-black px-3 py-2">2</td>
                  <td className="border border-black px-3 py-2">Carting Bhadu</td>
                  <td className="border border-black px-3 py-2 text-right">{Number(fullBill.carting_bhadu)}</td>
                  <td className="border border-black px-3 py-2 text-right">{Number(fullBill.grade?.carting_bhadu_per_mqb || 0).toLocaleString('en-IN')}</td>
                  <td className="border border-black px-3 py-2 text-right">
                    {(Number(fullBill.carting_bhadu) * Number(fullBill.grade?.carting_bhadu_per_mqb || 0)).toLocaleString('en-IN')}
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-gray-100 font-bold">
                <td className="border border-black px-3 py-2 text-right" colSpan={4}>Total Amount</td>
                <td className="border border-black px-3 py-2 text-right">₹{Number(fullBill.amount).toLocaleString('en-IN')}</td>
              </tr>
            </tfoot>
          </table>

          {/* Total MQB */}
          <div className="flex justify-between text-sm mb-6">
            <span>Total MQB: <strong>{Number(fullBill.total_mqb)}</strong></span>
          </div>

          {/* Payment info */}
          {payments.length > 0 && (
            <div className="border border-black rounded mb-6">
              <div className="bg-gray-100 px-3 py-1 text-xs font-bold border-b border-black">PAYMENT HISTORY</div>
              <div className="p-3 space-y-1 text-sm">
                {payments.map((p) => (
                  <div key={p.id} className="flex justify-between">
                    <span>{p.payment_date} {p.notes ? `(${p.notes})` : ''}</span>
                    <span className="font-medium">₹{Number(p.amount).toLocaleString('en-IN')}</span>
                  </div>
                ))}
                <div className="border-t border-black pt-1 flex justify-between font-bold">
                  <span>Balance Due</span>
                  <span>₹{balance.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          )}

          {/* Amount in words placeholder */}
          <div className="text-sm mb-6">
            <p className="text-xs text-gray-500">Amount in words:</p>
            <p className="font-medium border-b border-dotted border-gray-300 pb-1">
              Rupees {Number(fullBill.amount).toLocaleString('en-IN')} Only
            </p>
          </div>

          {/* Signatures */}
          <div className="flex justify-between mt-12 pt-4">
            <div className="text-center">
              <div className="w-40 border-t border-black pt-2 text-xs">Authorized Signatory</div>
            </div>
            <div className="text-center">
              <div className="w-40 border-t border-black pt-2 text-xs">For D Concrete Pvt. Ltd.</div>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 pt-3 border-t border-gray-300 text-center">
            <p className="text-[10px] text-gray-400">
              This is a computer-generated invoice. | D CONCRETE PVT. LTD. | Dholera, Gujarat | GST: 24BM3LOIBL2W1Z
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
