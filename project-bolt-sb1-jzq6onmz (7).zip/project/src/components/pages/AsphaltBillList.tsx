import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { AsphaltBill, Site, Truck, BituminousGrade, AsphaltPayment } from '../../lib/types';
import { FileText, Plus, Eye, Pencil, Trash2, Printer, CreditCard, X, Truck as TruckIcon, MapPin, User, Hash, Scale, IndianRupee, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface Props {
  onEdit: (id: string) => void;
  onCreate: () => void;
}

export default function AsphaltBillList({ onEdit, onCreate }: Props) {
  const [bills, setBills] = useState<AsphaltBill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPayments, setShowPayments] = useState<string | null>(null);
  const [payments, setPayments] = useState<AsphaltPayment[]>([]);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');

  useEffect(() => {
    loadBills();
  }, []);

  async function loadBills() {
    try {
      const { data } = await supabase
        .from('asphalt_bills')
        .select('*, site:sites(*), truck:trucks(*), grade:bituminous_grades(*)')
        .order('created_at', { ascending: false });
      setBills(data || []);
    } finally {
      setLoading(false);
    }
  }

  async function viewPayments(billId: string) {
    const { data } = await supabase.from('asphalt_payments').select('*').eq('bill_id', billId).order('payment_date', { ascending: false });
    setPayments(data || []);
    setShowPayments(billId);
    setPaymentAmount('');
    setPaymentNotes('');
  }

  async function addPayment(billId: string) {
    if (!paymentAmount || Number(paymentAmount) <= 0) return;

    await supabase.from('asphalt_payments').insert({ bill_id: billId, amount: Number(paymentAmount), notes: paymentNotes || null });

    // Calculate total paid and update status
    const bill = bills.find(b => b.id === billId);
    if (bill) {
      const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0) + Number(paymentAmount);
      const billAmount = Number(bill.amount);
      const status = totalPaid >= billAmount ? 'paid' : totalPaid > 0 ? 'partial' : 'unpaid';
      await supabase.from('asphalt_bills').update({ payment_status: status }).eq('id', billId);
    }

    viewPayments(billId);
    loadBills();
  }

  async function deletePayment(id: string, billId: string) {
    if (!confirm('Delete this payment?')) return;
    await supabase.from('asphalt_payments').delete().eq('id', id);

    // Calculate remaining paid and update status
    const remainingPayments = payments.filter(p => p.id !== id);
    const totalPaid = remainingPayments.reduce((s, p) => s + Number(p.amount), 0);
    const bill = bills.find(b => b.id === billId);
    if (bill) {
      const billAmount = Number(bill.amount);
      const status = totalPaid >= billAmount ? 'paid' : totalPaid > 0 ? 'partial' : 'unpaid';
      await supabase.from('asphalt_bills').update({ payment_status: status }).eq('id', billId);
    }

    viewPayments(billId);
    loadBills();
  }

  async function deleteBill(id: string) {
    if (!confirm('Delete this bill and all its payments?')) return;
    await supabase.from('asphalt_payments').delete().eq('bill_id', id);
    await supabase.from('asphalt_bills').delete().eq('id', id);
    loadBills();
  }

  function printBill(bill: AsphaltBill) {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const totalPaid = payments.filter(p => p.bill_id === bill.id).reduce((sum, p) => sum + Number(p.amount), 0);
    const pending = bill.amount - totalPaid;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Asphalt Bill #${bill.bill_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; padding: 20mm; font-size: 12pt; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .header h1 { font-size: 24pt; margin-bottom: 5px; }
          .header p { color: #666; }
          .bill-info { display: flex; justify-content: space-between; margin-bottom: 20px; }
          .bill-info div { flex: 1; }
          .bill-info label { font-size: 9pt; color: #666; display: block; }
          .bill-info span { font-size: 11pt; font-weight: bold; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
          th { background: #f5f5f5; }
          .totals { margin-top: 20px; text-align: right; }
          .totals div { margin: 5px 0; }
          .totals .total { font-size: 16pt; font-weight: bold; border-top: 2px solid #000; padding-top: 10px; }
          .footer { margin-top: 40px; text-align: center; font-size: 10pt; color: #666; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>ASPHALT BILL</h1>
          <p>Bituminous Mix Supply Invoice</p>
        </div>
        <div class="bill-info">
          <div><label>Bill No</label><span>${bill.bill_number}</span></div>
          <div><label>Date</label><span>${bill.date}</span></div>
          <div><label>Status</label><span style="text-transform: uppercase;">${bill.payment_status}</span></div>
        </div>
        <div class="bill-info">
          <div><label>Site</label><span>${bill.site?.name || '-'}</span></div>
          <div><label>Site Number</label><span>${bill.site?.site_number || '-'}</span></div>
          <div><label>Location</label><span>${bill.site?.location || '-'}</span></div>
          <div><label>Incharge</label><span>${bill.site?.incharge || '-'}</span></div>
        </div>
        <div class="bill-info">
          <div><label>Truck</label><span>${bill.truck?.truck_number || '-'}</span></div>
          <div><label>Truck Code</label><span>${bill.truck?.code || '-'}</span></div>
          <div><label>Grade</label><span>${bill.grade?.grade || '-'}</span></div>
        </div>
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th>Qty (Tone)</th>
              <th>Rate (₹)</th>
              <th>Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Bituminous Mix (${bill.grade?.grade || '-'})</td>
              <td>${bill.quantity_tone}</td>
              <td>${bill.grade ? Number(bill.grade.price_per_tone).toLocaleString('en-IN') : '0'}</td>
              <td>${(bill.quantity_tone * (bill.grade ? Number(bill.grade.price_per_tone) : 0)).toLocaleString('en-IN')}</td>
            </tr>
            ${bill.carting_bhadu > 0 ? `
            <tr>
              <td>Carting Bhadu</td>
              <td>${bill.carting_bhadu}</td>
              <td>${bill.grade ? Number(bill.grade.carting_bhadu_per_tone).toLocaleString('en-IN') : '0'}</td>
              <td>${(bill.carting_bhadu * (bill.grade ? Number(bill.grade.carting_bhadu_per_tone) : 0)).toLocaleString('en-IN')}</td>
            </tr>
            ` : ''}
          </tbody>
        </table>
        <div class="totals">
          <div><strong>Total Tone:</strong> ${bill.total_tone}</div>
          <div class="total"><strong>Grand Total:</strong> ₹${Number(bill.amount).toLocaleString('en-IN')}</div>
        </div>
        <div class="footer">
          <p>Thank you for your business!</p>
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  }

  function printGatePass(bill: AsphaltBill) {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Gate Pass #${bill.bill_number}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; padding: 15mm; font-size: 14pt; }
          .gate-pass { border: 3px solid #000; padding: 20px; }
          .header { text-align: center; border-bottom: 2px dashed #000; padding-bottom: 15px; margin-bottom: 15px; }
          .header h1 { font-size: 28pt; letter-spacing: 5px; }
          .content { margin: 15px 0; }
          .row { display: flex; justify-content: space-between; margin: 10px 0; padding: 5px 0; border-bottom: 1px dotted #ccc; }
          .row label { font-weight: bold; }
          .seal { margin-top: 30px; text-align: right; }
          .seal div { border: 1px solid #000; padding: 10px 30px; display: inline-block; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="gate-pass">
          <div class="header">
            <h1>GATE PASS</h1>
            <p>Asphalt Material Dispatch</p>
          </div>
          <div class="content">
            <div class="row"><label>Gate Pass No:</label><span>${bill.bill_number}</span></div>
            <div class="row"><label>Date:</label><span>${bill.date}</span></div>
            <div class="row"><label>Truck Number:</label><span>${bill.truck?.truck_number || '-'}</span></div>
            <div class="row"><label>Truck Code:</label><span>${bill.truck?.code || '-'}</span></div>
            <div class="row"><label>Destination Site:</label><span>${bill.site?.name || '-'}</span></div>
            <div class="row"><label>Site Location:</label><span>${bill.site?.location || '-'}</span></div>
            <div class="row"><label>Material Grade:</label><span>${bill.grade?.grade || '-'}</span></div>
            <div class="row"><label>Quantity:</label><span>${bill.total_tone} Tone</span></div>
            <div class="row"><label>Site Incharge:</label><span>${bill.site?.incharge || '-'}</span></div>
          </div>
          <div class="seal">
            <div>AUTHORIZED SIGNATURE</div>
          </div>
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  }

  const statusConfig = {
    paid: { icon: CheckCircle, color: 'text-emerald-600 bg-emerald-50', label: 'Paid' },
    partial: { icon: Clock, color: 'text-amber-600 bg-amber-50', label: 'Partial' },
    unpaid: { icon: AlertCircle, color: 'text-red-600 bg-red-50', label: 'Unpaid' },
  };

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;

  const totalAmount = bills.reduce((sum, b) => sum + Number(b.amount), 0);
  const totalTone = bills.reduce((sum, b) => sum + Number(b.total_tone), 0);
  const totalBills = bills.length;

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Asphalt Bills</h1>
            <p className="text-sm text-slate-400">Manage bituminous mix billing</p>
          </div>
        </div>
        <button onClick={onCreate} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Bill
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
            <IndianRupee className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <p className="text-xs text-slate-400 uppercase tracking-wider">Total Amount</p>
            <p className="text-xl font-bold text-slate-900">₹{totalAmount.toLocaleString('en-IN')}</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
            <Scale className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <p className="text-xs text-slate-400 uppercase tracking-wider">Total Tone</p>
            <p className="text-xl font-bold text-slate-900">{totalTone.toLocaleString('en-IN')}</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center">
            <Hash className="w-6 h-6 text-slate-600" />
          </div>
          <div>
            <p className="text-xs text-slate-400 uppercase tracking-wider">Total Bills</p>
            <p className="text-xl font-bold text-slate-900">{totalBills}</p>
          </div>
        </div>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Bill No</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Date</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Site</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Truck</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Grade</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Tone</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Amount</th>
              <th className="text-center text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Status</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {bills.map((bill) => {
              const StatusIcon = statusConfig[bill.payment_status].icon;
              return (
                <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-mono font-semibold text-slate-900">{bill.bill_number}</td>
                  <td className="px-4 py-3 text-slate-600">{bill.date}</td>
                  <td className="px-4 py-3">
                    <div className="text-sm font-medium text-slate-900">{bill.site?.name || '-'}</div>
                    <div className="text-xs text-slate-400">{bill.site?.location || '-'}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-sm font-medium text-slate-900">{bill.truck?.truck_number || '-'}</div>
                    <div className="text-xs text-slate-400">{bill.truck?.code || '-'}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium">{bill.grade?.grade || '-'}</span>
                  </td>
                  <td className="px-4 py-3 text-right font-medium text-slate-900">{Number(bill.total_tone).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 text-right font-medium text-slate-900">₹{Number(bill.amount).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${statusConfig[bill.payment_status].color}`}>
                      <StatusIcon className="w-3 h-3" />
                      {statusConfig[bill.payment_status].label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => printBill(bill)} title="Print Bill" className="text-slate-400 hover:text-slate-600 p-1">
                        <Printer className="w-4 h-4" />
                      </button>
                      <button onClick={() => printGatePass(bill)} title="Gate Pass" className="text-slate-400 hover:text-amber-600 p-1">
                        <FileText className="w-4 h-4" />
                      </button>
                      <button onClick={() => viewPayments(bill.id)} title="Payments" className="text-slate-400 hover:text-emerald-600 p-1">
                        <CreditCard className="w-4 h-4" />
                      </button>
                      <button onClick={() => onEdit(bill.id)} title="Edit" className="text-slate-400 hover:text-blue-600 p-1">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteBill(bill.id)} title="Delete" className="text-slate-400 hover:text-red-600 p-1">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {bills.length === 0 && (
              <tr><td colSpan={9} className="text-center py-12 text-slate-400">No bills yet. Click "New Bill" to create one.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Payments Modal */}
      {showPayments && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg animate-slide-up max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Payments</h2>
                <p className="text-xs text-slate-400">Bill #{bills.find(b => b.id === showPayments)?.bill_number}</p>
              </div>
              <button onClick={() => setShowPayments(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Bill Summary */}
            {(() => {
              const bill = bills.find(b => b.id === showPayments);
              if (!bill) return null;
              const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);
              const balance = Number(bill.amount) - totalPaid;
              return (
                <div className="bg-slate-50 rounded-xl p-4 mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-slate-500">Bill Amount</span>
                    <span className="font-bold text-slate-900">₹{Number(bill.amount).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-slate-500">Total Paid</span>
                    <span className="font-medium text-emerald-600">₹{totalPaid.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-sm pt-2 border-t border-slate-200">
                    <span className="text-slate-500">Balance Due</span>
                    <span className="font-bold text-red-600">₹{balance.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              );
            })()}

            <div className="space-y-3 mb-4">
              {payments.length === 0 && <p className="text-center text-slate-400 py-4">No payments yet</p>}
              {payments.map((p) => (
                <div key={p.id} className="flex items-center justify-between bg-slate-50 rounded-lg p-3">
                  <div>
                    <p className="font-medium text-slate-900">₹{Number(p.amount).toLocaleString('en-IN')}</p>
                    <p className="text-xs text-slate-400">{p.payment_date} {p.notes && `• ${p.notes}`}</p>
                  </div>
                  <button onClick={() => deletePayment(p.id, showPayments!)} className="text-red-400 hover:text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
            <div className="border-t border-slate-100 pt-4">
              <h4 className="text-sm font-medium text-slate-700 mb-2">Add Payment</h4>
              <div className="space-y-2">
                <div className="flex gap-2">
                  <input type="number" value={paymentAmount} onChange={(e) => setPaymentAmount(e.target.value)} placeholder="Amount (₹)" className="input-field flex-1" min="0" />
                  {(() => {
                    const bill = bills.find(b => b.id === showPayments);
                    if (!bill) return null;
                    const balance = Number(bill.amount) - payments.reduce((s, p) => s + Number(p.amount), 0);
                    return (
                      <button
                        type="button"
                        onClick={() => setPaymentAmount(String(balance))}
                        className="btn-secondary whitespace-nowrap text-xs"
                      >
                        Full Amount
                      </button>
                    );
                  })()}
                </div>
                <input type="text" value={paymentNotes} onChange={(e) => setPaymentNotes(e.target.value)} placeholder="Notes (optional)" className="input-field w-full" />
                <button onClick={() => addPayment(showPayments!)} className="btn-primary w-full">Add Payment</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
