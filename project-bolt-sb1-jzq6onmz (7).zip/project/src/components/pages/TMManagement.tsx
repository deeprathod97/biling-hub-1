import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { TransitMixer } from '../../lib/types';
import { Plus, Pencil, Trash2, X, Truck, Hash } from 'lucide-react';

export default function TMManagement() {
  const [tms, setTms] = useState<TransitMixer[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<TransitMixer | null>(null);
  const [form, setForm] = useState({ tm_number: '', code: '', wheels: 6 });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadTMs();
  }, []);

  async function loadTMs() {
    try {
      const { data } = await supabase.from('transit_mixers').select('*').order('created_at', { ascending: false });
      setTms(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  function openCreate() {
    setEditing(null);
    setForm({ tm_number: '', code: '', wheels: 6 });
    setShowForm(true);
  }

  function openEdit(tm: TransitMixer) {
    setEditing(tm);
    setForm({ tm_number: tm.tm_number, code: tm.code, wheels: tm.wheels });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await supabase.from('transit_mixers').update({ ...form, wheels: Number(form.wheels) }).eq('id', editing.id);
      } else {
        await supabase.from('transit_mixers').insert({ ...form, wheels: Number(form.wheels) });
      }
      setShowForm(false);
      loadTMs();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this transit mixer?')) return;
    await supabase.from('transit_mixers').delete().eq('id', id);
    loadTMs();
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Transit Mixers</h1>
          <p className="text-sm text-slate-400 mt-1">Manage transit mixer vehicles</p>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add TM
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                {editing ? 'Edit Transit Mixer' : 'Add Transit Mixer'}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">TM Number</label>
                <input value={form.tm_number} onChange={(e) => setForm({ ...form, tm_number: e.target.value })} className="input-field" required placeholder="e.g. TM-001" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Code</label>
                <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="input-field" required placeholder="e.g. GJ-01-AB-1234" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Wheels</label>
                <select value={form.wheels} onChange={(e) => setForm({ ...form, wheels: Number(e.target.value) })} className="input-field">
                  <option value={4}>4 Wheels</option>
                  <option value={6}>6 Wheels</option>
                  <option value={8}>8 Wheels</option>
                  <option value={10}>10 Wheels</option>
                  <option value={12}>12 Wheels</option>
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? 'Saving...' : editing ? 'Update' : 'Add TM'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading...</div>
      ) : tms.length === 0 ? (
        <div className="card p-12 text-center">
          <Truck className="w-12 h-12 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No transit mixers added yet</p>
          <button onClick={openCreate} className="btn-primary mt-4 btn-sm">Add your first TM</button>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="table-header">TM Number</th>
                  <th className="table-header">Code</th>
                  <th className="table-header">Wheels</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {tms.map((tm, i) => (
                  <tr key={tm.id} className="animate-slide-up" style={{ animationDelay: `${i * 40}ms` }}>
                    <td className="table-cell">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                          <Truck className="w-4 h-4 text-slate-500" />
                        </div>
                        <span className="font-medium text-slate-900">{tm.tm_number}</span>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className="inline-flex items-center gap-1 text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md">
                        <Hash className="w-3 h-3" />{tm.code}
                      </span>
                    </td>
                    <td className="table-cell">
                      <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-md font-medium">
                        {tm.wheels} Wheels
                      </span>
                    </td>
                    <td className="table-cell text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => openEdit(tm)} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                          <Pencil className="w-4 h-4 text-slate-400" />
                        </button>
                        <button onClick={() => handleDelete(tm.id)} className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
