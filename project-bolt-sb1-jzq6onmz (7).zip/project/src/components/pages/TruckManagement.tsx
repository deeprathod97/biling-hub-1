import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Truck } from '../../lib/types';
import { Truck as TruckIcon, Plus, Pencil, Trash2, X } from 'lucide-react';

export default function TruckManagement() {
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingTruck, setEditingTruck] = useState<Truck | null>(null);
  const [form, setForm] = useState({ truck_number: '', code: '', wheels: 6 });

  useEffect(() => {
    loadTrucks();
  }, []);

  async function loadTrucks() {
    try {
      const { data } = await supabase.from('trucks').select('*').order('truck_number');
      setTrucks(data || []);
    } finally {
      setLoading(false);
    }
  }

  function openAddModal() {
    setEditingTruck(null);
    setForm({ truck_number: '', code: '', wheels: 6 });
    setShowModal(true);
  }

  function openEditModal(truck: Truck) {
    setEditingTruck(truck);
    setForm({ truck_number: truck.truck_number, code: truck.code, wheels: truck.wheels });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (editingTruck) {
        await supabase.from('trucks').update(form).eq('id', editingTruck.id);
      } else {
        await supabase.from('trucks').insert(form);
      }
      setShowModal(false);
      loadTrucks();
    } catch (err) {
      console.error(err);
      alert('Error saving truck');
    }
  }

  async function deleteTruck(id: string) {
    if (!confirm('Delete this truck?')) return;
    try {
      await supabase.from('trucks').delete().eq('id', id);
      loadTrucks();
    } catch (err) {
      console.error(err);
      alert('Error deleting truck');
    }
  }

  if (loading) return <div className="text-center py-12 text-slate-400">Loading...</div>;

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
            <TruckIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Truck Management</h1>
            <p className="text-sm text-slate-400">Manage truck fleet</p>
          </div>
        </div>
        <button onClick={openAddModal} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Truck
        </button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Truck Number</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Code</th>
              <th className="text-left text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Wheels</th>
              <th className="text-right text-xs font-semibold text-slate-500 uppercase tracking-wider px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {trucks.map((truck) => (
              <tr key={truck.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3 font-medium text-slate-900">{truck.truck_number}</td>
                <td className="px-4 py-3 text-slate-600">{truck.code}</td>
                <td className="px-4 py-3 text-slate-600">{truck.wheels}</td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => openEditModal(truck)} className="text-slate-400 hover:text-slate-600 p-1">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => deleteTruck(truck.id)} className="text-slate-400 hover:text-red-500 p-1 ml-2">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
            {trucks.length === 0 && (
              <tr><td colSpan={4} className="text-center py-8 text-slate-400">No trucks added yet</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900">{editingTruck ? 'Edit Truck' : 'Add Truck'}</h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Truck Number</label>
                <input type="text" value={form.truck_number} onChange={(e) => setForm({ ...form, truck_number: e.target.value })} className="input-field" required placeholder="TR-001" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Code (Registration)</label>
                <input type="text" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className="input-field" required placeholder="GJ-01-AB-1234" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-500 mb-1 block">Wheels</label>
                <select value={form.wheels} onChange={(e) => setForm({ ...form, wheels: Number(e.target.value) })} className="input-field">
                  <option value={4}>4</option>
                  <option value={6}>6</option>
                  <option value={8}>8</option>
                  <option value={10}>10</option>
                  <option value={12}>12</option>
                </select>
              </div>
              <button type="submit" className="btn-primary w-full">{editingTruck ? 'Update' : 'Add'} Truck</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
