import { useState } from 'react';
import {
  LayoutDashboard,
  Building2,
  Truck,
  Layers,
  FileText,
  Printer,
  Building,
  Menu,
  X,
  Droplets,
  FileBarChart,
} from 'lucide-react';

const COMPANY_LOGO = 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj5m4IoG1JS37j-ZWdejm2yBrFZVrv_MgO8tulIsz4A7HEK47tYw6IWDU8vPenDrnDdthVURhHgYqY0q1osLe121lCYdN67MX_t0nFMn5vCTCgHLK02XIAx84J4N6fEsWFw4tes784tJvnBddDuW_gQ7VqUTi_6ZVh94cFkD1QcU6xfwN7Rf-IWz_0SZf7a/s320/ChatGPT_Image_Jun_5__2026__11_40_06_AM-removebg-preview%20(1).png';

export type Page =
  | 'dashboard'
  | 'sites'
  | 'tms'
  | 'grades'
  | 'create-bill'
  | 'bills'
  | 'rmc-report'
  | 'profile'
  | 'trucks'
  | 'bit-grades'
  | 'asphalt-bills'
  | 'create-asphalt-bill'
  | 'asphalt-report';

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const navItems: { id: Page; label: string; icon: React.ElementType; section?: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'sites', label: 'Sites', icon: Building2 },
  { id: 'tms', label: 'Transit Mixers', icon: Truck },
  { id: 'grades', label: 'Concrete Grades', icon: Layers },
  { id: 'create-bill', label: 'Create RMC Bill', icon: FileText },
  { id: 'bills', label: 'RMC Bills', icon: Printer },
  { id: 'rmc-report', label: 'Sales Report', icon: FileBarChart },
  { id: 'trucks', label: 'Trucks', icon: Truck, section: 'Asphalt' },
  { id: 'bit-grades', label: 'Bituminous Grades', icon: Droplets },
  { id: 'create-asphalt-bill', label: 'Create Asphalt Bill', icon: FileText },
  { id: 'asphalt-bills', label: 'Asphalt Bills', icon: Printer },
  { id: 'asphalt-report', label: 'Asphalt Sales Report', icon: FileBarChart },
  { id: 'profile', label: 'Company Profile', icon: Building },
];

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(true)}
        className="fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-lg border border-slate-100 lg:hidden"
      >
        <Menu className="w-5 h-5 text-slate-700" />
      </button>

      {/* Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-40 lg:hidden animate-fade-in"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-white border-r border-slate-100 z-50 flex flex-col transition-transform duration-300 lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo area */}
        <div className="p-5 border-b border-slate-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={COMPANY_LOGO}
                alt="D Concrete"
                className="w-10 h-10 object-contain"
              />
              <div>
                <h2 className="text-sm font-bold text-slate-900 leading-tight">
                  D CONCRETE
                </h2>
                <p className="text-[10px] text-slate-400 tracking-widest uppercase">
                  PVT. LTD.
                </p>
              </div>
            </div>
            <button
              onClick={() => setMobileOpen(false)}
              className="lg:hidden p-1 hover:bg-slate-100 rounded"
            >
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item, idx) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            const showSection = item.section && (idx === 0 || navItems[idx - 1].section !== item.section);
            return (
              <div key={item.id}>
                {showSection && (
                  <div className="px-3 py-2 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    {item.section}
                  </div>
                )}
                <button
                  onClick={() => {
                    onNavigate(item.id);
                    setMobileOpen(false);
                  }}
                  className={`sidebar-link w-full ${
                    isActive ? 'sidebar-link-active' : 'sidebar-link-inactive'
                  }`}
                >
                  <Icon className="w-4.5 h-4.5" />
                  <span>{item.label}</span>
                </button>
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100">
          <p className="text-[10px] text-slate-300 text-center">
            Dholera, Gujarat
          </p>
        </div>
      </aside>
    </>
  );
}
