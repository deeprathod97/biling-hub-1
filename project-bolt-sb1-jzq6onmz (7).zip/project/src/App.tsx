import { useState } from 'react';
import Sidebar, { Page } from './components/Sidebar';
import Dashboard from './components/pages/Dashboard';
import SiteManagement from './components/pages/SiteManagement';
import TMManagement from './components/pages/TMManagement';
import GradeManagement from './components/pages/GradeManagement';
import CreateBill from './components/pages/CreateBill';
import BillList from './components/pages/BillList';
import BillPrint from './components/pages/BillPrint';
import EditBill from './components/pages/EditBill';
import CompanyProfile from './components/pages/CompanyProfile';
import TruckManagement from './components/pages/TruckManagement';
import BituminousGradeManagement from './components/pages/BituminousGradeManagement';
import AsphaltBillList from './components/pages/AsphaltBillList';
import CreateAsphaltBill from './components/pages/CreateAsphaltBill';
import EditAsphaltBill from './components/pages/EditAsphaltBill';
import RMCDailySalesReport from './components/pages/RMCDailySalesReport';
import AsphaltDailySalesReport from './components/pages/AsphaltDailySalesReport';
import { RmcBill } from './lib/types';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [printBill, setPrintBill] = useState<RmcBill | null>(null);
  const [printMode, setPrintMode] = useState<'a4' | 'slip'>('a4');
  const [editBill, setEditBill] = useState<RmcBill | null>(null);
  const [editAsphaltBillId, setEditAsphaltBillId] = useState<string | null>(null);

  function handlePrintBill(bill: RmcBill) {
    setPrintBill(bill);
    setPrintMode('a4');
  }

  function handlePrintSlip(bill: RmcBill) {
    setPrintBill(bill);
    setPrintMode('slip');
  }

  return (
    <div className="min-h-screen bg-slate-50/80">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />

      {/* Main content */}
      <main className="lg:ml-64 min-h-screen">
        <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto pt-16 lg:pt-8">
          {currentPage === 'dashboard' && <Dashboard />}

          {/* RMC Section */}
          {currentPage === 'sites' && <SiteManagement />}
          {currentPage === 'tms' && <TMManagement />}
          {currentPage === 'grades' && <GradeManagement />}
          {currentPage === 'create-bill' && (
            <CreateBill onCreated={() => setCurrentPage('bills')} />
          )}
          {currentPage === 'bills' && (
            <BillList
              onPrintBill={handlePrintBill}
              onPrintSlip={handlePrintSlip}
              onEditBill={(bill) => setEditBill(bill)}
            />
          )}
          {currentPage === 'rmc-report' && <RMCDailySalesReport />}

          {/* Asphalt Section */}
          {currentPage === 'trucks' && <TruckManagement />}
          {currentPage === 'bit-grades' && <BituminousGradeManagement />}
          {currentPage === 'create-asphalt-bill' && (
            <CreateAsphaltBill
              onCreated={() => setCurrentPage('asphalt-bills')}
              onCancel={() => setCurrentPage('asphalt-bills')}
            />
          )}
          {currentPage === 'asphalt-bills' && !editAsphaltBillId && (
            <AsphaltBillList
              onEdit={(id) => setEditAsphaltBillId(id)}
              onCreate={() => setCurrentPage('create-asphalt-bill')}
            />
          )}
          {currentPage === 'asphalt-bills' && editAsphaltBillId && (
            <EditAsphaltBill
              billId={editAsphaltBillId}
              onSaved={() => setEditAsphaltBillId(null)}
              onBack={() => setEditAsphaltBillId(null)}
            />
          )}
          {currentPage === 'asphalt-report' && <AsphaltDailySalesReport />}

          {currentPage === 'profile' && <CompanyProfile />}
        </div>
      </main>

      {/* Print modal */}
      {printBill && (
        <BillPrint
          bill={printBill}
          mode={printMode}
          onClose={() => setPrintBill(null)}
        />
      )}

      {/* Edit modal */}
      {editBill && (
        <EditBill
          bill={editBill}
          onClose={() => setEditBill(null)}
          onSaved={() => {
            setEditBill(null);
            setCurrentPage('bills');
          }}
        />
      )}
    </div>
  );
}
