export interface Site {
  id: string;
  name: string;
  site_number: string;
  location: string;
  incharge: string;
  created_at: string;
}

export interface TransitMixer {
  id: string;
  tm_number: string;
  code: string;
  wheels: number;
  created_at: string;
}

export interface ConcreteGrade {
  id: string;
  grade: string;
  price_per_mqb: number;
  carting_bhadu_per_mqb: number;
  created_at: string;
}

export interface RmcBill {
  id: string;
  bill_number: string;
  date: string;
  site_id: string;
  tm_id: string;
  grade_id: string;
  carting_bhadu: number;
  quantity_mqb: number;
  total_mqb: number;
  amount: number;
  payment_status: 'unpaid' | 'partial' | 'paid';
  created_at: string;
  site?: Site;
  tm?: TransitMixer;
  grade?: ConcreteGrade;
}

export interface Payment {
  id: string;
  bill_id: string;
  amount: number;
  payment_date: string;
  notes: string | null;
  created_at: string;
}

// Asphalt Bill Types
export interface Truck {
  id: string;
  truck_number: string;
  code: string;
  wheels: number;
  created_at: string;
}

export interface BituminousGrade {
  id: string;
  grade: string;
  price_per_tone: number;
  carting_bhadu_per_tone: number;
  created_at: string;
}

export interface AsphaltBill {
  id: string;
  bill_number: string;
  date: string;
  site_id: string;
  truck_id: string;
  grade_id: string;
  carting_bhadu: number;
  quantity_tone: number;
  total_tone: number;
  amount: number;
  payment_status: 'unpaid' | 'partial' | 'paid';
  created_at: string;
  site?: Site;
  truck?: Truck;
  grade?: BituminousGrade;
}

export interface AsphaltPayment {
  id: string;
  bill_id: string;
  amount: number;
  payment_date: string;
  notes: string | null;
  created_at: string;
}
