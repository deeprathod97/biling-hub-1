/*
  # Add adjustment column to salary_payments

  Allows manual salary adjustments (bonus or deductions).
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'salary_payments' AND column_name = 'adjustment'
  ) THEN
    ALTER TABLE salary_payments ADD COLUMN adjustment numeric(12,2) DEFAULT 0;
  END IF;
END $$;
