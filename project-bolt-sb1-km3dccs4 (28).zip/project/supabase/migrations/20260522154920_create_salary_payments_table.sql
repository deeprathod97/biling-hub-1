/*
  # Create Salary Payments Table

  ## New Table
  - `salary_payments` - Stores employee salary payment records with calculation breakdown
    - employee_id, employee_name, month, year
    - basic_salary, days_present, days_absent, days_half
    - present_amount, half_day_amount, advance_deduction, net_salary
    - paid_amount, pending_amount, payment_status
    - notes, created_at

  ## Security
  - RLS enabled with public access policies
*/

CREATE TABLE IF NOT EXISTS salary_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id),
  employee_name text NOT NULL,
  month integer NOT NULL,
  year integer NOT NULL,
  basic_salary numeric(12,2) NOT NULL DEFAULT 0,
  days_present integer NOT NULL DEFAULT 0,
  days_absent integer NOT NULL DEFAULT 0,
  days_half integer NOT NULL DEFAULT 0,
  present_amount numeric(12,2) NOT NULL DEFAULT 0,
  half_day_amount numeric(12,2) NOT NULL DEFAULT 0,
  advance_deduction numeric(12,2) NOT NULL DEFAULT 0,
  net_salary numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE salary_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on salary_payments"
  ON salary_payments FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on salary_payments"
  ON salary_payments FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on salary_payments"
  ON salary_payments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on salary_payments"
  ON salary_payments FOR DELETE TO anon, authenticated USING (true);

-- Index for efficient queries
CREATE INDEX IF NOT EXISTS idx_salary_employee_month_year ON salary_payments(employee_id, month, year);
CREATE INDEX IF NOT EXISTS idx_salary_month_year ON salary_payments(month, year);
