/*
  # Create Dumper Management Tables

  ## New Tables
  - `dumpers` - Dumper vehicles with company, model, wheel, code, site, party
  - `dumper_rates` - Rate configuration (per tone, hour, dumper, months, loads, lid)
  - `dumper_bills` - Bills with site, dumper, rate, quantity, tons, amount, payment
*/

-- Dumpers table
CREATE TABLE IF NOT EXISTS dumpers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  wheel text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  party_name text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE dumpers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on dumpers"
  ON dumpers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on dumpers"
  ON dumpers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on dumpers"
  ON dumpers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on dumpers"
  ON dumpers FOR DELETE TO anon, authenticated USING (true);

-- Dumper Rates table
CREATE TABLE IF NOT EXISTS dumper_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dumper_id uuid NOT NULL REFERENCES dumpers(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE dumper_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on dumper_rates"
  ON dumper_rates FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on dumper_rates"
  ON dumper_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on dumper_rates"
  ON dumper_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on dumper_rates"
  ON dumper_rates FOR DELETE TO anon, authenticated USING (true);

-- Dumper Bills table
CREATE TABLE IF NOT EXISTS dumper_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  dumper_id uuid NOT NULL REFERENCES dumpers(id),
  dumper_name text NOT NULL DEFAULT '',
  dumper_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  tons numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE dumper_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on dumper_bills"
  ON dumper_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on dumper_bills"
  ON dumper_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on dumper_bills"
  ON dumper_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on dumper_bills"
  ON dumper_bills FOR DELETE TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_dumper_rates_dumper ON dumper_rates(dumper_id);
CREATE INDEX IF NOT EXISTS idx_dumper_bills_site ON dumper_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_dumper_bills_dumper ON dumper_bills(dumper_id);
CREATE INDEX IF NOT EXISTS idx_dumper_bills_date ON dumper_bills(bill_date);
