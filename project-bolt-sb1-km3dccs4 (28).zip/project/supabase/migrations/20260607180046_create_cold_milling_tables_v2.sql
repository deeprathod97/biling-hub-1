CREATE TABLE IF NOT EXISTS cold_milling_machines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cold_milling_machines ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_machines' AND policyname='Allow all select on cold_milling_machines') THEN
    CREATE POLICY "Allow all select on cold_milling_machines" ON cold_milling_machines FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_machines' AND policyname='Allow all insert on cold_milling_machines') THEN
    CREATE POLICY "Allow all insert on cold_milling_machines" ON cold_milling_machines FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_machines' AND policyname='Allow all update on cold_milling_machines') THEN
    CREATE POLICY "Allow all update on cold_milling_machines" ON cold_milling_machines FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_machines' AND policyname='Allow all delete on cold_milling_machines') THEN
    CREATE POLICY "Allow all delete on cold_milling_machines" ON cold_milling_machines FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS cold_milling_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_id uuid NOT NULL REFERENCES cold_milling_machines(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cold_milling_rates ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_rates' AND policyname='Allow all select on cold_milling_rates') THEN
    CREATE POLICY "Allow all select on cold_milling_rates" ON cold_milling_rates FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_rates' AND policyname='Allow all insert on cold_milling_rates') THEN
    CREATE POLICY "Allow all insert on cold_milling_rates" ON cold_milling_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_rates' AND policyname='Allow all update on cold_milling_rates') THEN
    CREATE POLICY "Allow all update on cold_milling_rates" ON cold_milling_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_rates' AND policyname='Allow all delete on cold_milling_rates') THEN
    CREATE POLICY "Allow all delete on cold_milling_rates" ON cold_milling_rates FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS cold_milling_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  machine_id uuid NOT NULL REFERENCES cold_milling_machines(id),
  machine_name text NOT NULL DEFAULT '',
  machine_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cold_milling_bills ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_bills' AND policyname='Allow all select on cold_milling_bills') THEN
    CREATE POLICY "Allow all select on cold_milling_bills" ON cold_milling_bills FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_bills' AND policyname='Allow all insert on cold_milling_bills') THEN
    CREATE POLICY "Allow all insert on cold_milling_bills" ON cold_milling_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_bills' AND policyname='Allow all update on cold_milling_bills') THEN
    CREATE POLICY "Allow all update on cold_milling_bills" ON cold_milling_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cold_milling_bills' AND policyname='Allow all delete on cold_milling_bills') THEN
    CREATE POLICY "Allow all delete on cold_milling_bills" ON cold_milling_bills FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_cmr_rates_machine ON cold_milling_rates(machine_id);
CREATE INDEX IF NOT EXISTS idx_cmb_bills_site ON cold_milling_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_cmb_bills_machine ON cold_milling_bills(machine_id);
CREATE INDEX IF NOT EXISTS idx_cmb_bills_date ON cold_milling_bills(bill_date);
