/*
  # Create Excavator Management Tables

  ## New Tables
  - `excavators` - JCB/Excavator vehicles with company, model, code
  - `excavator_rates` - Rate configuration per excavator (per minutes, hour, dumper, months, loads, lid)
  - `excavator_bills` - Bills with site, excavator, rate config, quantity, amount, payment

  ## Security
  - RLS enabled with public access policies
*/

-- Excavators table
CREATE TABLE IF NOT EXISTS excavators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL DEFAULT 'excavator',
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE excavators ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on excavators"
  ON excavators FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on excavators"
  ON excavators FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on excavators"
  ON excavators FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on excavators"
  ON excavators FOR DELETE TO anon, authenticated USING (true);

-- Excavator Rates table
CREATE TABLE IF NOT EXISTS excavator_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  excavator_id uuid NOT NULL REFERENCES excavators(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE excavator_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on excavator_rates"
  ON excavator_rates FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on excavator_rates"
  ON excavator_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on excavator_rates"
  ON excavator_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on excavator_rates"
  ON excavator_rates FOR DELETE TO anon, authenticated USING (true);

-- Excavator Bills table
CREATE TABLE IF NOT EXISTS excavator_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  excavator_id uuid NOT NULL REFERENCES excavators(id),
  excavator_name text NOT NULL DEFAULT '',
  excavator_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE excavator_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on excavator_bills"
  ON excavator_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on excavator_bills"
  ON excavator_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on excavator_bills"
  ON excavator_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on excavator_bills"
  ON excavator_bills FOR DELETE TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_excavator_rates_excavator ON excavator_rates(excavator_id);
CREATE INDEX IF NOT EXISTS idx_excavator_bills_site ON excavator_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_excavator_bills_excavator ON excavator_bills(excavator_id);
CREATE INDEX IF NOT EXISTS idx_excavator_bills_date ON excavator_bills(bill_date);
