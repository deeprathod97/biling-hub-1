CREATE TABLE IF NOT EXISTS road_rollers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE road_rollers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on road_rollers" ON road_rollers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on road_rollers" ON road_rollers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on road_rollers" ON road_rollers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on road_rollers" ON road_rollers FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS road_roller_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  roller_id uuid NOT NULL REFERENCES road_rollers(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE road_roller_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on road_roller_rates" ON road_roller_rates FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on road_roller_rates" ON road_roller_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on road_roller_rates" ON road_roller_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on road_roller_rates" ON road_roller_rates FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS road_roller_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  roller_id uuid NOT NULL REFERENCES road_rollers(id),
  roller_name text NOT NULL DEFAULT '',
  roller_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE road_roller_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on road_roller_bills" ON road_roller_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on road_roller_bills" ON road_roller_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on road_roller_bills" ON road_roller_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on road_roller_bills" ON road_roller_bills FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_rr_rates_roller ON road_roller_rates(roller_id);
CREATE INDEX IF NOT EXISTS idx_rr_bills_site ON road_roller_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_rr_bills_roller ON road_roller_bills(roller_id);
CREATE INDEX IF NOT EXISTS idx_rr_bills_date ON road_roller_bills(bill_date);
