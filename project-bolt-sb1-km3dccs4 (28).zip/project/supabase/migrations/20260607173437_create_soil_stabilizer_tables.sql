/*
  # Create Soil Stabilizer Management Tables
*/

CREATE TABLE IF NOT EXISTS soil_stabilizers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE soil_stabilizers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on soil_stabilizers"
  ON soil_stabilizers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on soil_stabilizers"
  ON soil_stabilizers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on soil_stabilizers"
  ON soil_stabilizers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on soil_stabilizers"
  ON soil_stabilizers FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS soil_stabilizer_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  stabilizer_id uuid NOT NULL REFERENCES soil_stabilizers(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE soil_stabilizer_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on soil_stabilizer_rates"
  ON soil_stabilizer_rates FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on soil_stabilizer_rates"
  ON soil_stabilizer_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on soil_stabilizer_rates"
  ON soil_stabilizer_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on soil_stabilizer_rates"
  ON soil_stabilizer_rates FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS soil_stabilizer_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  stabilizer_id uuid NOT NULL REFERENCES soil_stabilizers(id),
  stabilizer_name text NOT NULL DEFAULT '',
  stabilizer_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE soil_stabilizer_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on soil_stabilizer_bills"
  ON soil_stabilizer_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on soil_stabilizer_bills"
  ON soil_stabilizer_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on soil_stabilizer_bills"
  ON soil_stabilizer_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on soil_stabilizer_bills"
  ON soil_stabilizer_bills FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_ss_rates_stabilizer ON soil_stabilizer_rates(stabilizer_id);
CREATE INDEX IF NOT EXISTS idx_ss_bills_site ON soil_stabilizer_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_ss_bills_stabilizer ON soil_stabilizer_bills(stabilizer_id);
CREATE INDEX IF NOT EXISTS idx_ss_bills_date ON soil_stabilizer_bills(bill_date);
