CREATE TABLE IF NOT EXISTS cranes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cranes ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cranes' AND policyname='Allow all select on cranes') THEN
    CREATE POLICY "Allow all select on cranes" ON cranes FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cranes' AND policyname='Allow all insert on cranes') THEN
    CREATE POLICY "Allow all insert on cranes" ON cranes FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cranes' AND policyname='Allow all update on cranes') THEN
    CREATE POLICY "Allow all update on cranes" ON cranes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='cranes' AND policyname='Allow all delete on cranes') THEN
    CREATE POLICY "Allow all delete on cranes" ON cranes FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS crane_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crane_id uuid NOT NULL REFERENCES cranes(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crane_rates ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_rates' AND policyname='Allow all select on crane_rates') THEN
    CREATE POLICY "Allow all select on crane_rates" ON crane_rates FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_rates' AND policyname='Allow all insert on crane_rates') THEN
    CREATE POLICY "Allow all insert on crane_rates" ON crane_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_rates' AND policyname='Allow all update on crane_rates') THEN
    CREATE POLICY "Allow all update on crane_rates" ON crane_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_rates' AND policyname='Allow all delete on crane_rates') THEN
    CREATE POLICY "Allow all delete on crane_rates" ON crane_rates FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS crane_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  crane_id uuid NOT NULL REFERENCES cranes(id),
  crane_name text NOT NULL DEFAULT '',
  crane_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crane_bills ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_bills' AND policyname='Allow all select on crane_bills') THEN
    CREATE POLICY "Allow all select on crane_bills" ON crane_bills FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_bills' AND policyname='Allow all insert on crane_bills') THEN
    CREATE POLICY "Allow all insert on crane_bills" ON crane_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_bills' AND policyname='Allow all update on crane_bills') THEN
    CREATE POLICY "Allow all update on crane_bills" ON crane_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='crane_bills' AND policyname='Allow all delete on crane_bills') THEN
    CREATE POLICY "Allow all delete on crane_bills" ON crane_bills FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_cr_rates_crane ON crane_rates(crane_id);
CREATE INDEX IF NOT EXISTS idx_cb_bills_site ON crane_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_cb_bills_crane ON crane_bills(crane_id);
CREATE INDEX IF NOT EXISTS idx_cb_bills_date ON crane_bills(bill_date);