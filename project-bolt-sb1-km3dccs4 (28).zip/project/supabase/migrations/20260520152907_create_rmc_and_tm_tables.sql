/*
  # RMC (Ready Mix Concrete) & TM (Transit Mixer) Schema

  ## New Tables
  - `tms` - Transit Mixer registry with TM number, code, wheels
  - `rmc_bills` - Ready Mix Concrete billing records with grade, quantity, carting, calculations

  ## Security
  - RLS enabled on all tables
  - Public access policies (single-org system)
*/

-- TM (Transit Mixer) table
CREATE TABLE IF NOT EXISTS tms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tm_number text NOT NULL UNIQUE,
  code text NOT NULL,
  wheels integer NOT NULL DEFAULT 6,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tms ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on tms"
  ON tms FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on tms"
  ON tms FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on tms"
  ON tms FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on tms"
  ON tms FOR DELETE TO anon, authenticated USING (true);

-- RMC Bills table
CREATE TABLE IF NOT EXISTS rmc_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL UNIQUE,
  site_id uuid REFERENCES sites(id),
  site_name text NOT NULL,
  site_number text NOT NULL,
  site_location text NOT NULL,
  site_incharge text NOT NULL,
  tm_id uuid REFERENCES tms(id),
  tm_number text NOT NULL,
  concrete_grade text NOT NULL,
  grade_rate numeric(10,2) NOT NULL DEFAULT 0,
  carting_bhada numeric(10,2) NOT NULL DEFAULT 0,
  quantity_mcb numeric(10,3) NOT NULL DEFAULT 0,
  total_mcb numeric(10,3) NOT NULL DEFAULT 0,
  total_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  payment_amount numeric(12,2) DEFAULT 0,
  payment_date timestamptz,
  payment_note text DEFAULT '',
  bill_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE rmc_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on rmc_bills"
  ON rmc_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on rmc_bills"
  ON rmc_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on rmc_bills"
  ON rmc_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on rmc_bills"
  ON rmc_bills FOR DELETE TO anon, authenticated USING (true);

-- RMC bill counter
INSERT INTO bill_counters (counter_name, last_number)
VALUES ('rmc', 0)
ON CONFLICT (counter_name) DO NOTHING;
