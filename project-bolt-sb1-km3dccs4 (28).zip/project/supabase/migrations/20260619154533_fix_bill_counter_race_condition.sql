CREATE OR REPLACE FUNCTION get_next_bill_counter(p_counter_name text)
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  v_next integer;
BEGIN
  UPDATE bill_counters SET last_number = last_number + 1 WHERE counter_name = p_counter_name RETURNING last_number INTO v_next;
  IF NOT FOUND THEN
    INSERT INTO bill_counters (counter_name, last_number) VALUES (p_counter_name, 1) RETURNING last_number INTO v_next;
  END IF;
  RETURN v_next::text;
END;
$$;