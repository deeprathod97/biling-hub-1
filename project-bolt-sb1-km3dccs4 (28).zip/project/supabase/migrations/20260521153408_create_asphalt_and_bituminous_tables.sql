/*
  # Asphalt & Bituminous Grade Schema

  ## New Tables
  - `bituminous_grades` - Bituminous grade registry with grade name, price per ton, carting bhada
  - `asphalt_bills` - Asphalt billing records with grade, quantity, truck, calculations

  ## Security
  - RLS enabled on all tables
  - Public access policies (single-org system)
*/

-- Bituminous Grades table
CREATE TABLE IF NOT EXISTS bituminous_grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grade_name text NOT NULL UNIQUE,
  price_per_ton numeric(10,2) NOT NULL DEFAULT 0,
  carting_bhada numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bituminous_grades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on bituminous_grades"
  ON bituminous_grades FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on bituminous_grades"
  ON bituminous_grades FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on bituminous_grades"
  ON bituminous_grades FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on bituminous_grades"
  ON bituminous_grades FOR DELETE TO anon, authenticated USING (true);

-- Asphalt Bills table
CREATE TABLE IF NOT EXISTS asphalt_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL UNIQUE,
  site_id uuid REFERENCES sites(id),
  site_name text NOT NULL,
  site_number text NOT NULL,
  site_location text NOT NULL,
  site_incharge text NOT NULL,
  bituminous_grade_id uuid REFERENCES bituminous_grades(id),
  grade_name text NOT NULL,
  price_per_ton numeric(10,2) NOT NULL DEFAULT 0,
  carting_bhada numeric(10,2) NOT NULL DEFAULT 0,
  truck_id uuid REFERENCES trucks(id),
  truck_number text NOT NULL,
  quantity_ton numeric(10,3) NOT NULL DEFAULT 0,
  total_ton numeric(10,3) NOT NULL DEFAULT 0,
  total_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  payment_amount numeric(12,2) DEFAULT 0,
  payment_date timestamptz,
  payment_note text DEFAULT '',
  bill_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE asphalt_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on asphalt_bills"
  ON asphalt_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on asphalt_bills"
  ON asphalt_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on asphalt_bills"
  ON asphalt_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on asphalt_bills"
  ON asphalt_bills FOR DELETE TO anon, authenticated USING (true);

-- Asphalt bill counter
INSERT INTO bill_counters (counter_name, last_number)
VALUES ('asphalt', 0)
ON CONFLICT (counter_name) DO NOTHING;
