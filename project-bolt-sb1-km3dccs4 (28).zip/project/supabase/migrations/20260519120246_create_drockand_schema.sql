/*
  # D Rock Sand Pvt Ltd - Management System Schema

  ## New Tables
  - `sites` - Construction sites with name, number, location, in-charge
  - `materials` - Material types with name, price per ton, royalty price
  - `trucks` - Truck registry with code, number, wheels
  - `aggregate_bills` - Main billing records with gross/tare/net weights, royalty info

  ## Security
  - RLS enabled on all tables
  - Public access policies for now (single-org system)
*/

-- Sites table
CREATE TABLE IF NOT EXISTS sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name text NOT NULL,
  site_number text NOT NULL UNIQUE,
  site_location text NOT NULL,
  site_incharge text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on sites"
  ON sites FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow all insert on sites"
  ON sites FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all update on sites"
  ON sites FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all delete on sites"
  ON sites FOR DELETE
  TO anon, authenticated
  USING (true);

-- Materials table
CREATE TABLE IF NOT EXISTS materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  material_name text NOT NULL,
  bhav_per_ton numeric(10,2) NOT NULL DEFAULT 0,
  royalty_bhav_per_ton numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE materials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on materials"
  ON materials FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow all insert on materials"
  ON materials FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all update on materials"
  ON materials FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all delete on materials"
  ON materials FOR DELETE
  TO anon, authenticated
  USING (true);

-- Trucks table
CREATE TABLE IF NOT EXISTS trucks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  select_code text NOT NULL,
  truck_number text NOT NULL UNIQUE,
  wheels integer NOT NULL DEFAULT 6,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trucks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on trucks"
  ON trucks FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow all insert on trucks"
  ON trucks FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all update on trucks"
  ON trucks FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all delete on trucks"
  ON trucks FOR DELETE
  TO anon, authenticated
  USING (true);

-- Aggregate bills table
CREATE TABLE IF NOT EXISTS aggregate_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL UNIQUE,
  site_id uuid REFERENCES sites(id),
  site_name text NOT NULL,
  site_number text NOT NULL,
  site_location text NOT NULL,
  site_incharge text NOT NULL,
  truck_id uuid REFERENCES trucks(id),
  truck_number text NOT NULL,
  material_id uuid REFERENCES materials(id),
  material_name text NOT NULL,
  bhav_per_ton numeric(10,2) NOT NULL DEFAULT 0,
  royalty_number text NOT NULL DEFAULT '',
  royalty_ton numeric(10,3) NOT NULL DEFAULT 0,
  gross_weight_kg numeric(12,2) NOT NULL DEFAULT 0,
  tare_weight_kg numeric(12,2) NOT NULL DEFAULT 0,
  net_weight_ton numeric(10,3) NOT NULL DEFAULT 0,
  total_amount numeric(12,2) NOT NULL DEFAULT 0,
  royalty_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  payment_amount numeric(12,2) DEFAULT 0,
  payment_date timestamptz,
  payment_note text DEFAULT '',
  bill_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE aggregate_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on aggregate_bills"
  ON aggregate_bills FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow all insert on aggregate_bills"
  ON aggregate_bills FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all update on aggregate_bills"
  ON aggregate_bills FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all delete on aggregate_bills"
  ON aggregate_bills FOR DELETE
  TO anon, authenticated
  USING (true);

-- Bill number sequence counter
CREATE TABLE IF NOT EXISTS bill_counters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  counter_name text NOT NULL UNIQUE,
  last_number integer NOT NULL DEFAULT 0
);

ALTER TABLE bill_counters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on bill_counters"
  ON bill_counters FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow all insert on bill_counters"
  ON bill_counters FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow all update on bill_counters"
  ON bill_counters FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Seed bill counter
INSERT INTO bill_counters (counter_name, last_number)
VALUES ('aggregate', 0)
ON CONFLICT (counter_name) DO NOTHING;
