/*
  # Create Motor Grader Management Tables

  ## New Tables
  - `motor_graders` - Motor grader vehicles with company, model, code
  - `motor_grader_rates` - Rate configuration (per minutes, hour, months, years)
  - `motor_grader_bills` - Bills with site, motor grader, rate, quantity, amount, payment

  ## Security
  - RLS enabled with public access policies
*/

-- Motor Graders table
CREATE TABLE IF NOT EXISTS motor_graders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE motor_graders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on motor_graders"
  ON motor_graders FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on motor_graders"
  ON motor_graders FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on motor_graders"
  ON motor_graders FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on motor_graders"
  ON motor_graders FOR DELETE TO anon, authenticated USING (true);

-- Motor Grader Rates table
CREATE TABLE IF NOT EXISTS motor_grader_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  motor_grader_id uuid NOT NULL REFERENCES motor_graders(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE motor_grader_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on motor_grader_rates"
  ON motor_grader_rates FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on motor_grader_rates"
  ON motor_grader_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on motor_grader_rates"
  ON motor_grader_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on motor_grader_rates"
  ON motor_grader_rates FOR DELETE TO anon, authenticated USING (true);

-- Motor Grader Bills table
CREATE TABLE IF NOT EXISTS motor_grader_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  motor_grader_id uuid NOT NULL REFERENCES motor_graders(id),
  motor_grader_name text NOT NULL DEFAULT '',
  motor_grader_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE motor_grader_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on motor_grader_bills"
  ON motor_grader_bills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on motor_grader_bills"
  ON motor_grader_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on motor_grader_bills"
  ON motor_grader_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on motor_grader_bills"
  ON motor_grader_bills FOR DELETE TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_mg_rates_grader ON motor_grader_rates(motor_grader_id);
CREATE INDEX IF NOT EXISTS idx_mg_bills_site ON motor_grader_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_mg_bills_grader ON motor_grader_bills(motor_grader_id);
CREATE INDEX IF NOT EXISTS idx_mg_bills_date ON motor_grader_bills(bill_date);
