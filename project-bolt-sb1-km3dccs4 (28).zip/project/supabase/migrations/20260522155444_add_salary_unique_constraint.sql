/*
  # Add unique constraint on salary_payments

  Ensures one salary record per employee per month/year.
  Allows upsert on conflict.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'salary_payments_employee_month_year_unique'
  ) THEN
    ALTER TABLE salary_payments
      ADD CONSTRAINT salary_payments_employee_month_year_unique
      UNIQUE (employee_id, month, year);
  END IF;
END $$;
