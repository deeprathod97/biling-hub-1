CREATE TABLE IF NOT EXISTS asphalt_pavers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  code text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE asphalt_pavers ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_pavers' AND policyname='Allow all select on asphalt_pavers') THEN
    CREATE POLICY "Allow all select on asphalt_pavers" ON asphalt_pavers FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_pavers' AND policyname='Allow all insert on asphalt_pavers') THEN
    CREATE POLICY "Allow all insert on asphalt_pavers" ON asphalt_pavers FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_pavers' AND policyname='Allow all update on asphalt_pavers') THEN
    CREATE POLICY "Allow all update on asphalt_pavers" ON asphalt_pavers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_pavers' AND policyname='Allow all delete on asphalt_pavers') THEN
    CREATE POLICY "Allow all delete on asphalt_pavers" ON asphalt_pavers FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS asphalt_paver_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  paver_id uuid NOT NULL REFERENCES asphalt_pavers(id),
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE asphalt_paver_rates ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_rates' AND policyname='Allow all select on asphalt_paver_rates') THEN
    CREATE POLICY "Allow all select on asphalt_paver_rates" ON asphalt_paver_rates FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_rates' AND policyname='Allow all insert on asphalt_paver_rates') THEN
    CREATE POLICY "Allow all insert on asphalt_paver_rates" ON asphalt_paver_rates FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_rates' AND policyname='Allow all update on asphalt_paver_rates') THEN
    CREATE POLICY "Allow all update on asphalt_paver_rates" ON asphalt_paver_rates FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_rates' AND policyname='Allow all delete on asphalt_paver_rates') THEN
    CREATE POLICY "Allow all delete on asphalt_paver_rates" ON asphalt_paver_rates FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS asphalt_paver_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number text NOT NULL,
  site_id uuid REFERENCES sites(id),
  site_name text DEFAULT '',
  paver_id uuid NOT NULL REFERENCES asphalt_pavers(id),
  paver_name text NOT NULL DEFAULT '',
  paver_code text DEFAULT '',
  rate_type text NOT NULL,
  rate numeric(12,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT '',
  quantity numeric(12,2) NOT NULL DEFAULT 0,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  pending_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'pending',
  bill_date date DEFAULT current_date,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE asphalt_paver_bills ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_bills' AND policyname='Allow all select on asphalt_paver_bills') THEN
    CREATE POLICY "Allow all select on asphalt_paver_bills" ON asphalt_paver_bills FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_bills' AND policyname='Allow all insert on asphalt_paver_bills') THEN
    CREATE POLICY "Allow all insert on asphalt_paver_bills" ON asphalt_paver_bills FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_bills' AND policyname='Allow all update on asphalt_paver_bills') THEN
    CREATE POLICY "Allow all update on asphalt_paver_bills" ON asphalt_paver_bills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='asphalt_paver_bills' AND policyname='Allow all delete on asphalt_paver_bills') THEN
    CREATE POLICY "Allow all delete on asphalt_paver_bills" ON asphalt_paver_bills FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_apr_rates_paver ON asphalt_paver_rates(paver_id);
CREATE INDEX IF NOT EXISTS idx_apb_bills_site ON asphalt_paver_bills(site_id);
CREATE INDEX IF NOT EXISTS idx_apb_bills_paver ON asphalt_paver_bills(paver_id);
CREATE INDEX IF NOT EXISTS idx_apb_bills_date ON asphalt_paver_bills(bill_date);