/*
  # Add unique constraint on employee_attendance

  Ensures one attendance record per employee per date.
  Required for upsert (ON CONFLICT) in bulk attendance marking.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'employee_attendance_employee_date_unique'
  ) THEN
    ALTER TABLE employee_attendance
      ADD CONSTRAINT employee_attendance_employee_date_unique
      UNIQUE (employee_id, attendance_date);
  END IF;
END $$;
