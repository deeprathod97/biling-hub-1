/*
  # Employee Management Schema

  ## New Tables
  - `employees` - Employee registry with name, mobile, address, work name, salary
  - `employee_attendance` - Daily attendance records (present/absent/half-day) with date and notes
  - `employee_advances` - Advance payment records with date, amount, and notes

  ## Security
  - RLS enabled on all tables
  - Public access policies (single-org system)
*/

-- Employees table
CREATE TABLE IF NOT EXISTS employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  mobile text NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  work_name text NOT NULL DEFAULT '',
  salary numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE employees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on employees"
  ON employees FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on employees"
  ON employees FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on employees"
  ON employees FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on employees"
  ON employees FOR DELETE TO anon, authenticated USING (true);

-- Employee Attendance table
CREATE TABLE IF NOT EXISTS employee_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id),
  employee_name text NOT NULL,
  attendance_date date NOT NULL,
  status text NOT NULL DEFAULT 'present',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE employee_attendance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on employee_attendance"
  ON employee_attendance FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on employee_attendance"
  ON employee_attendance FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on employee_attendance"
  ON employee_attendance FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on employee_attendance"
  ON employee_attendance FOR DELETE TO anon, authenticated USING (true);

-- Employee Advances table
CREATE TABLE IF NOT EXISTS employee_advances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES employees(id),
  employee_name text NOT NULL,
  advance_date date NOT NULL,
  amount numeric(10,2) NOT NULL DEFAULT 0,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE employee_advances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all select on employee_advances"
  ON employee_advances FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow all insert on employee_advances"
  ON employee_advances FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow all update on employee_advances"
  ON employee_advances FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow all delete on employee_advances"
  ON employee_advances FOR DELETE TO anon, authenticated USING (true);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON employee_attendance(employee_id, attendance_date);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON employee_attendance(attendance_date);
CREATE INDEX IF NOT EXISTS idx_advances_employee_date ON employee_advances(employee_id, advance_date);
CREATE INDEX IF NOT EXISTS idx_advances_date ON employee_advances(advance_date);
