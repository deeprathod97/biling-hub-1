import type { AggregateBill } from '../lib/supabase';

interface Props {
  bill: AggregateBill;
}

export default function BillPrint({ bill }: Props) {
  const billDate = new Date(bill.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', width: '100%', maxWidth: '794px', background: 'white', padding: '32px', color: '#000', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '12px', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '16px', marginBottom: '6px', flexWrap: 'wrap' }}>
          <img
            src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg"
            alt="Logo"
            style={{ width: '60px', height: '60px', objectFit: 'cover', borderRadius: '8px' }}
          />
          <div>
            <div style={{ fontSize: '22px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
            <div style={{ fontSize: '12px', marginTop: '2px' }}>Aggregate & Sand Supplier | Sayla, Gujarat</div>
            <div style={{ fontSize: '11px', color: '#555' }}>GST No: 7EGH5HFN0401Z</div>
          </div>
        </div>
        <div style={{ fontSize: '16px', fontWeight: 'bold', marginTop: '8px', letterSpacing: '2px' }}>AGGREGATE BILL</div>
      </div>

      {/* Bill Info */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', fontSize: '12px', flexWrap: 'wrap', gap: '8px' }}>
        <div>
          <strong>Bill No:</strong> {bill.bill_number}<br />
          <strong>Date:</strong> {billDate}
        </div>
        <div style={{ textAlign: 'right' }}>
          <strong>Royalty No:</strong> {bill.royalty_number || 'N/A'}<br />
          <strong>Payment Status:</strong> {bill.payment_status.toUpperCase()}
        </div>
      </div>

      {/* Site & Truck */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '16px', fontSize: '12px' }}>
        <thead>
          <tr style={{ background: '#000', color: '#fff' }}>
            <th style={{ padding: '6px 10px', textAlign: 'left', width: '50%' }}>SITE DETAILS</th>
            <th style={{ padding: '6px 10px', textAlign: 'left', width: '50%' }}>TRUCK DETAILS</th>
          </tr>
        </thead>
        <tbody>
          <tr style={{ borderBottom: '1px solid #ddd' }}>
            <td style={{ padding: '6px 10px', verticalAlign: 'top' }}>
              <strong>Site Name:</strong> {bill.site_name}<br />
              <strong>Site No:</strong> {bill.site_number}<br />
              <strong>Location:</strong> {bill.site_location}<br />
              <strong>In-Charge:</strong> {bill.site_incharge}
            </td>
            <td style={{ padding: '6px 10px', verticalAlign: 'top' }}>
              <strong>Truck No:</strong> {bill.truck_number}<br />
              <strong>Material:</strong> {bill.material_name}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Weight Details */}
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '16px', fontSize: '12px', minWidth: '300px' }}>
          <thead>
            <tr style={{ background: '#000', color: '#fff' }}>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>GROSS WT (KG)</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>TARE WT (KG)</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>NET WT (KG)</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>NET WT (TON)</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: '2px solid #000' }}>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '14px' }}>{Number(bill.gross_weight_kg).toFixed(0)}</td>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '14px' }}>{Number(bill.tare_weight_kg).toFixed(0)}</td>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '14px' }}>{(Number(bill.gross_weight_kg) - Number(bill.tare_weight_kg)).toFixed(0)}</td>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '16px' }}>{Number(bill.net_weight_ton).toFixed(3)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Amount Calculation */}
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '24px', fontSize: '12px', minWidth: '300px' }}>
          <thead>
            <tr style={{ background: '#000', color: '#fff' }}>
              <th style={{ padding: '6px 10px', textAlign: 'left' }}>DESCRIPTION</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>TON</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>RATE (Rs./Ton)</th>
              <th style={{ padding: '6px 10px', textAlign: 'right' }}>AMOUNT (Rs.)</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '6px 10px' }}>{bill.material_name}</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.net_weight_ton).toFixed(3)}</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.bhav_per_ton).toFixed(2)}</td>
              <td style={{ padding: '6px 10px', textAlign: 'right' }}>{Number(bill.total_amount).toFixed(2)}</td>
            </tr>
            <tr style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '6px 10px' }}>Royalty (No: {bill.royalty_number || 'N/A'})</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.royalty_ton).toFixed(3)}</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>-</td>
              <td style={{ padding: '6px 10px', textAlign: 'right' }}>{Number(bill.royalty_amount).toFixed(2)}</td>
            </tr>
            <tr style={{ background: '#f0f0f0' }}>
              <td colSpan={3} style={{ padding: '8px 10px', fontWeight: 'bold', fontSize: '13px' }}>TOTAL AMOUNT</td>
              <td style={{ padding: '8px 10px', textAlign: 'right', fontWeight: 'bold', fontSize: '16px' }}>
                Rs. {Number(bill.total_amount).toFixed(2)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Signatures */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '48px', fontSize: '12px', flexWrap: 'wrap', gap: '12px' }}>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>
          Prepared By
        </div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>
          Checked By
        </div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>
          Authorized Signatory
        </div>
      </div>

      {/* Footer */}
      <div style={{ marginTop: '24px', borderTop: '1px solid #000', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
        D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod
      </div>
    </div>
  );
}
