import type { RMCBill } from '../lib/supabase';

interface Props {
  bill: RMCBill;
}

export default function RMCSlipPrint({ bill }: Props) {
  const billDate = new Date(bill.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const gradeAmount = Number(bill.grade_rate) * Number(bill.quantity_mcb);
  const cartingAmount = Number(bill.carting_bhada) * Number(bill.quantity_mcb);

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', width: '100%', maxWidth: '380px', background: 'white', padding: '16px', color: '#000', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '8px', marginBottom: '10px' }}>
        <div style={{ fontSize: '14px', fontWeight: 'bold' }}>D ROCK SAND PVT LTD</div>
        <div style={{ fontSize: '10px' }}>Sayla, Gujarat | GST: 7EGH5HFN0401Z</div>
        <div style={{ fontSize: '12px', fontWeight: 'bold', marginTop: '4px', letterSpacing: '1px' }}>RMC DELIVERY SLIP</div>
      </div>

      {/* Bill Details */}
      <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse', marginBottom: '8px' }}>
        <tbody>
          <SlipRow label="Bill No" value={bill.bill_number} />
          <SlipRow label="Date" value={billDate} />
          <SlipRow label="TM No" value={bill.tm_number} />
          <SlipRow label="Site" value={`${bill.site_name} (${bill.site_number})`} />
          <SlipRow label="Location" value={bill.site_location} />
          <SlipRow label="In-Charge" value={bill.site_incharge} />
          <SlipRow label="Grade" value={bill.concrete_grade} />
        </tbody>
      </table>

      {/* Quantity Box */}
      <div style={{ border: '2px solid #000', borderRadius: '4px', padding: '8px', marginBottom: '8px' }}>
        <div style={{ textAlign: 'center', marginBottom: '4px' }}>
          <span style={{ fontSize: '11px' }}>Concrete Grade: </span>
          <span style={{ fontSize: '14px', fontWeight: 'bold' }}>{bill.concrete_grade}</span>
        </div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px' }}>
          <span style={{ fontSize: '11px' }}>Quantity: </span>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>{Number(bill.quantity_mcb).toFixed(3)} MCB</span>
        </div>
      </div>

      {/* Amount */}
      <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse' }}>
        <tbody>
          <SlipRow label="Grade Rate" value={`Rs. ${Number(bill.grade_rate).toFixed(2)}/MCB`} />
          <SlipRow label="Grade Amount" value={`Rs. ${gradeAmount.toFixed(2)}`} />
          <SlipRow label="Carting Bhada" value={`Rs. ${Number(bill.carting_bhada).toFixed(2)}/MCB`} />
          <SlipRow label="Carting Amount" value={`Rs. ${cartingAmount.toFixed(2)}`} />
          <SlipRow label="Total Amount" value={`Rs. ${Number(bill.total_amount).toFixed(2)}`} bold />
        </tbody>
      </table>

      {/* Footer */}
      <div style={{ borderTop: '1px dashed #000', marginTop: '10px', paddingTop: '8px', textAlign: 'center', fontSize: '10px' }}>
        <div style={{ marginBottom: '16px' }}>Signature: ________________</div>
        D Rock Sand Pvt Ltd — Thank You
      </div>
    </div>
  );
}

function SlipRow({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <tr style={{ borderBottom: '1px dotted #ddd' }}>
      <td style={{ padding: '3px 0', color: '#555', width: '45%' }}>{label}</td>
      <td style={{ padding: '3px 0', fontWeight: bold ? 'bold' : 'normal' }}>: {value}</td>
    </tr>
  );
}
