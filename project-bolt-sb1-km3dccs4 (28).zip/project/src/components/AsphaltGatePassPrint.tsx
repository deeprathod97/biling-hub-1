import type { AsphaltBill } from '../lib/supabase';

interface Props {
  bill: AsphaltBill;
}

export default function AsphaltGatePassPrint({ bill }: Props) {
  const billDate = new Date(bill.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', width: '100%', maxWidth: '794px', background: 'white', padding: '32px', color: '#000', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', borderBottom: '3px double #000', paddingBottom: '12px', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '16px', marginBottom: '6px', flexWrap: 'wrap' }}>
          <img
            src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg"
            alt="Logo"
            style={{ width: '60px', height: '60px', objectFit: 'cover', borderRadius: '8px' }}
          />
          <div>
            <div style={{ fontSize: '22px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
            <div style={{ fontSize: '12px', marginTop: '2px' }}>Asphalt & Bituminous Supplier | Sayla, Gujarat</div>
            <div style={{ fontSize: '11px', color: '#555' }}>GST No: 7EGH5HFN0401Z</div>
          </div>
        </div>
        <div style={{ fontSize: '18px', fontWeight: 'bold', marginTop: '10px', letterSpacing: '3px', border: '2px solid #000', display: 'inline-block', padding: '4px 24px' }}>GATE PASS</div>
      </div>

      {/* Gate Pass Info */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', fontSize: '13px', flexWrap: 'wrap', gap: '8px' }}>
        <div>
          <strong>Gate Pass No:</strong> GP-{bill.bill_number}<br />
          <strong>Date:</strong> {billDate}
        </div>
        <div style={{ textAlign: 'right' }}>
          <strong>Bill No:</strong> {bill.bill_number}
        </div>
      </div>

      {/* Delivery Details */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px', fontSize: '12px' }}>
        <thead>
          <tr style={{ background: '#000', color: '#fff' }}>
            <th style={{ padding: '8px 10px', textAlign: 'left' }} colSpan={2}>DELIVERY DETAILS</th>
          </tr>
        </thead>
        <tbody>
          <tr style={{ borderBottom: '1px solid #ddd' }}>
            <td style={{ padding: '8px 10px', width: '50%', verticalAlign: 'top' }}>
              <strong>Site Name:</strong> {bill.site_name}<br />
              <strong>Site No:</strong> {bill.site_number}<br />
              <strong>Location:</strong> {bill.site_location}<br />
              <strong>Site In-Charge:</strong> {bill.site_incharge}
            </td>
            <td style={{ padding: '8px 10px', width: '50%', verticalAlign: 'top' }}>
              <strong>Truck No:</strong> {bill.truck_number}<br />
              <strong>Bituminous Grade:</strong> {bill.grade_name}<br />
              <strong>Quantity:</strong> {Number(bill.quantity_ton).toFixed(3)} Ton
            </td>
          </tr>
        </tbody>
      </table>

      {/* Material Box */}
      <div style={{ border: '3px solid #000', borderRadius: '4px', padding: '16px', marginBottom: '20px', textAlign: 'center' }}>
        <p style={{ fontSize: '12px', color: '#555', marginBottom: '4px' }}>MATERIAL</p>
        <p style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '8px' }}>Bituminous {bill.grade_name}</p>
        <div style={{ borderTop: '1px solid #000', paddingTop: '8px' }}>
          <p style={{ fontSize: '12px', color: '#555' }}>QUANTITY</p>
          <p style={{ fontSize: '28px', fontWeight: 'bold' }}>{Number(bill.quantity_ton).toFixed(3)} TON</p>
        </div>
      </div>

      {/* Authorization */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '32px', fontSize: '12px', flexWrap: 'wrap', gap: '12px' }}>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>Driver Signature</div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>Security Check</div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>Authorized By</div>
      </div>

      {/* Footer */}
      <div style={{ marginTop: '24px', borderTop: '1px solid #000', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
        D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | This gate pass must be carried during transit
      </div>
    </div>
  );
}
