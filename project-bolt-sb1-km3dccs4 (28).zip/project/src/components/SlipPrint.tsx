import type { AggregateBill } from '../lib/supabase';

interface Props {
  bill: AggregateBill;
}

export default function SlipPrint({ bill }: Props) {
  const billDate = new Date(bill.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', width: '100%', maxWidth: '380px', background: 'white', padding: '16px', color: '#000', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '8px', marginBottom: '10px' }}>
        <div style={{ fontSize: '14px', fontWeight: 'bold' }}>D ROCK SAND PVT LTD</div>
        <div style={{ fontSize: '10px' }}>Sayla, Gujarat | GST: 7EGH5HFN0401Z</div>
        <div style={{ fontSize: '12px', fontWeight: 'bold', marginTop: '4px', letterSpacing: '1px' }}>WEIGHING SLIP</div>
      </div>

      {/* Bill Details */}
      <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse', marginBottom: '8px' }}>
        <tbody>
          <SlipRow label="Bill No" value={bill.bill_number} />
          <SlipRow label="Date" value={billDate} />
          <SlipRow label="Truck No" value={bill.truck_number} />
          <SlipRow label="Site" value={`${bill.site_name} (${bill.site_number})`} />
          <SlipRow label="Location" value={bill.site_location} />
          <SlipRow label="In-Charge" value={bill.site_incharge} />
          <SlipRow label="Material" value={bill.material_name} />
          <SlipRow label="Royalty No" value={bill.royalty_number || 'N/A'} />
        </tbody>
      </table>

      {/* Weight Box */}
      <div style={{ border: '2px solid #000', borderRadius: '4px', padding: '8px', marginBottom: '8px' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #000' }}>
                <th style={{ textAlign: 'left', paddingBottom: '4px' }}>Gross (kg)</th>
                <th style={{ textAlign: 'center', paddingBottom: '4px' }}>Tare (kg)</th>
                <th style={{ textAlign: 'right', paddingBottom: '4px' }}>Net (kg)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ paddingTop: '4px', fontWeight: 'bold' }}>{Number(bill.gross_weight_kg).toFixed(0)}</td>
                <td style={{ paddingTop: '4px', fontWeight: 'bold', textAlign: 'center' }}>{Number(bill.tare_weight_kg).toFixed(0)}</td>
                <td style={{ paddingTop: '4px', fontWeight: 'bold', textAlign: 'right' }}>{(Number(bill.gross_weight_kg) - Number(bill.tare_weight_kg)).toFixed(0)}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div style={{ borderTop: '1px solid #000', marginTop: '6px', paddingTop: '6px', textAlign: 'center' }}>
          <span style={{ fontSize: '11px' }}>Net Weight: </span>
          <span style={{ fontSize: '16px', fontWeight: 'bold' }}>{Number(bill.net_weight_ton).toFixed(3)} TON</span>
        </div>
      </div>

      {/* Amount */}
      <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse' }}>
        <tbody>
          <SlipRow label="Rate/Ton" value={`Rs. ${Number(bill.bhav_per_ton).toFixed(2)}`} />
          <SlipRow label="Total Amount" value={`Rs. ${Number(bill.total_amount).toFixed(2)}`} bold />
          <SlipRow label="Royalty Amount" value={`Rs. ${Number(bill.royalty_amount).toFixed(2)}`} />
        </tbody>
      </table>

      {/* Footer */}
      <div style={{ borderTop: '1px dashed #000', marginTop: '10px', paddingTop: '8px', textAlign: 'center', fontSize: '10px' }}>
        <div style={{ marginBottom: '16px' }}>Signature: ________________</div>
        D Rock Sand Pvt Ltd — Thank You
      </div>
    </div>
  );
}

function SlipRow({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <tr style={{ borderBottom: '1px dotted #ddd' }}>
      <td style={{ padding: '3px 0', color: '#555', width: '45%' }}>{label}</td>
      <td style={{ padding: '3px 0', fontWeight: bold ? 'bold' : 'normal' }}>: {value}</td>
    </tr>
  );
}
