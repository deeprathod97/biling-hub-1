import { useState } from 'react';
import {
  LayoutDashboard,
  FileText,
  MapPin,
  Package,
  Truck,
  User,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  BarChart3,
  Construction,
  Layers,
  Users,
  CalendarCheck,
  IndianRupee,
  Calculator,
  Settings,
  Grip,
  Disc,
  Wrench,
} from 'lucide-react';

type Page =
  | 'profile'
  | 'aggregate-new'
  | 'aggregate-dashboard'
  | 'daily-sales'
  | 'rmc-new'
  | 'rmc-dashboard'
  | 'rmc-daily-sales'
  | 'asphalt-new'
  | 'asphalt-dashboard'
  | 'asphalt-daily-sales'
  | 'sites'
  | 'materials'
  | 'trucks'
  | 'tms'
  | 'bituminous-grades'
  | 'employees'
  | 'employee-attendance'
  | 'employee-advances'
  | 'salary'
  | 'excavators'
  | 'excavator-rates'
  | 'excavator-bill-new'
  | 'excavator-dashboard'
  | 'motor-graders'
  | 'motor-grader-rates'
  | 'motor-grader-bill-new'
  | 'motor-grader-dashboard'
  | 'dumpers'
  | 'dumper-rates'
  | 'dumper-bill-new'
  | 'dumper-dashboard'
  | 'soil-stabilizers'
  | 'soil-stabilizer-rates'
  | 'soil-stabilizer-bill-new'
  | 'soil-stabilizer-dashboard'
  | 'road-rollers'
  | 'road-roller-rates'
  | 'road-roller-bill-new'
  | 'road-roller-dashboard'
  | 'cold-milling-machines'
  | 'cold-milling-rates'
  | 'cold-milling-bill-new'
  | 'cold-milling-dashboard'
  | 'asphalt-pavers'
  | 'asphalt-paver-rates'
  | 'asphalt-paver-bill-new'
  | 'asphalt-paver-dashboard'
  | 'cranes'
  | 'crane-rates'
  | 'crane-bill-new'
  | 'crane-dashboard';

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const navItems: { label: string; page: Page; icon: React.ElementType }[] = [
  { label: 'Profile', page: 'profile', icon: User },
  // Aggregate section
  { label: 'New Bill', page: 'aggregate-new', icon: FileText },
  { label: 'Bill Dashboard', page: 'aggregate-dashboard', icon: LayoutDashboard },
  { label: 'Daily Sales', page: 'daily-sales', icon: BarChart3 },
  // RMC section
  { label: 'New RMC Bill', page: 'rmc-new', icon: Construction },
  { label: 'RMC Dashboard', page: 'rmc-dashboard', icon: LayoutDashboard },
  { label: 'RMC Daily Sales', page: 'rmc-daily-sales', icon: BarChart3 },
  // Asphalt section
  { label: 'New Asphalt Bill', page: 'asphalt-new', icon: FileText },
  { label: 'Asphalt Dashboard', page: 'asphalt-dashboard', icon: LayoutDashboard },
  { label: 'Asphalt Daily Sales', page: 'asphalt-daily-sales', icon: BarChart3 },
  // Master data
  { label: 'Sites', page: 'sites', icon: MapPin },
  { label: 'Materials', page: 'materials', icon: Package },
  { label: 'Trucks', page: 'trucks', icon: Truck },
  { label: 'Transit Mixers', page: 'tms', icon: Truck },
  { label: 'Bituminous Grades', page: 'bituminous-grades', icon: Layers },
  // Employee section
  { label: 'Employees', page: 'employees', icon: Users },
  { label: 'Attendance', page: 'employee-attendance', icon: CalendarCheck },
  { label: 'Advances', page: 'employee-advances', icon: IndianRupee },
  { label: 'Salary', page: 'salary', icon: Calculator },
  // Excavator section
  { label: 'Excavators', page: 'excavators', icon: Truck },
  { label: 'Excavator Rates', page: 'excavator-rates', icon: Settings },
  { label: 'New Excavator Bill', page: 'excavator-bill-new', icon: FileText },
  { label: 'Excavator Bills', page: 'excavator-dashboard', icon: LayoutDashboard },
  // Motor Grader section
  { label: 'Motor Graders', page: 'motor-graders', icon: Grip },
  { label: 'MG Rates', page: 'motor-grader-rates', icon: Settings },
  { label: 'New MG Bill', page: 'motor-grader-bill-new', icon: FileText },
  { label: 'MG Bills', page: 'motor-grader-dashboard', icon: LayoutDashboard },
  // Dumper section
  { label: 'Dumpers', page: 'dumpers', icon: Truck },
  { label: 'Dumper Rates', page: 'dumper-rates', icon: Settings },
  { label: 'New Dumper Bill', page: 'dumper-bill-new', icon: FileText },
  { label: 'Dumper Bills', page: 'dumper-dashboard', icon: LayoutDashboard },
  // Soil Stabilizer section
  { label: 'Soil Stabilizers', page: 'soil-stabilizers', icon: Layers },
  { label: 'SS Rates', page: 'soil-stabilizer-rates', icon: Settings },
  { label: 'New SS Bill', page: 'soil-stabilizer-bill-new', icon: FileText },
  { label: 'SS Bills', page: 'soil-stabilizer-dashboard', icon: LayoutDashboard },
  // Road Roller section
  { label: 'Road Rollers', page: 'road-rollers', icon: Disc },
  { label: 'RR Rates', page: 'road-roller-rates', icon: Settings },
  { label: 'New RR Bill', page: 'road-roller-bill-new', icon: FileText },
  { label: 'RR Bills', page: 'road-roller-dashboard', icon: LayoutDashboard },
  // Cold Milling Machine section
  { label: 'Cold Milling', page: 'cold-milling-machines', icon: Wrench },
  { label: 'CMM Rates', page: 'cold-milling-rates', icon: Settings },
  { label: 'New CMM Bill', page: 'cold-milling-bill-new', icon: FileText },
  { label: 'CMM Bills', page: 'cold-milling-dashboard', icon: LayoutDashboard },
  // Asphalt Paver section
  { label: 'Asphalt Pavers', page: 'asphalt-pavers', icon: Construction },
  { label: 'AP Rates', page: 'asphalt-paver-rates', icon: Settings },
  { label: 'New AP Bill', page: 'asphalt-paver-bill-new', icon: FileText },
  { label: 'AP Bills', page: 'asphalt-paver-dashboard', icon: LayoutDashboard },
  // Crane section
  { label: 'Cranes', page: 'cranes', icon: Construction },
  { label: 'Crane Rates', page: 'crane-rates', icon: Settings },
  { label: 'New Crane Bill', page: 'crane-bill-new', icon: FileText },
  { label: 'Crane Bills', page: 'crane-dashboard', icon: LayoutDashboard },
];

function NavItem({ label, page, icon: Icon, active, collapsed, onNavigate, onClose }: {
  label: string; page: Page; icon: React.ElementType; active: boolean; collapsed: boolean;
  onNavigate: (page: Page) => void; onClose: () => void;
}) {
  return (
    <button
      onClick={() => { onNavigate(page); onClose(); }}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 group mb-0.5 ${
        active ? 'bg-gray-900 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
      }`}
    >
      <Icon size={18} className={`flex-shrink-0 transition-transform duration-200 group-hover:scale-110 ${active ? 'text-white' : 'text-gray-500'}`} />
      {!collapsed && <span className="truncate">{label}</span>}
    </button>
  );
}

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-4 py-5 border-b border-gray-200">
        <img
          src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg"
          alt="D Rock Sand"
          className="w-10 h-10 rounded-full object-cover border-2 border-gray-300 flex-shrink-0"
        />
        {!collapsed && (
          <div className="overflow-hidden">
            <p className="text-xs font-bold text-gray-900 leading-tight truncate">D ROCK SAND</p>
            <p className="text-xs text-gray-500 truncate">PVT LTD</p>
          </div>
        )}
      </div>

      <nav className="flex-1 py-4 px-2 overflow-y-auto">
        {!collapsed && <p className="px-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">General</p>}
        {navItems.slice(0, 1).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Aggregate</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(1, 4).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Ready Mix Concrete</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(4, 7).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Asphalt</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(7, 10).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Master Data</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(10, 15).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Employee</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(15, 19).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Excavator</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(19, 23).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Motor Grader</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(23, 27).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Dumper</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(27, 31).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Soil Stabilizer</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(31, 35).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Road Roller</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(35, 39).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Cold Milling</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(39, 43).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Asphalt Paver</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(43, 47).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
        {!collapsed && <p className="px-3 mt-3 mb-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Crane</p>}
        {collapsed && <div className="my-2 border-t border-gray-100" />}
        {navItems.slice(47).map(({ label, page, icon: Icon }) => (
          <NavItem key={page} label={label} page={page} icon={Icon} active={currentPage === page} collapsed={collapsed} onNavigate={onNavigate} onClose={() => setMobileOpen(false)} />
        ))}
      </nav>

      <div className="p-2 border-t border-gray-200">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-colors duration-200 hidden md:flex"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile toggle button */}
      <button
        onClick={() => setMobileOpen(true)}
        className="md:hidden fixed top-4 left-4 z-50 bg-white border border-gray-200 rounded-lg p-2 shadow-md"
      >
        <Menu size={20} />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/40 z-40 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile drawer */}
      <div
        className={`md:hidden fixed left-0 top-0 h-full w-64 bg-white z-50 shadow-2xl transform transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <button
          onClick={() => setMobileOpen(false)}
          className="absolute top-4 right-4 p-1 rounded-lg text-gray-400 hover:text-gray-700"
        >
          <X size={20} />
        </button>
        <NavContent />
      </div>

      {/* Desktop sidebar */}
      <aside
        className={`hidden md:flex flex-col h-screen bg-white border-r border-gray-200 transition-all duration-300 ease-in-out ${
          collapsed ? 'w-16' : 'w-56'
        } flex-shrink-0`}
      >
        <NavContent />
      </aside>
    </>
  );
}
