import type { RMCBill } from '../lib/supabase';

interface Props {
  bill: RMCBill;
}

export default function RMCBillPrint({ bill }: Props) {
  const billDate = new Date(bill.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const gradeAmount = Number(bill.grade_rate) * Number(bill.quantity_mcb);
  const cartingAmount = Number(bill.carting_bhada) * Number(bill.quantity_mcb);

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', width: '100%', maxWidth: '794px', background: 'white', padding: '32px', color: '#000', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '12px', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '16px', marginBottom: '6px', flexWrap: 'wrap' }}>
          <img
            src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg"
            alt="Logo"
            style={{ width: '60px', height: '60px', objectFit: 'cover', borderRadius: '8px' }}
          />
          <div>
            <div style={{ fontSize: '22px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
            <div style={{ fontSize: '12px', marginTop: '2px' }}>Ready Mix Concrete Supplier | Sayla, Gujarat</div>
            <div style={{ fontSize: '11px', color: '#555' }}>GST No: 7EGH5HFN0401Z</div>
          </div>
        </div>
        <div style={{ fontSize: '16px', fontWeight: 'bold', marginTop: '8px', letterSpacing: '2px' }}>READY MIX CONCRETE BILL</div>
      </div>

      {/* Bill Info */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', fontSize: '12px', flexWrap: 'wrap', gap: '8px' }}>
        <div>
          <strong>Bill No:</strong> {bill.bill_number}<br />
          <strong>Date:</strong> {billDate}
        </div>
        <div style={{ textAlign: 'right' }}>
          <strong>Payment Status:</strong> {bill.payment_status.toUpperCase()}
        </div>
      </div>

      {/* Site & TM */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '16px', fontSize: '12px' }}>
        <thead>
          <tr style={{ background: '#000', color: '#fff' }}>
            <th style={{ padding: '6px 10px', textAlign: 'left', width: '50%' }}>SITE DETAILS</th>
            <th style={{ padding: '6px 10px', textAlign: 'left', width: '50%' }}>TM DETAILS</th>
          </tr>
        </thead>
        <tbody>
          <tr style={{ borderBottom: '1px solid #ddd' }}>
            <td style={{ padding: '6px 10px', verticalAlign: 'top' }}>
              <strong>Site Name:</strong> {bill.site_name}<br />
              <strong>Site No:</strong> {bill.site_number}<br />
              <strong>Location:</strong> {bill.site_location}<br />
              <strong>In-Charge:</strong> {bill.site_incharge}
            </td>
            <td style={{ padding: '6px 10px', verticalAlign: 'top' }}>
              <strong>TM Number:</strong> {bill.tm_number}<br />
              <strong>Concrete Grade:</strong> {bill.concrete_grade}
            </td>
          </tr>
        </tbody>
      </table>

      {/* Concrete Details */}
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '16px', fontSize: '12px', minWidth: '300px' }}>
          <thead>
            <tr style={{ background: '#000', color: '#fff' }}>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>CONCRETE GRADE</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>RATE (Rs./MCB)</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>QUANTITY (MCB)</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>TOTAL MCB</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: '2px solid #000' }}>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '14px' }}>{bill.concrete_grade}</td>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '14px' }}>{Number(bill.grade_rate).toFixed(2)}</td>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '14px' }}>{Number(bill.quantity_mcb).toFixed(3)}</td>
              <td style={{ padding: '8px 10px', textAlign: 'center', fontWeight: 'bold', fontSize: '16px' }}>{Number(bill.total_mcb).toFixed(3)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Amount Calculation */}
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '24px', fontSize: '12px', minWidth: '300px' }}>
          <thead>
            <tr style={{ background: '#000', color: '#fff' }}>
              <th style={{ padding: '6px 10px', textAlign: 'left' }}>DESCRIPTION</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>MCB</th>
              <th style={{ padding: '6px 10px', textAlign: 'center' }}>RATE (Rs.)</th>
              <th style={{ padding: '6px 10px', textAlign: 'right' }}>AMOUNT (Rs.)</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '6px 10px' }}>Concrete {bill.concrete_grade}</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.quantity_mcb).toFixed(3)}</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.grade_rate).toFixed(2)}/MCB</td>
              <td style={{ padding: '6px 10px', textAlign: 'right' }}>{gradeAmount.toFixed(2)}</td>
            </tr>
            <tr style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '6px 10px' }}>Carting Bhada</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.quantity_mcb).toFixed(3)}</td>
              <td style={{ padding: '6px 10px', textAlign: 'center' }}>{Number(bill.carting_bhada).toFixed(2)}/MCB</td>
              <td style={{ padding: '6px 10px', textAlign: 'right' }}>{cartingAmount.toFixed(2)}</td>
            </tr>
            <tr style={{ background: '#f0f0f0' }}>
              <td colSpan={3} style={{ padding: '8px 10px', fontWeight: 'bold', fontSize: '13px' }}>TOTAL AMOUNT</td>
              <td style={{ padding: '8px 10px', textAlign: 'right', fontWeight: 'bold', fontSize: '16px' }}>
                Rs. {Number(bill.total_amount).toFixed(2)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Signatures */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '48px', fontSize: '12px', flexWrap: 'wrap', gap: '12px' }}>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>Prepared By</div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>Checked By</div>
        <div style={{ textAlign: 'center', borderTop: '1px solid #000', paddingTop: '6px', width: '180px' }}>Authorized Signatory</div>
      </div>

      {/* Footer */}
      <div style={{ marginTop: '24px', borderTop: '1px solid #000', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
        D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod
      </div>
    </div>
  );
}
