import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Site = {
  id: string;
  site_name: string;
  site_number: string;
  site_location: string;
  site_incharge: string;
  created_at: string;
};

export type Material = {
  id: string;
  material_name: string;
  bhav_per_ton: number;
  royalty_bhav_per_ton: number;
  created_at: string;
};

export type Truck = {
  id: string;
  select_code: string;
  truck_number: string;
  wheels: number;
  created_at: string;
};

export type AggregateBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  site_number: string;
  site_location: string;
  site_incharge: string;
  truck_id: string;
  truck_number: string;
  material_id: string;
  material_name: string;
  bhav_per_ton: number;
  royalty_number: string;
  royalty_ton: number;
  gross_weight_kg: number;
  tare_weight_kg: number;
  net_weight_ton: number;
  total_amount: number;
  royalty_amount: number;
  payment_status: string;
  payment_amount: number;
  payment_date: string | null;
  payment_note: string;
  bill_date: string;
  created_at: string;
  updated_at: string;
};

export type TM = {
  id: string;
  tm_number: string;
  code: string;
  wheels: number;
  created_at: string;
};

export type RMCBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  site_number: string;
  site_location: string;
  site_incharge: string;
  tm_id: string;
  tm_number: string;
  concrete_grade: string;
  grade_rate: number;
  carting_bhada: number;
  quantity_mcb: number;
  total_mcb: number;
  total_amount: number;
  payment_status: string;
  payment_amount: number;
  payment_date: string | null;
  payment_note: string;
  bill_date: string;
  created_at: string;
  updated_at: string;
};

export type BituminousGrade = {
  id: string;
  grade_name: string;
  price_per_ton: number;
  carting_bhada: number;
  created_at: string;
};

export type AsphaltBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  site_number: string;
  site_location: string;
  site_incharge: string;
  bituminous_grade_id: string;
  grade_name: string;
  price_per_ton: number;
  carting_bhada: number;
  truck_id: string;
  truck_number: string;
  quantity_ton: number;
  total_ton: number;
  total_amount: number;
  payment_status: string;
  payment_amount: number;
  payment_date: string | null;
  payment_note: string;
  bill_date: string;
  created_at: string;
  updated_at: string;
};

export type Employee = {
  id: string;
  name: string;
  mobile: string;
  address: string;
  work_name: string;
  salary: number;
  created_at: string;
};

export type EmployeeAttendance = {
  id: string;
  employee_id: string;
  employee_name: string;
  attendance_date: string;
  status: string;
  notes: string;
  created_at: string;
};

export type EmployeeAdvance = {
  id: string;
  employee_id: string;
  employee_name: string;
  advance_date: string;
  amount: number;
  notes: string;
  created_at: string;
};

export type SalaryPayment = {
  id: string;
  employee_id: string;
  employee_name: string;
  month: number;
  year: number;
  basic_salary: number;
  days_present: number;
  days_absent: number;
  days_half: number;
  present_amount: number;
  half_day_amount: number;
  advance_deduction: number;
  adjustment: number;
  net_salary: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  notes: string;
  created_at: string;
};

export type Excavator = {
  id: string;
  type: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type ExcavatorRate = {
  id: string;
  excavator_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type ExcavatorBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  excavator_id: string;
  excavator_name: string;
  excavator_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type MotorGrader = {
  id: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type MotorGraderRate = {
  id: string;
  motor_grader_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type MotorGraderBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  motor_grader_id: string;
  motor_grader_name: string;
  motor_grader_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type Dumper = {
  id: string;
  company_name: string;
  model: string;
  wheel: string;
  code: string;
  site_id: string;
  site_name: string;
  party_name: string;
  created_at: string;
};

export type DumperRate = {
  id: string;
  dumper_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type DumperBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  dumper_id: string;
  dumper_name: string;
  dumper_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  tons: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type SoilStabilizer = {
  id: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type SoilStabilizerRate = {
  id: string;
  stabilizer_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type SoilStabilizerBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  stabilizer_id: string;
  stabilizer_name: string;
  stabilizer_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type RoadRoller = {
  id: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type RoadRollerRate = {
  id: string;
  roller_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type RoadRollerBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  roller_id: string;
  roller_name: string;
  roller_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type ColdMillingMachine = {
  id: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type ColdMillingRate = {
  id: string;
  machine_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type ColdMillingBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  machine_id: string;
  machine_name: string;
  machine_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type Crane = {
  id: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type CraneRate = {
  id: string;
  crane_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type CraneBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  crane_id: string;
  crane_name: string;
  crane_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};

export type AsphaltPaver = {
  id: string;
  company_name: string;
  model: string;
  code: string;
  created_at: string;
};

export type AsphaltPaverRate = {
  id: string;
  paver_id: string;
  rate_type: string;
  rate: number;
  unit: string;
  created_at: string;
};

export type AsphaltPaverBill = {
  id: string;
  bill_number: string;
  site_id: string;
  site_name: string;
  paver_id: string;
  paver_name: string;
  paver_code: string;
  rate_type: string;
  rate: number;
  unit: string;
  quantity: number;
  amount: number;
  paid_amount: number;
  pending_amount: number;
  payment_status: string;
  bill_date: string;
  notes: string;
  created_at: string;
};
