import { useState } from 'react';
import Sidebar from './components/Sidebar';
import ProfilePage from './pages/ProfilePage';
import SitesPage from './pages/SitesPage';
import MaterialsPage from './pages/MaterialsPage';
import TrucksPage from './pages/TrucksPage';
import TMsPage from './pages/TMsPage';
import BituminousGradesPage from './pages/BituminousGradesPage';
import EmployeesPage from './pages/EmployeesPage';
import EmployeeAttendancePage from './pages/EmployeeAttendancePage';
import EmployeeAdvancesPage from './pages/EmployeeAdvancesPage';
import SalaryPage from './pages/SalaryPage';
import ExcavatorsPage from './pages/ExcavatorsPage';
import ExcavatorRatesPage from './pages/ExcavatorRatesPage';
import ExcavatorBillNew from './pages/ExcavatorBillNew';
import ExcavatorDashboard from './pages/ExcavatorDashboard';
import MotorGradersPage from './pages/MotorGradersPage';
import MotorGraderRatesPage from './pages/MotorGraderRatesPage';
import MotorGraderBillNew from './pages/MotorGraderBillNew';
import MotorGraderDashboard from './pages/MotorGraderDashboard';
import DumpersPage from './pages/DumpersPage';
import DumperRatesPage from './pages/DumperRatesPage';
import DumperBillNew from './pages/DumperBillNew';
import DumperDashboard from './pages/DumperDashboard';
import SoilStabilizersPage from './pages/SoilStabilizersPage';
import SoilStabilizerRatesPage from './pages/SoilStabilizerRatesPage';
import SoilStabilizerBillNew from './pages/SoilStabilizerBillNew';
import SoilStabilizerDashboard from './pages/SoilStabilizerDashboard';
import RoadRollersPage from './pages/RoadRollersPage';
import RoadRollerRatesPage from './pages/RoadRollerRatesPage';
import RoadRollerBillNew from './pages/RoadRollerBillNew';
import RoadRollerDashboard from './pages/RoadRollerDashboard';
import ColdMillingMachinesPage from './pages/ColdMillingMachinesPage';
import ColdMillingRatesPage from './pages/ColdMillingRatesPage';
import ColdMillingBillNew from './pages/ColdMillingBillNew';
import ColdMillingDashboard from './pages/ColdMillingDashboard';
import AsphaltPaversPage from './pages/AsphaltPaversPage';
import AsphaltPaverRatesPage from './pages/AsphaltPaverRatesPage';
import AsphaltPaverBillNew from './pages/AsphaltPaverBillNew';
import AsphaltPaverDashboard from './pages/AsphaltPaverDashboard';
import CranesPage from './pages/CranesPage';
import CraneRatesPage from './pages/CraneRatesPage';
import CraneBillNew from './pages/CraneBillNew';
import CraneDashboard from './pages/CraneDashboard';
import AggregateBillNew from './pages/AggregateBillNew';
import AggregateDashboard from './pages/AggregateDashboard';
import DailySalesReport from './pages/DailySalesReport';
import RMCBillNew from './pages/RMCBillNew';
import RMCDashboard from './pages/RMCDashboard';
import RMCDailySalesReport from './pages/RMCDailySalesReport';
import AsphaltBillNew from './pages/AsphaltBillNew';
import AsphaltDashboard from './pages/AsphaltDashboard';
import AsphaltDailySalesReport from './pages/AsphaltDailySalesReport';

type Page = 'profile' | 'aggregate-new' | 'aggregate-dashboard' | 'daily-sales' | 'rmc-new' | 'rmc-dashboard' | 'rmc-daily-sales' | 'asphalt-new' | 'asphalt-dashboard' | 'asphalt-daily-sales' | 'sites' | 'materials' | 'trucks' | 'tms' | 'bituminous-grades' | 'employees' | 'employee-attendance' | 'employee-advances' | 'salary' | 'excavators' | 'excavator-rates' | 'excavator-bill-new' | 'excavator-dashboard' | 'motor-graders' | 'motor-grader-rates' | 'motor-grader-bill-new' | 'motor-grader-dashboard' | 'dumpers' | 'dumper-rates' | 'dumper-bill-new' | 'dumper-dashboard' | 'soil-stabilizers' | 'soil-stabilizer-rates' | 'soil-stabilizer-bill-new' | 'soil-stabilizer-dashboard' | 'road-rollers' | 'road-roller-rates' | 'road-roller-bill-new' | 'road-roller-dashboard' | 'cold-milling-machines' | 'cold-milling-rates' | 'cold-milling-bill-new' | 'cold-milling-dashboard' | 'asphalt-pavers' | 'asphalt-paver-rates' | 'asphalt-paver-bill-new' | 'asphalt-paver-dashboard' | 'cranes' | 'crane-rates' | 'crane-bill-new' | 'crane-dashboard';

function App() {
  const [page, setPage] = useState<Page>('profile');

  function renderPage() {
    switch (page) {
      case 'profile': return <ProfilePage />;
      case 'aggregate-new': return <AggregateBillNew onSuccess={() => setPage('aggregate-dashboard')} />;
      case 'aggregate-dashboard': return <AggregateDashboard />;
      case 'daily-sales': return <DailySalesReport />;
      case 'rmc-new': return <RMCBillNew onSuccess={() => setPage('rmc-dashboard')} />;
      case 'rmc-dashboard': return <RMCDashboard />;
      case 'rmc-daily-sales': return <RMCDailySalesReport />;
      case 'asphalt-new': return <AsphaltBillNew onSuccess={() => setPage('asphalt-dashboard')} />;
      case 'asphalt-dashboard': return <AsphaltDashboard />;
      case 'asphalt-daily-sales': return <AsphaltDailySalesReport />;
      case 'sites': return <SitesPage />;
      case 'materials': return <MaterialsPage />;
      case 'trucks': return <TrucksPage />;
      case 'tms': return <TMsPage />;
      case 'bituminous-grades': return <BituminousGradesPage />;
      case 'employees': return <EmployeesPage />;
      case 'employee-attendance': return <EmployeeAttendancePage />;
      case 'employee-advances': return <EmployeeAdvancesPage />;
      case 'salary': return <SalaryPage />;
      case 'excavators': return <ExcavatorsPage />;
      case 'excavator-rates': return <ExcavatorRatesPage />;
      case 'excavator-bill-new': return <ExcavatorBillNew onSuccess={() => setPage('excavator-dashboard')} />;
      case 'excavator-dashboard': return <ExcavatorDashboard />;
      case 'motor-graders': return <MotorGradersPage />;
      case 'motor-grader-rates': return <MotorGraderRatesPage />;
      case 'motor-grader-bill-new': return <MotorGraderBillNew onSuccess={() => setPage('motor-grader-dashboard')} />;
      case 'motor-grader-dashboard': return <MotorGraderDashboard />;
      case 'dumpers': return <DumpersPage />;
      case 'dumper-rates': return <DumperRatesPage />;
      case 'dumper-bill-new': return <DumperBillNew onSuccess={() => setPage('dumper-dashboard')} />;
      case 'dumper-dashboard': return <DumperDashboard />;
      case 'soil-stabilizers': return <SoilStabilizersPage />;
      case 'soil-stabilizer-rates': return <SoilStabilizerRatesPage />;
      case 'soil-stabilizer-bill-new': return <SoilStabilizerBillNew onSuccess={() => setPage('soil-stabilizer-dashboard')} />;
      case 'soil-stabilizer-dashboard': return <SoilStabilizerDashboard />;
      case 'road-rollers': return <RoadRollersPage />;
      case 'road-roller-rates': return <RoadRollerRatesPage />;
      case 'road-roller-bill-new': return <RoadRollerBillNew onSuccess={() => setPage('road-roller-dashboard')} />;
      case 'road-roller-dashboard': return <RoadRollerDashboard />;
      case 'cold-milling-machines': return <ColdMillingMachinesPage />;
      case 'cold-milling-rates': return <ColdMillingRatesPage />;
      case 'cold-milling-bill-new': return <ColdMillingBillNew onSuccess={() => setPage('cold-milling-dashboard')} />;
      case 'cold-milling-dashboard': return <ColdMillingDashboard />;
      case 'asphalt-pavers': return <AsphaltPaversPage />;
      case 'asphalt-paver-rates': return <AsphaltPaverRatesPage />;
      case 'asphalt-paver-bill-new': return <AsphaltPaverBillNew onSuccess={() => setPage('asphalt-paver-dashboard')} />;
      case 'asphalt-paver-dashboard': return <AsphaltPaverDashboard />;
      case 'cranes': return <CranesPage />;
      case 'crane-rates': return <CraneRatesPage />;
      case 'crane-bill-new': return <CraneBillNew onSuccess={() => setPage('crane-dashboard')} />;
      case 'crane-dashboard': return <CraneDashboard />;
    }
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <Sidebar currentPage={page} onNavigate={setPage} />
      <main className="flex-1 overflow-y-auto">
        <div className="min-h-full">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}

export default App;
