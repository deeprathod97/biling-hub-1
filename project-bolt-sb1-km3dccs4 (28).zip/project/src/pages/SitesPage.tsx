import { useState, useEffect } from 'react';
import { supabase, type Site } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, MapPin, Trash2, Pencil, X, Check, Loader2 } from 'lucide-react';

const emptyForm = { site_name: '', site_number: '', site_location: '', site_incharge: '' };

export default function SitesPage() {
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchSites();
  }, []);

  async function fetchSites() {
    setLoading(true);
    const { data } = await supabase.from('sites').select('*').order('created_at', { ascending: false });
    setSites(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.site_name || !form.site_number || !form.site_location || !form.site_incharge) {
      setError('All fields are required.');
      return;
    }
    setSaving(true);
    if (editId) {
      const { error: err } = await supabase.from('sites').update(form).eq('id', editId);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('sites').insert(form);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
    fetchSites();
  }

  function startEdit(site: Site) {
    setEditId(site.id);
    setForm({ site_name: site.site_name, site_number: site.site_number, site_location: site.site_location, site_incharge: site.site_incharge });
    setShowForm(true);
    setError('');
  }

  async function deleteSite(id: string) {
    if (!confirm('Delete this site?')) return;
    await supabase.from('sites').delete().eq('id', id);
    fetchSites();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Sites"
        subtitle="Manage construction sites"
        actions={
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); setError(''); }}
            className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200"
          >
            <Plus size={16} /> Add Site
          </button>
        }
      />

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editId ? 'Edit Site' : 'Add New Site'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700 transition-colors">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <FormField label="Site Name" value={form.site_name} onChange={v => setForm(f => ({ ...f, site_name: v }))} placeholder="e.g. Highway Project" />
              <FormField label="Site Number" value={form.site_number} onChange={v => setForm(f => ({ ...f, site_number: v }))} placeholder="e.g. S001" />
              <FormField label="Site Location" value={form.site_location} onChange={v => setForm(f => ({ ...f, site_location: v }))} placeholder="e.g. Ahmedabad" />
              <FormField label="Site In-Charge" value={form.site_incharge} onChange={v => setForm(f => ({ ...f, site_incharge: v }))} placeholder="e.g. Ramesh Patel" />
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editId ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 size={28} className="animate-spin text-gray-400" />
        </div>
      ) : sites.length === 0 ? (
        <EmptyState icon={MapPin} message="No sites added yet. Click Add Site to begin." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {sites.map((site, i) => (
            <div
              key={site.id}
              className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow duration-200 animate-slide-up"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
                    <MapPin size={14} className="text-gray-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{site.site_name}</p>
                    <p className="text-xs text-gray-400">#{site.site_number}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => startEdit(site)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                  <button onClick={() => deleteSite(site.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="space-y-1 text-xs text-gray-500">
                <p><span className="text-gray-400">Location:</span> {site.site_location}</p>
                <p><span className="text-gray-400">In-Charge:</span> {site.site_incharge}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function FormField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all"
      />
    </div>
  );
}

function EmptyState({ icon: Icon, message }: { icon: React.ElementType; message: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
      <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
        <Icon size={24} className="text-gray-300" />
      </div>
      <p className="text-sm">{message}</p>
    </div>
  );
}
