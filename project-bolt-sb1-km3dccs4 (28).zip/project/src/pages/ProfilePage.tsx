import PageHeader from '../components/PageHeader';
import { Building2, MapPin, Hash, Users, Briefcase, Cpu } from 'lucide-react';

const teamMembers = [
  { name: 'Mr. Deep Bhai Rathod', role: 'Co-Founder & CTO', icon: Cpu },
  { name: 'Mr. Vinod Bhai Rathod', role: 'Co-Founder & CEO', icon: Briefcase },
];

export default function ProfilePage() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader title="Company Profile" subtitle="D Rock Sand Pvt Ltd details" />

      {/* Hero Card */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden mb-6 animate-slide-up">
        <div className="h-24 bg-gradient-to-r from-gray-800 to-gray-600" />
        <div className="px-6 pb-6">
          <div className="flex items-end gap-4 -mt-10 mb-4">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg"
              alt="D Rock Sand Logo"
              className="w-20 h-20 rounded-xl object-cover border-4 border-white shadow-lg"
            />
            <div className="pb-1">
              <h2 className="text-xl font-bold text-gray-900">D ROCK SAND PVT LTD</h2>
              <p className="text-sm text-gray-500">Aggregate & Sand Management</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InfoRow icon={Building2} label="Company" value="D Rock Sand Pvt Ltd" />
            <InfoRow icon={MapPin} label="Location" value="Sayla" />
            <InfoRow icon={Hash} label="GST Number" value="7EGH5HFN0401Z" />
            <InfoRow icon={Users} label="Team Size" value="2 Co-Founders" />
          </div>
        </div>
      </div>

      {/* Team Cards */}
      <h2 className="text-lg font-semibold text-gray-800 mb-3">Leadership Team</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {teamMembers.map((member, i) => (
          <div
            key={i}
            className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 flex items-center gap-4 hover:shadow-md transition-shadow duration-200 animate-slide-up"
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
              <member.icon size={22} className="text-gray-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">{member.name}</p>
              <p className="text-sm text-gray-500">{member.role}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Company details */}
      <div className="mt-6 bg-gray-50 rounded-xl border border-gray-200 p-5 animate-slide-up">
        <h3 className="text-sm font-semibold text-gray-700 mb-3 uppercase tracking-wide">Business Details</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
          <Detail label="Bill Prefix" value="DR00000" />
          <Detail label="Registered State" value="Gujarat" />
          <Detail label="Business Type" value="Aggregate / Sand Supply" />
          <Detail label="Headquarters" value="Sayla, Gujarat" />
        </div>
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 py-2">
      <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
        <Icon size={15} className="text-gray-500" />
      </div>
      <div>
        <p className="text-xs text-gray-400">{label}</p>
        <p className="text-sm font-medium text-gray-800">{value}</p>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span className="text-gray-500">{label}: </span>
      <span className="font-medium text-gray-800">{value}</span>
    </div>
  );
}
