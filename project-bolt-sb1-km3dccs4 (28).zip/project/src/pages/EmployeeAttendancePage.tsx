import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, type Employee, type EmployeeAttendance } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, Calendar, Printer, Smartphone, ChevronLeft, ChevronRight, Users, CheckSquare, Square, Filter } from 'lucide-react';

const STATUS_OPTIONS = ['present', 'absent', 'half-day'];
const STATUS_COLORS: Record<string, string> = { present: 'bg-green-500', absent: 'bg-red-500', 'half-day': 'bg-blue-500' };
const STATUS_TEXT: Record<string, string> = { present: 'text-green-700 bg-green-100', absent: 'text-red-700 bg-red-100', 'half-day': 'text-blue-700 bg-blue-100' };
const STATUS_BTN: Record<string, string> = {
  present: 'bg-green-600 text-white border-green-600 shadow-green-200 shadow-md',
  absent: 'bg-red-600 text-white border-red-600 shadow-red-200 shadow-md',
  'half-day': 'bg-blue-600 text-white border-blue-600 shadow-blue-200 shadow-md',
};

export default function EmployeeAttendancePage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [records, setRecords] = useState<EmployeeAttendance[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showBulk, setShowBulk] = useState(false);
  const [editRecord, setEditRecord] = useState<EmployeeAttendance | null>(null);
  const [form, setForm] = useState({ employee_id: '', attendance_date: new Date().toISOString().split('T')[0], status: 'present', notes: '' });
  const [error, setError] = useState('');

  // Filters: date range + employee
  const [filterMode, setFilterMode] = useState<'month' | 'range'>('month');
  const [selectedMonth, setSelectedMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; });
  const [startDate, setStartDate] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`; });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Bulk state
  const [bulkDate, setBulkDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [bulkStatus, setBulkStatus] = useState('present');
  const [bulkNotes, setBulkNotes] = useState('');
  const [bulkSelected, setBulkSelected] = useState<Set<string>>(new Set());
  const [bulkError, setBulkError] = useState('');
  const [bulkSaving, setBulkSaving] = useState(false);
  const [existingForDate, setExistingForDate] = useState<Set<string>>(new Set());

  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.from('employees').select('*').order('name').then(({ data }) => setEmployees(data ?? []));
  }, []);

  useEffect(() => { fetchRecords(); }, [selectedMonth, startDate, endDate, selectedEmployee, filterMode]);

  async function fetchRecords() {
    setLoading(true);
    let query = supabase.from('employee_attendance').select('*').order('attendance_date', { ascending: true });

    if (filterMode === 'month') {
      const [year, month] = selectedMonth.split('-').map(Number);
      const sDate = `${year}-${String(month).padStart(2, '0')}-01`;
      const eDate = `${year}-${String(month).padStart(2, '0')}-${String(new Date(year, month, 0).getDate()).padStart(2, '0')}`;
      query = query.gte('attendance_date', sDate).lte('attendance_date', eDate);
    } else {
      query = query.gte('attendance_date', startDate).lte('attendance_date', endDate);
    }

    if (selectedEmployee) query = query.eq('employee_id', selectedEmployee);
    const { data } = await query;
    setRecords(data ?? []);
    setLoading(false);
  }

  async function fetchExistingForBulkDate() {
    if (!bulkDate) { setExistingForDate(new Set()); return; }
    const { data } = await supabase.from('employee_attendance').select('employee_id').eq('attendance_date', bulkDate);
    const ids = new Set((data ?? []).map(r => r.employee_id));
    setExistingForDate(ids);
    setBulkSelected(prev => { const next = new Set(prev); ids.forEach(id => next.delete(id)); return next; });
  }

  useEffect(() => { fetchExistingForBulkDate(); }, [bulkDate]);

  const unmarkedEmployees = employees.filter(e => !existingForDate.has(e.id));

  function toggleBulkSelect(id: string) {
    setBulkSelected(prev => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });
  }
  function selectAllBulk() { setBulkSelected(new Set(unmarkedEmployees.map(e => e.id))); }
  function deselectAllBulk() { setBulkSelected(new Set()); }

  async function handleBulkSubmit() {
    setBulkError('');
    if (bulkSelected.size === 0) { setBulkError('Select at least one employee.'); return; }
    if (!bulkDate) { setBulkError('Date is required.'); return; }
    setBulkSaving(true);
    const rows = Array.from(bulkSelected).map(id => {
      const emp = employees.find(e => e.id === id);
      return { employee_id: id, employee_name: emp?.name ?? '', attendance_date: bulkDate, status: bulkStatus, notes: bulkNotes };
    });
    const { error: err } = await supabase.from('employee_attendance').upsert(rows, { onConflict: 'employee_id,attendance_date' });
    if (err) { setBulkError(err.message); setBulkSaving(false); return; }
    setBulkSaving(false);
    setShowBulk(false);
    setBulkSelected(new Set());
    setBulkNotes('');
    setBulkError('');
    fetchRecords();
    fetchExistingForBulkDate();
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.employee_id || !form.attendance_date) { setError('Employee and date are required.'); return; }
    setSaving(true);
    const emp = employees.find(e => e.id === form.employee_id);
    const payload = { employee_id: form.employee_id, employee_name: emp?.name ?? '', attendance_date: form.attendance_date, status: form.status, notes: form.notes };
    if (editRecord) {
      const { error: err } = await supabase.from('employee_attendance').update(payload).eq('id', editRecord.id);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('employee_attendance').upsert(payload, { onConflict: 'employee_id,attendance_date' });
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditRecord(null);
    setForm({ employee_id: '', attendance_date: new Date().toISOString().split('T')[0], status: 'present', notes: '' });
    fetchRecords();
  }

  function startEdit(rec: EmployeeAttendance) {
    setEditRecord(rec);
    setForm({ employee_id: rec.employee_id, attendance_date: rec.attendance_date, status: rec.status, notes: rec.notes });
    setShowForm(true);
    setError('');
  }

  async function deleteRecord(id: string) {
    if (!confirm('Delete this attendance record?')) return;
    await supabase.from('employee_attendance').delete().eq('id', id);
    fetchRecords();
  }

  const presentCount = records.filter(r => r.status === 'present').length;
  const absentCount = records.filter(r => r.status === 'absent').length;
  const halfDayCount = records.filter(r => r.status === 'half-day').length;

  // Calendar data (always based on selectedMonth)
  const [year, month] = selectedMonth.split('-').map(Number);
  const daysInMonth = new Date(year, month, 0).getDate();
  const firstDayOfWeek = new Date(year, month - 1, 1).getDay();
  const calendarDays: (number | null)[] = [];
  for (let i = 0; i < firstDayOfWeek; i++) calendarDays.push(null);
  for (let d = 1; d <= daysInMonth; d++) calendarDays.push(d);

  function getDayStatus(day: number): string | null {
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dayRecords = records.filter(r => r.attendance_date === dateStr);
    if (dayRecords.length === 0) return null;
    if (dayRecords.some(r => r.status === 'absent')) return 'absent';
    if (dayRecords.some(r => r.status === 'half-day')) return 'half-day';
    return 'present';
  }

  function navigateMonth(dir: number) {
    const [y, m] = selectedMonth.split('-').map(Number);
    const d = new Date(y, m - 1 + dir, 1);
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }

  const handlePrint = useCallback(() => {
    const el = printRef.current;
    if (!el) return;
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
    const html = `<html><head><title>Attendance Report</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#fff;padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #000;padding:5px 8px;text-align:left}th{background:#000;color:#fff;font-weight:bold}.text-right{text-align:right}.present{color:green;font-weight:bold}.absent{color:red;font-weight:bold}.half-day{color:blue;font-weight:bold}.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin:10px 0}.cal-cell{height:36px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:bold;border-radius:4px}.cal-present{background:#22c55e;color:#fff}.cal-absent{background:#ef4444;color:#fff}.cal-half{background:#3b82f6;color:#fff}.cal-empty{background:#f3f4f6;color:#9ca3af}.cal-header{text-align:center;font-size:10px;font-weight:bold;padding:4px 0}.summary-box{display:inline-block;padding:8px 16px;border-radius:6px;margin-right:10px;font-size:12px;font-weight:bold}.summary-present{background:#dcfce7;color:#166534}.summary-absent{background:#fee2e2;color:#991b1b}.summary-half{background:#dbeafe;color:#1e40af}@media print{body{margin:0}}</style></head><body>${el.innerHTML}</body></html>`;
    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }
      doc.open(); doc.write(html); doc.close();
      iframe.contentWindow?.focus();
      setTimeout(() => { try { iframe.contentWindow?.print(); } catch {} setTimeout(() => document.body.removeChild(iframe), 1000); }, 500);
    } else {
      const win = window.open('', '_blank', 'width=900,height=700');
      if (!win) return;
      win.document.write(html); win.document.close(); win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }, []);

  const monthName = new Date(year, month - 1, 1).toLocaleString('en-IN', { month: 'long', year: 'numeric' });
  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });

  const filterLabel = filterMode === 'month'
    ? monthName
    : `${formatDate(startDate)} - ${formatDate(endDate)}`;

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <PageHeader
        title="Employee Attendance"
        subtitle="Track daily attendance with calendar view"
        actions={
          <div className="flex gap-2">
            <button onClick={handlePrint} disabled={records.length === 0} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
              <Printer size={15} className="hidden sm:block" /><Smartphone size={15} className="sm:hidden" /> Print
            </button>
            <button onClick={() => { setShowBulk(true); setBulkError(''); }} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
              <Users size={16} /> Bulk Mark
            </button>
            <button onClick={() => { setShowForm(true); setEditRecord(null); setForm({ employee_id: '', attendance_date: new Date().toISOString().split('T')[0], status: 'present', notes: '' }); setError(''); }} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
              <Plus size={16} /> Single Mark
            </button>
          </div>
        }
      />

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        <div className="rounded-xl border border-green-200 bg-green-50 p-3">
          <p className="text-xs text-green-600">Total Present</p>
          <p className="text-xl font-bold text-green-700">{presentCount}</p>
        </div>
        <div className="rounded-xl border border-red-200 bg-red-50 p-3">
          <p className="text-xs text-red-600">Total Absent</p>
          <p className="text-xl font-bold text-red-700">{absentCount}</p>
        </div>
        <div className="rounded-xl border border-blue-200 bg-blue-50 p-3">
          <p className="text-xs text-blue-600">Total Half Day</p>
          <p className="text-xl font-bold text-blue-700">{halfDayCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Total Records</p>
          <p className="text-xl font-bold text-gray-900">{records.length}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-2 py-1">
          <button onClick={() => navigateMonth(-1)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"><ChevronLeft size={16} /></button>
          <span className="text-sm font-semibold text-gray-800 min-w-[140px] text-center">{monthName}</span>
          <button onClick={() => navigateMonth(1)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"><ChevronRight size={16} /></button>
        </div>
        <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${showFilters ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}>
          <Filter size={15} /> Filters {(startDate !== `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-01` || endDate !== new Date().toISOString().split('T')[0] || selectedEmployee) && <span className="w-2 h-2 rounded-full bg-red-500" />}
        </button>
      </div>

      {showFilters && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4 animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Filters</h3>
            <button onClick={() => { setFilterMode('month'); setSelectedEmployee(''); setStartDate(`${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-01`); setEndDate(new Date().toISOString().split('T')[0]); }} className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700"><X size={12} /> Reset</button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Filter Mode</label>
              <div className="flex gap-2">
                <button onClick={() => setFilterMode('month')} className={`flex-1 py-2 rounded-lg text-xs font-medium border-2 transition-all ${filterMode === 'month' ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>By Month</button>
                <button onClick={() => setFilterMode('range')} className={`flex-1 py-2 rounded-lg text-xs font-medium border-2 transition-all ${filterMode === 'range' ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>Date Range</button>
              </div>
            </div>
            {filterMode === 'range' && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Start Date</label>
                  <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="input-field" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">End Date</label>
                  <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="input-field" />
                </div>
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Employee</label>
              <select value={selectedEmployee} onChange={e => setSelectedEmployee(e.target.value)} className="select-field">
                <option value="">All Employees</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Calendar View */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 mb-5 shadow-sm">
        <div className="grid grid-cols-7 gap-1 mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
            <div key={d} className="text-center text-xs font-bold text-gray-500 py-1">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((day, i) => {
            if (day === null) return <div key={`empty-${i}`} className="h-10" />;
            const status = getDayStatus(day);
            return (
              <div key={day} className={`h-10 rounded-lg flex items-center justify-center text-sm font-medium transition-colors ${status ? STATUS_COLORS[status] + ' text-white' : 'bg-gray-50 text-gray-400'}`}>
                {day}
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-gray-100">
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-green-500" /><span className="text-xs text-gray-600">Present</span></div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-red-500" /><span className="text-xs text-gray-600">Absent</span></div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-blue-500" /><span className="text-xs text-gray-600">Half-Day</span></div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-gray-100" /><span className="text-xs text-gray-600">No Record</span></div>
        </div>
      </div>

      {/* Bulk Attendance Modal */}
      {showBulk && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 flex-shrink-0">
              <h2 className="text-base font-semibold text-gray-900">Bulk Mark Attendance</h2>
              <button onClick={() => setShowBulk(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {bulkError && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{bulkError}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Date</label>
                <input type="date" value={bulkDate} onChange={e => setBulkDate(e.target.value)} className="input-field" />
                {existingForDate.size > 0 && <p className="text-xs text-gray-400 mt-1">{existingForDate.size} employee(s) already marked for this date</p>}
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-2">Status</label>
                <div className="flex gap-2">
                  {STATUS_OPTIONS.map(s => (
                    <button key={s} type="button" onClick={() => setBulkStatus(s)} className={`flex-1 py-2.5 rounded-lg text-sm font-semibold border-2 transition-all duration-200 ${bulkStatus === s ? STATUS_BTN[s] : 'border-gray-200 text-gray-500 bg-white hover:bg-gray-50'}`}>
                      {s === 'present' ? 'Present' : s === 'absent' ? 'Absent' : 'Half Day'}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-medium text-gray-600">Select Employees <span className="text-gray-400">({bulkSelected.size} selected)</span></label>
                  <div className="flex gap-2">
                    <button type="button" onClick={selectAllBulk} className="text-xs font-medium text-gray-700 hover:text-gray-900 flex items-center gap-1"><CheckSquare size={12} /> Select All</button>
                    <button type="button" onClick={deselectAllBulk} className="text-xs font-medium text-gray-500 hover:text-gray-700 flex items-center gap-1"><Square size={12} /> Deselect All</button>
                  </div>
                </div>
                {unmarkedEmployees.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-4 bg-gray-50 rounded-lg">All employees already marked for this date.</p>
                ) : (
                  <div className="grid grid-cols-2 gap-1.5 max-h-[200px] overflow-y-auto border border-gray-100 rounded-lg p-2 bg-gray-50/50">
                    {unmarkedEmployees.map(emp => {
                      const isSelected = bulkSelected.has(emp.id);
                      return (
                        <button key={emp.id} type="button" onClick={() => toggleBulkSelect(emp.id)} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-left text-sm transition-all duration-150 ${isSelected ? 'bg-gray-900 text-white shadow-sm' : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-100'}`}>
                          {isSelected ? <CheckSquare size={14} className="flex-shrink-0" /> : <Square size={14} className="flex-shrink-0 text-gray-400" />}
                          <span className="truncate font-medium">{emp.name}</span>
                          {emp.work_name && <span className={`text-xs ml-auto truncate ${isSelected ? 'text-gray-300' : 'text-gray-400'}`}>{emp.work_name}</span>}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes (applies to all)</label>
                <textarea value={bulkNotes} onChange={e => setBulkNotes(e.target.value)} rows={2} className="input-field resize-none" placeholder="Optional notes..." />
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100 flex-shrink-0">
              <button onClick={handleBulkSubmit} disabled={bulkSaving || bulkSelected.size === 0} className="w-full py-3 rounded-xl bg-gray-900 text-white text-sm font-semibold hover:bg-gray-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed">
                {bulkSaving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                Mark {bulkSelected.size > 0 ? `${bulkSelected.size} Employee${bulkSelected.size > 1 ? 's' : ''}` : 'Employees'} as {bulkStatus === 'half-day' ? 'Half Day' : bulkStatus.charAt(0).toUpperCase() + bulkStatus.slice(1)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Single Employee Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editRecord ? 'Edit Attendance' : 'Mark Attendance'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Employee</label>
                <select value={form.employee_id} onChange={e => setForm(f => ({ ...f, employee_id: e.target.value }))} className="select-field">
                  <option value="">-- Select Employee --</option>
                  {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.work_name})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Date</label>
                <input type="date" value={form.attendance_date} onChange={e => setForm(f => ({ ...f, attendance_date: e.target.value }))} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Status</label>
                <div className="flex gap-2">
                  {STATUS_OPTIONS.map(s => (
                    <button key={s} type="button" onClick={() => setForm(f => ({ ...f, status: s }))} className={`flex-1 py-2 rounded-lg text-xs font-medium border-2 transition-all ${form.status === s ? STATUS_TEXT[s] + ' border-current' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                      {s.charAt(0).toUpperCase() + s.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} className="input-field resize-none" placeholder="Optional notes..." />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editRecord ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Content */}
      <div ref={printRef}>
        {/* Company Header */}
        <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '10px', marginBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '4px' }}>
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg" alt="Logo" style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '6px' }} />
            <div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
              <div style={{ fontSize: '11px', marginTop: '2px' }}>Employee Attendance Report | Sayla, Gujarat</div>
              <div style={{ fontSize: '10px', color: '#555' }}>GST No: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod</div>
            </div>
          </div>
          <div style={{ fontSize: '14px', fontWeight: 'bold', marginTop: '6px', letterSpacing: '2px' }}>ATTENDANCE REPORT</div>
          <div style={{ fontSize: '11px', marginTop: '2px', color: '#333' }}>Period: {filterLabel}{selectedEmployee ? ` | Employee: ${employees.find(e => e.id === selectedEmployee)?.name ?? 'All'}` : ''}</div>
        </div>

        {/* Print Summary */}
        <div style={{ display: 'flex', gap: '10px', marginBottom: '14px', flexWrap: 'wrap' }}>
          <div className="summary-box summary-present" style={{ display: 'inline-block', padding: '8px 16px', borderRadius: '6px', fontSize: '12px', fontWeight: 'bold', background: '#dcfce7', color: '#166534' }}>
            Total Present: {presentCount}
          </div>
          <div style={{ display: 'inline-block', padding: '8px 16px', borderRadius: '6px', fontSize: '12px', fontWeight: 'bold', background: '#fee2e2', color: '#991b1b' }}>
            Total Absent: {absentCount}
          </div>
          <div style={{ display: 'inline-block', padding: '8px 16px', borderRadius: '6px', fontSize: '12px', fontWeight: 'bold', background: '#dbeafe', color: '#1e40af' }}>
            Total Half Day: {halfDayCount}
          </div>
        </div>

        {/* Print Calendar */}
        <div style={{ marginBottom: '14px' }}>
          <div style={{ fontSize: '12px', fontWeight: 'bold', marginBottom: '6px' }}>Attendance Calendar - {monthName}</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '3px' }}>
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
              <div key={d} style={{ textAlign: 'center', fontSize: '10px', fontWeight: 'bold', padding: '3px 0', background: '#000', color: '#fff', borderRadius: '2px' }}>{d}</div>
            ))}
            {calendarDays.map((day, i) => {
              if (day === null) return <div key={`e-${i}`} style={{ height: '32px' }} />;
              const status = getDayStatus(day);
              const bg = status === 'present' ? '#22c55e' : status === 'absent' ? '#ef4444' : status === 'half-day' ? '#3b82f6' : '#f3f4f6';
              const fg = status ? '#fff' : '#9ca3af';
              return <div key={day} style={{ height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 'bold', borderRadius: '4px', background: bg, color: fg }}>{day}</div>;
            })}
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
        ) : records.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
            <Calendar size={32} className="text-gray-200" />
            <p className="text-sm">No attendance records for this period.</p>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-900 text-white">
                    <th className="px-4 py-3 text-left text-xs font-semibold">#</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold">Employee</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold hidden sm:table-cell">Notes</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((rec, i) => (
                    <tr key={rec.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                      <td className="px-4 py-3 text-xs text-gray-500">{i + 1}</td>
                      <td className="px-4 py-3 text-xs text-gray-700">{new Date(rec.attendance_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</td>
                      <td className="px-4 py-3 text-xs font-semibold text-gray-900">{rec.employee_name}</td>
                      <td className="px-4 py-3 text-xs">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_TEXT[rec.status] || 'bg-gray-100 text-gray-600'}`}>
                          {rec.status.charAt(0).toUpperCase() + rec.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500 hidden sm:table-cell max-w-[200px] truncate">{rec.notes || '-'}</td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => startEdit(rec)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                          <button onClick={() => deleteRecord(rec.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Print Footer */}
        <div style={{ borderTop: '1px solid #000', marginTop: '16px', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
          D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | This is a computer generated report
        </div>
      </div>
    </div>
  );
}
