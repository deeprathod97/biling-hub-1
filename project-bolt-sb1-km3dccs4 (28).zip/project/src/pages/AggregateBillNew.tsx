import { useState, useEffect } from 'react';
import { supabase, type Site, type Truck, type Material } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Check, Loader2, Calculator } from 'lucide-react';

const emptyForm = {
  site_id: '',
  truck_id: '',
  material_id: '',
  royalty_number: '',
  royalty_ton: '',
  gross_weight_kg: '',
  tare_weight_kg: '',
  _wheels: '',
};

interface Props {
  onSuccess?: () => void;
}

export default function AggregateBillNew({ onSuccess }: Props) {
  const [sites, setSites] = useState<Site[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const selectedSite = sites.find(s => s.id === form.site_id);
  const selectedTruck = trucks.find(t => t.id === form.truck_id);
  const selectedMaterial = materials.find(m => m.id === form.material_id);

  const grossKg = parseFloat(form.gross_weight_kg) || 0;
  const tareKg = parseFloat(form.tare_weight_kg) || 0;
  const netKg = grossKg - tareKg;
  const netTon = netKg > 0 ? netKg / 1000 : 0;
  const bhav = selectedMaterial ? Number(selectedMaterial.bhav_per_ton) : 0;
  const royaltyBhav = selectedMaterial ? Number(selectedMaterial.royalty_bhav_per_ton) : 0;
  const totalAmount = netTon * bhav;
  const royaltyTon = parseFloat(form.royalty_ton) || 0;
  const royaltyAmount = royaltyTon * royaltyBhav;

  useEffect(() => {
    Promise.all([
      supabase.from('sites').select('*').order('site_name'),
      supabase.from('trucks').select('*').order('truck_number'),
      supabase.from('materials').select('*').order('material_name'),
    ]).then(([s, t, m]) => {
      setSites(s.data ?? []);
      setTrucks(t.data ?? []);
      setMaterials(m.data ?? []);
    });
  }, []);

  async function generateBillNumber(): Promise<string> {
    const { data, error } = await supabase.rpc('get_next_bill_counter', { p_counter_name: 'aggregate' });
    if (error) throw error;
    return `DR${String(data).padStart(5, '0')}`;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!form.site_id || !form.truck_id || !form.material_id) {
      setError('Please select site, truck and material.');
      return;
    }
    if (!form.gross_weight_kg || !form.tare_weight_kg) {
      setError('Please enter gross and tare weight.');
      return;
    }
    if (netKg <= 0) {
      setError('Net weight must be positive. Check gross/tare values.');
      return;
    }
    setSaving(true);
    const billNumber = await generateBillNumber();
    const payload = {
      bill_number: billNumber,
      site_id: form.site_id,
      site_name: selectedSite!.site_name,
      site_number: selectedSite!.site_number,
      site_location: selectedSite!.site_location,
      site_incharge: selectedSite!.site_incharge,
      truck_id: form.truck_id,
      truck_number: selectedTruck!.truck_number,
      material_id: form.material_id,
      material_name: selectedMaterial!.material_name,
      bhav_per_ton: bhav,
      royalty_number: form.royalty_number,
      royalty_ton: royaltyTon,
      gross_weight_kg: grossKg,
      tare_weight_kg: tareKg,
      net_weight_ton: netTon,
      total_amount: totalAmount,
      royalty_amount: royaltyAmount,
      payment_status: 'pending',
    };
    const { error: err } = await supabase.from('aggregate_bills').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    setSaving(false);
    setSuccess(`Bill ${billNumber} created successfully!`);
    setForm(emptyForm);
    if (onSuccess) setTimeout(onSuccess, 1500);
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="New Aggregate Bill" subtitle="Create a new weighing bill" />

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && <p className="text-red-500 text-sm bg-red-50 px-4 py-3 rounded-lg border border-red-100">{error}</p>}
        {success && <p className="text-green-700 text-sm bg-green-50 px-4 py-3 rounded-lg border border-green-100">{success}</p>}

        {/* Site Selection */}
        <Section title="Site Details">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Site</label>
            <select value={form.site_id} onChange={e => setForm(f => ({ ...f, site_id: e.target.value }))} className="select-field">
              <option value="">-- Select Site --</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
            </select>
          </div>
          {selectedSite && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Site Number" value={selectedSite.site_number} />
              <InfoChip label="Location" value={selectedSite.site_location} />
              <InfoChip label="In-Charge" value={selectedSite.site_incharge} />
            </div>
          )}
        </Section>

        {/* Truck Selection */}
        <Section title="Truck Details">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Wheels</label>
            <div className="flex flex-wrap gap-2">
              {[...new Set(trucks.map(t => t.wheels))].sort((a, b) => a - b).map(w => (
                <button key={w} type="button" onClick={() => setForm(f => ({ ...f, truck_id: f.truck_id && trucks.find(t => t.id === f.truck_id)?.wheels !== w ? '' : f.truck_id, _wheels: f._wheels === String(w) ? '' : String(w) }))}
                  className={`py-2 px-4 rounded-lg text-xs font-bold border-2 transition-all ${form._wheels === String(w) ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                  {w} Wheels
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Truck</label>
            <select value={form.truck_id} onChange={e => setForm(f => ({ ...f, truck_id: e.target.value }))} className="select-field">
              <option value="">-- Select Truck --</option>
              {trucks.filter(t => !form._wheels || String(t.wheels) === form._wheels).map(t => <option key={t.id} value={t.id}>{t.truck_number} ({t.select_code}) - {t.wheels} Wheels</option>)}
            </select>
          </div>
          {selectedTruck && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Code" value={selectedTruck.select_code} />
              <InfoChip label="Wheels" value={`${selectedTruck.wheels}`} />
            </div>
          )}
        </Section>

        {/* Material & Royalty */}
        <Section title="Material & Royalty">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Material</label>
            <select value={form.material_id} onChange={e => setForm(f => ({ ...f, material_id: e.target.value }))} className="select-field">
              <option value="">-- Select Material --</option>
              {materials.map(m => <option key={m.id} value={m.id}>{m.material_name}</option>)}
            </select>
          </div>
          {selectedMaterial && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Bhav/Ton" value={`Rs. ${Number(selectedMaterial.bhav_per_ton).toFixed(2)}`} />
              <InfoChip label="Royalty/Ton" value={`Rs. ${Number(selectedMaterial.royalty_bhav_per_ton).toFixed(2)}`} />
            </div>
          )}
          <div className="grid grid-cols-2 gap-4 mt-2">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Royalty Number</label>
              <input type="text" value={form.royalty_number} onChange={e => setForm(f => ({ ...f, royalty_number: e.target.value }))} placeholder="e.g. ROY-2024-001" className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Royalty Ton</label>
              <input type="number" step="0.001" value={form.royalty_ton} onChange={e => setForm(f => ({ ...f, royalty_ton: e.target.value }))} placeholder="0.000" className="input-field" />
            </div>
          </div>
        </Section>

        {/* Weight */}
        <Section title="Weight Entry">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Gross Weight (kg)</label>
              <input type="number" step="1" value={form.gross_weight_kg} onChange={e => setForm(f => ({ ...f, gross_weight_kg: e.target.value }))} placeholder="0" className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Tare Weight (kg)</label>
              <input type="number" step="1" value={form.tare_weight_kg} onChange={e => setForm(f => ({ ...f, tare_weight_kg: e.target.value }))} placeholder="0" className="input-field" />
            </div>
          </div>
        </Section>

        {/* Calculated Summary */}
        {(grossKg > 0 || tareKg > 0) && (
          <div className="bg-gray-900 rounded-xl p-5 text-white animate-slide-up">
            <div className="flex items-center gap-2 mb-4">
              <Calculator size={16} className="text-gray-400" />
              <span className="text-sm font-semibold text-gray-300">Calculation Summary</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <CalcItem label="Net Weight" value={`${netTon.toFixed(3)} T`} highlight />
              <CalcItem label="Total Amount" value={`Rs. ${totalAmount.toFixed(2)}`} />
              <CalcItem label="Royalty Ton" value={`${royaltyTon.toFixed(3)} T`} />
              <CalcItem label="Royalty Amount" value={`Rs. ${royaltyAmount.toFixed(2)}`} />
            </div>
            <p className="text-xs text-gray-500 mt-3">Net: {netKg.toFixed(0)} kg = {netTon.toFixed(3)} ton</p>
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl bg-gray-900 text-white font-semibold text-sm hover:bg-gray-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl active:scale-[0.99]"
        >
          {saving ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
          {saving ? 'Creating Bill...' : 'Create Bill'}
        </button>
      </form>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm animate-slide-up">
      <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">{title}</h3>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

function InfoChip({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-gray-50 rounded-lg px-3 py-2">
      <p className="text-xs text-gray-400">{label}</p>
      <p className="text-sm font-medium text-gray-800">{value}</p>
    </div>
  );
}

function CalcItem({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className={`text-base font-bold ${highlight ? 'text-white' : 'text-gray-300'}`}>{value}</p>
    </div>
  );
}
