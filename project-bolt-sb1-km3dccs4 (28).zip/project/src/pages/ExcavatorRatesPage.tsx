import { useState, useEffect } from 'react';
import { supabase, type Excavator, type ExcavatorRate } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, Settings } from 'lucide-react';

const RATE_TYPES = [
  { value: 'per_minutes', label: 'Per Minutes', unit: 'min' },
  { value: 'per_hour', label: 'Per Hour', unit: 'hr' },
  { value: 'per_dumper', label: 'Per Dumper', unit: 'dumper' },
  { value: 'per_months', label: 'Per Months', unit: 'month' },
  { value: 'per_loads', label: 'Per Loads', unit: 'load' },
  { value: 'per_lid', label: 'Per Lid', unit: 'lid' },
];

export default function ExcavatorRatesPage() {
  const [excavators, setExcavators] = useState<Excavator[]>([]);
  const [rates, setRates] = useState<ExcavatorRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<ExcavatorRate | null>(null);
  const [form, setForm] = useState({ excavator_id: '', rate_type: 'per_hour', rate: '', unit: 'hr' });
  const [error, setError] = useState('');

  useEffect(() => {
    supabase.from('excavators').select('*').order('company_name').then(({ data }) => setExcavators(data ?? []));
    fetchRates();
  }, []);

  async function fetchRates() {
    setLoading(true);
    const { data } = await supabase.from('excavator_rates').select('*').order('created_at', { ascending: false });
    setRates(data ?? []);
    setLoading(false);
  }

  function getRateTypeInfo(rateType: string) {
    return RATE_TYPES.find(r => r.value === rateType) ?? { label: rateType, unit: '' };
  }

  function handleRateTypeChange(rt: string) {
    const info = getRateTypeInfo(rt);
    setForm(f => ({ ...f, rate_type: rt, unit: info.unit }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.excavator_id || !form.rate_type || !form.rate) { setError('All fields are required.'); return; }
    setSaving(true);
    const payload = { excavator_id: form.excavator_id, rate_type: form.rate_type, rate: parseFloat(form.rate), unit: form.unit };
    if (editItem) {
      const { error: err } = await supabase.from('excavator_rates').update(payload).eq('id', editItem.id);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('excavator_rates').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditItem(null);
    setForm({ excavator_id: '', rate_type: 'per_hour', rate: '', unit: 'hr' });
    fetchRates();
  }

  function startEdit(item: ExcavatorRate) {
    const info = getRateTypeInfo(item.rate_type);
    setEditItem(item);
    setForm({ excavator_id: item.excavator_id, rate_type: item.rate_type, rate: String(item.rate), unit: info.unit });
    setShowForm(true);
    setError('');
  }

  async function deleteItem(id: string) {
    if (!confirm('Delete this rate configuration?')) return;
    await supabase.from('excavator_rates').delete().eq('id', id);
    fetchRates();
  }

  function getExcavatorName(id: string) {
    const exc = excavators.find(e => e.id === id);
    return exc ? `${exc.company_name} - ${exc.model} (${exc.code || 'No code'})` : 'Unknown';
  }

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Rate Configuration"
        subtitle="Configure rates for excavators (per minutes, hour, dumper, months, loads, lid)"
        actions={
          <button onClick={() => { setShowForm(true); setEditItem(null); setForm({ excavator_id: '', rate_type: 'per_hour', rate: '', unit: 'hr' }); setError(''); }} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700">
            <Plus size={16} /> Add Rate
          </button>
        }
      />

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editItem ? 'Edit' : 'Add'} Rate Configuration</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Excavator</label>
                <select value={form.excavator_id} onChange={e => setForm(f => ({ ...f, excavator_id: e.target.value }))} className="select-field">
                  <option value="">-- Select Excavator --</option>
                  {excavators.map(e => <option key={e.id} value={e.id}>{e.company_name} - {e.model} ({e.code || 'No code'}) [{e.type === 'jcb' ? 'JCB' : 'Excavator'}]</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Rate Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {RATE_TYPES.map(rt => (
                    <button key={rt.value} type="button" onClick={() => handleRateTypeChange(rt.value)}
                      className={`py-2 rounded-lg text-xs font-medium border-2 transition-all ${form.rate_type === rt.value ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                      {rt.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Rate (Rs.)</label>
                  <input type="number" step="0.01" value={form.rate} onChange={e => setForm(f => ({ ...f, rate: e.target.value }))} className="input-field" placeholder="0.00" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Unit</label>
                  <input type="text" value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} className="input-field" placeholder="hr, min, etc." />
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editItem ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : rates.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <Settings size={32} className="text-gray-200" />
          <p className="text-sm">No rate configurations yet.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {rates.map(item => {
            const info = getRateTypeInfo(item.rate_type);
            return (
              <div key={item.id} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between gap-4 hover:border-gray-300 transition-colors">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-gray-900 truncate">{getExcavatorName(item.excavator_id)}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700">{info.label}</span>
                    <span className="text-sm font-bold text-green-700">Rs. {Number(item.rate).toFixed(2)}</span>
                    <span className="text-xs text-gray-400">/ {item.unit}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => startEdit(item)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><Pencil size={14} /></button>
                  <button onClick={() => deleteItem(item.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 size={14} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
