import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, type RMCBill } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import RMCBillPrint from '../components/RMCBillPrint';
import RMCSlipPrint from '../components/RMCSlipPrint';
import {
  Search, Printer, FileText, Trash2, CreditCard, X, Loader2,
  ChevronDown, ChevronUp, IndianRupee, Smartphone
} from 'lucide-react';

const PAYMENT_STATUSES = ['pending', 'partial', 'paid'];

export default function RMCDashboard() {
  const [bills, setBills] = useState<RMCBill[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [printBill, setPrintBill] = useState<RMCBill | null>(null);
  const [slipBill, setSlipBill] = useState<RMCBill | null>(null);
  const [payBill, setPayBill] = useState<RMCBill | null>(null);
  const [payForm, setPayForm] = useState({ payment_amount: '', payment_note: '', payment_status: 'paid' });
  const [saving, setSaving] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const printRef = useRef<HTMLDivElement>(null);
  const slipRef = useRef<HTMLDivElement>(null);

  useEffect(() => { fetchBills(); }, []);

  async function fetchBills() {
    setLoading(true);
    const { data } = await supabase.from('rmc_bills').select('*').order('created_at', { ascending: false });
    setBills(data ?? []);
    setLoading(false);
  }

  const filtered = bills.filter(b =>
    b.bill_number.toLowerCase().includes(search.toLowerCase()) ||
    b.site_name.toLowerCase().includes(search.toLowerCase()) ||
    b.tm_number.toLowerCase().includes(search.toLowerCase()) ||
    b.concrete_grade.toLowerCase().includes(search.toLowerCase())
  );

  const handlePrint = useCallback((ref: React.RefObject<HTMLDivElement>, title: string) => {
    const el = ref.current;
    if (!el) return;

    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);

    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }

      doc.open();
      doc.write(`
        <html><head><title>${title}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          @media print { body { margin: 0; } }
        </style>
        </head><body>${el.innerHTML}</body></html>
      `);
      doc.close();

      iframe.contentWindow?.focus();
      setTimeout(() => {
        try { iframe.contentWindow?.print(); } catch {}
        setTimeout(() => { document.body.removeChild(iframe); }, 1000);
      }, 500);
    } else {
      const win = window.open('', '_blank', 'width=900,height=700');
      if (!win) return;
      win.document.write(`
        <html><head><title>${title}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          @media print { body { margin: 0; } }
        </style>
        </head><body>${el.innerHTML}</body></html>
      `);
      win.document.close();
      win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }, []);

  async function handleDelete(id: string) {
    if (!confirm('Delete this bill? This cannot be undone.')) return;
    await supabase.from('rmc_bills').delete().eq('id', id);
    fetchBills();
  }

  async function handlePayment(e: React.FormEvent) {
    e.preventDefault();
    if (!payBill) return;
    setSaving(true);
    await supabase.from('rmc_bills').update({
      payment_status: payForm.payment_status,
      payment_amount: parseFloat(payForm.payment_amount) || 0,
      payment_date: new Date().toISOString(),
      payment_note: payForm.payment_note,
      updated_at: new Date().toISOString(),
    }).eq('id', payBill.id);
    setSaving(false);
    setPayBill(null);
    fetchBills();
  }

  const totalBills = bills.length;
  const totalAmount = bills.reduce((a, b) => a + Number(b.total_amount), 0);
  const totalMcb = bills.reduce((a, b) => a + Number(b.total_mcb), 0);
  const pendingAmount = bills.filter(b => b.payment_status !== 'paid').reduce((a, b) => a + Number(b.total_amount), 0);

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      <PageHeader title="RMC Bill Dashboard" subtitle="All Ready Mix Concrete bills" />

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Bills" value={String(totalBills)} />
        <StatCard label="Total MCB" value={`${totalMcb.toFixed(3)}`} />
        <StatCard label="Total Amount" value={`Rs. ${totalAmount.toFixed(2)}`} />
        <StatCard label="Pending Amount" value={`Rs. ${pendingAmount.toFixed(2)}`} accent />
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by bill no, site, TM, grade..."
          className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 bg-white"
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <FileText size={32} className="text-gray-200" />
          <p className="text-sm">No RMC bills found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((bill, i) => (
            <div key={bill.id} className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden animate-slide-up" style={{ animationDelay: `${i * 30}ms` }}>
              <div
                className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => setExpanded(expanded === bill.id ? null : bill.id)}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="font-bold text-gray-900 text-sm shrink-0">{bill.bill_number}</span>
                  <span className="text-xs text-gray-400 hidden sm:block truncate">{bill.site_name}</span>
                  <span className="text-xs px-1.5 py-0.5 bg-gray-100 rounded text-gray-600 font-medium">{bill.concrete_grade}</span>
                  <span className="text-xs text-gray-500 hidden md:block">{bill.tm_number}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0 ml-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    bill.payment_status === 'paid' ? 'bg-green-100 text-green-700' :
                    bill.payment_status === 'partial' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>{bill.payment_status}</span>
                  <span className="text-sm font-semibold text-gray-800">Rs. {Number(bill.total_amount).toFixed(2)}</span>
                  {expanded === bill.id ? <ChevronUp size={15} className="text-gray-400" /> : <ChevronDown size={15} className="text-gray-400" />}
                </div>
              </div>

              {expanded === bill.id && (
                <div className="border-t border-gray-100 px-4 py-4 animate-slide-up">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4 text-xs">
                    <DetailItem label="Bill Date" value={new Date(bill.bill_date).toLocaleDateString('en-IN')} />
                    <DetailItem label="Grade" value={`${bill.concrete_grade} @ Rs. ${Number(bill.grade_rate).toFixed(2)}/MCB`} />
                    <DetailItem label="Quantity" value={`${Number(bill.quantity_mcb).toFixed(3)} MCB`} />
                    <DetailItem label="Total MCB" value={`${Number(bill.total_mcb).toFixed(3)}`} />
                    <DetailItem label="Carting Bhada" value={`Rs. ${Number(bill.carting_bhada).toFixed(2)}/MCB`} />
                    <DetailItem label="Site" value={bill.site_name} />
                    <DetailItem label="Location" value={bill.site_location} />
                    <DetailItem label="In-Charge" value={bill.site_incharge} />
                    <DetailItem label="TM Number" value={bill.tm_number} />
                    <DetailItem label="Grade Amount" value={`Rs. ${(Number(bill.grade_rate) * Number(bill.quantity_mcb)).toFixed(2)}`} />
                    <DetailItem label="Carting Amount" value={`Rs. ${(Number(bill.carting_bhada) * Number(bill.quantity_mcb)).toFixed(2)}`} />
                    <DetailItem label="Total Amount" value={`Rs. ${Number(bill.total_amount).toFixed(2)}`} />
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <ActionBtn icon={Printer} label="Print Bill" onClick={() => setPrintBill(bill)} />
                    <ActionBtn icon={FileText} label="Print Slip" onClick={() => setSlipBill(bill)} />
                    <ActionBtn icon={CreditCard} label="Payment" onClick={() => { setPayBill(bill); setPayForm({ payment_amount: String(bill.total_amount), payment_note: bill.payment_note || '', payment_status: bill.payment_status }); }} />
                    <ActionBtn icon={Trash2} label="Delete" onClick={() => handleDelete(bill.id)} danger />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Payment Modal */}
      {payBill && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">Payment - {payBill.bill_number}</h2>
              <button onClick={() => setPayBill(null)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <form onSubmit={handlePayment} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Payment Status</label>
                <select value={payForm.payment_status} onChange={e => setPayForm(f => ({ ...f, payment_status: e.target.value }))} className="select-field">
                  {PAYMENT_STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Payment Amount (Rs.)</label>
                <input type="number" step="0.01" value={payForm.payment_amount} onChange={e => setPayForm(f => ({ ...f, payment_amount: e.target.value }))} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Note</label>
                <textarea value={payForm.payment_note} onChange={e => setPayForm(f => ({ ...f, payment_note: e.target.value }))} rows={2} className="input-field resize-none" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setPayBill(null)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <IndianRupee size={15} />}
                  Save Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Print Bill Modal */}
      {printBill && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-2 sm:my-0 animate-modal-in">
            <div className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 border-b border-gray-100 sticky top-0 bg-white z-10 rounded-t-2xl">
              <h2 className="text-sm sm:text-base font-semibold text-gray-900">RMC Bill Preview</h2>
              <div className="flex gap-2">
                <button onClick={() => handlePrint(printRef, 'RMC Bill')} className="flex items-center gap-1.5 bg-gray-900 text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm hover:bg-gray-700 transition-colors">
                  <Printer size={14} className="hidden sm:block" />
                  <Smartphone size={14} className="sm:hidden" />
                  Print
                </button>
                <button onClick={() => setPrintBill(null)} className="text-gray-400 hover:text-gray-700 p-1.5 sm:p-2"><X size={18} /></button>
              </div>
            </div>
            <div className="overflow-x-auto p-2 sm:p-4">
              <div ref={printRef}>
                <RMCBillPrint bill={printBill} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Print Slip Modal */}
      {slipBill && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md my-2 sm:my-0 animate-modal-in">
            <div className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 border-b border-gray-100 sticky top-0 bg-white z-10 rounded-t-2xl">
              <h2 className="text-sm sm:text-base font-semibold text-gray-900">RMC Slip Preview</h2>
              <div className="flex gap-2">
                <button onClick={() => handlePrint(slipRef, 'RMC Slip')} className="flex items-center gap-1.5 bg-gray-900 text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm hover:bg-gray-700 transition-colors">
                  <Printer size={14} className="hidden sm:block" />
                  <Smartphone size={14} className="sm:hidden" />
                  Print
                </button>
                <button onClick={() => setSlipBill(null)} className="text-gray-400 hover:text-gray-700 p-1.5 sm:p-2"><X size={18} /></button>
              </div>
            </div>
            <div className="overflow-x-auto p-2 sm:p-4">
              <div ref={slipRef}>
                <RMCSlipPrint bill={slipBill} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className={`rounded-xl border p-4 ${accent ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'}`}>
      <p className={`text-xs mb-1 ${accent ? 'text-gray-400' : 'text-gray-500'}`}>{label}</p>
      <p className="text-xl font-bold">{value}</p>
    </div>
  );
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-gray-50 rounded-lg px-2 py-1.5">
      <p className="text-gray-400 text-xs">{label}</p>
      <p className="text-gray-800 font-medium text-xs mt-0.5">{value}</p>
    </div>
  );
}

function ActionBtn({ icon: Icon, label, onClick, danger }: { icon: React.ElementType; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
        danger ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-gray-700 bg-gray-100 hover:bg-gray-200'
      }`}
    >
      <Icon size={13} /> {label}
    </button>
  );
}
