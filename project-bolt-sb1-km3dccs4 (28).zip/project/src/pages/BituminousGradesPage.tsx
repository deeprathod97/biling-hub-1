import { useState, useEffect } from 'react';
import { supabase, type BituminousGrade } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, Layers } from 'lucide-react';

const emptyForm = { grade_name: '', price_per_ton: '', carting_bhada: '' };

export default function BituminousGradesPage() {
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  useEffect(() => { fetchGrades(); }, []);

  async function fetchGrades() {
    setLoading(true);
    const { data } = await supabase.from('bituminous_grades').select('*').order('created_at', { ascending: false });
    setGrades(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.grade_name || !form.price_per_ton) {
      setError('Grade name and price per ton are required.');
      return;
    }
    setSaving(true);
    const payload = {
      grade_name: form.grade_name.toUpperCase(),
      price_per_ton: parseFloat(form.price_per_ton) || 0,
      carting_bhada: parseFloat(form.carting_bhada) || 0,
    };
    if (editId) {
      const { error: err } = await supabase.from('bituminous_grades').update(payload).eq('id', editId);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('bituminous_grades').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
    fetchGrades();
  }

  function startEdit(g: BituminousGrade) {
    setEditId(g.id);
    setForm({ grade_name: g.grade_name, price_per_ton: String(g.price_per_ton), carting_bhada: String(g.carting_bhada) });
    setShowForm(true);
    setError('');
  }

  async function deleteGrade(id: string) {
    if (!confirm('Delete this grade?')) return;
    await supabase.from('bituminous_grades').delete().eq('id', id);
    fetchGrades();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Bituminous Grades"
        subtitle="Manage grade names, prices, and carting bhada"
        actions={
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); setError(''); }}
            className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200"
          >
            <Plus size={16} /> Add Grade
          </button>
        }
      />

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editId ? 'Edit Grade' : 'Add New Grade'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700 transition-colors"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Grade Name</label>
                <input type="text" value={form.grade_name} onChange={e => setForm(f => ({ ...f, grade_name: e.target.value.toUpperCase() }))} placeholder="e.g. VG-30, VG-40" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Price Per Ton (Rs.)</label>
                <input type="number" step="0.01" value={form.price_per_ton} onChange={e => setForm(f => ({ ...f, price_per_ton: e.target.value }))} placeholder="0.00" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Carting Bhada (Rs./Ton)</label>
                <input type="number" step="0.01" value={form.carting_bhada} onChange={e => setForm(f => ({ ...f, carting_bhada: e.target.value }))} placeholder="0.00" className="input-field" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editId ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : grades.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center"><Layers size={24} className="text-gray-300" /></div>
          <p className="text-sm">No bituminous grades added yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {grades.map((g, i) => (
            <div key={g.id} className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow duration-200 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center"><Layers size={14} className="text-gray-500" /></div>
                  <div>
                    <p className="font-bold text-gray-900 text-sm">{g.grade_name}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => startEdit(g)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                  <button onClick={() => deleteGrade(g.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-gray-50 rounded-lg px-3 py-2 text-center">
                  <p className="text-xs text-gray-400">Price/Ton</p>
                  <p className="font-bold text-gray-800 text-sm">Rs. {Number(g.price_per_ton).toFixed(2)}</p>
                </div>
                <div className="bg-gray-50 rounded-lg px-3 py-2 text-center">
                  <p className="text-xs text-gray-400">Carting Bhada</p>
                  <p className="font-bold text-gray-800 text-sm">Rs. {Number(g.carting_bhada).toFixed(2)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
