import { useState, useEffect } from 'react';
import { supabase, type Employee } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, Users, Search } from 'lucide-react';

const emptyForm = { name: '', mobile: '', address: '', work_name: '', salary: '' };

export default function EmployeesPage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => { fetchEmployees(); }, []);

  async function fetchEmployees() {
    setLoading(true);
    const { data } = await supabase.from('employees').select('*').order('name');
    setEmployees(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.name) { setError('Employee name is required.'); return; }
    setSaving(true);
    const payload = {
      name: form.name,
      mobile: form.mobile,
      address: form.address,
      work_name: form.work_name,
      salary: parseFloat(form.salary) || 0,
    };
    if (editId) {
      const { error: err } = await supabase.from('employees').update(payload).eq('id', editId);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('employees').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
    fetchEmployees();
  }

  function startEdit(emp: Employee) {
    setEditId(emp.id);
    setForm({ name: emp.name, mobile: emp.mobile, address: emp.address, work_name: emp.work_name, salary: String(emp.salary) });
    setShowForm(true);
    setError('');
  }

  async function deleteEmployee(id: string) {
    if (!confirm('Delete this employee? Attendance and advance records will also be removed.')) return;
    await supabase.from('employee_attendance').delete().eq('employee_id', id);
    await supabase.from('employee_advances').delete().eq('employee_id', id);
    await supabase.from('employees').delete().eq('id', id);
    fetchEmployees();
  }

  const filtered = employees.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.mobile.includes(search) ||
    e.work_name.toLowerCase().includes(search.toLowerCase())
  );

  const totalSalary = employees.reduce((a, e) => a + Number(e.salary), 0);

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <PageHeader
        title="Employees"
        subtitle="Manage employee records"
        actions={
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); setError(''); }}
            className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200"
          >
            <Plus size={16} /> Add Employee
          </button>
        }
      />

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
        <div className="rounded-xl border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Total Employees</p>
          <p className="text-xl font-bold text-gray-900">{employees.length}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Total Monthly Salary</p>
          <p className="text-xl font-bold text-gray-900">Rs. {totalSalary.toFixed(2)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Showing</p>
          <p className="text-xl font-bold text-gray-900">{filtered.length}</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, mobile, or work..." className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 bg-white" />
      </div>

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editId ? 'Edit Employee' : 'Add New Employee'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700 transition-colors"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Name</label>
                <input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Employee name" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Mobile</label>
                <input type="tel" value={form.mobile} onChange={e => setForm(f => ({ ...f, mobile: e.target.value }))} placeholder="Mobile number" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Address</label>
                <textarea value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} rows={2} placeholder="Address" className="input-field resize-none" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Work Name</label>
                <input type="text" value={form.work_name} onChange={e => setForm(f => ({ ...f, work_name: e.target.value }))} placeholder="e.g. Driver, Operator, Labour" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Monthly Salary (Rs.)</label>
                <input type="number" step="0.01" value={form.salary} onChange={e => setForm(f => ({ ...f, salary: e.target.value }))} placeholder="0.00" className="input-field" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editId ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center"><Users size={24} className="text-gray-300" /></div>
          <p className="text-sm">No employees found.</p>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-900 text-white">
                  <th className="px-4 py-3 text-left text-xs font-semibold">#</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold">Name</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold hidden sm:table-cell">Mobile</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold hidden md:table-cell">Address</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold">Work</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold">Salary</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((emp, i) => (
                  <tr key={emp.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                    <td className="px-4 py-3 text-xs text-gray-500">{i + 1}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-gray-900">{emp.name}</td>
                    <td className="px-4 py-3 text-xs text-gray-600 hidden sm:table-cell">{emp.mobile || '-'}</td>
                    <td className="px-4 py-3 text-xs text-gray-600 hidden md:table-cell max-w-[150px] truncate">{emp.address || '-'}</td>
                    <td className="px-4 py-3 text-xs"><span className="px-2 py-0.5 bg-gray-100 rounded text-gray-700 font-medium">{emp.work_name || '-'}</span></td>
                    <td className="px-4 py-3 text-xs text-right font-semibold text-gray-900">Rs. {Number(emp.salary).toFixed(2)}</td>
                    <td className="px-4 py-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => startEdit(emp)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                        <button onClick={() => deleteEmployee(emp.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
