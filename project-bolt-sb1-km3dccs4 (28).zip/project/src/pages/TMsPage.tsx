import { useState, useEffect } from 'react';
import { supabase, type TM } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Truck, Trash2, Pencil, X, Check, Loader2 } from 'lucide-react';

const emptyForm = { tm_number: '', code: '', wheels: '6' };
const WHEEL_OPTIONS = [4, 6, 8, 10, 12];

export default function TMsPage() {
  const [tms, setTMs] = useState<TM[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  useEffect(() => { fetchTMs(); }, []);

  async function fetchTMs() {
    setLoading(true);
    const { data } = await supabase.from('tms').select('*').order('created_at', { ascending: false });
    setTMs(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.tm_number || !form.code || !form.wheels) {
      setError('All fields are required.');
      return;
    }
    setSaving(true);
    const payload = { tm_number: form.tm_number.toUpperCase(), code: form.code, wheels: parseInt(form.wheels) };
    if (editId) {
      const { error: err } = await supabase.from('tms').update(payload).eq('id', editId);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('tms').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
    fetchTMs();
  }

  function startEdit(tm: TM) {
    setEditId(tm.id);
    setForm({ tm_number: tm.tm_number, code: tm.code, wheels: String(tm.wheels) });
    setShowForm(true);
    setError('');
  }

  async function deleteTM(id: string) {
    if (!confirm('Delete this TM?')) return;
    await supabase.from('tms').delete().eq('id', id);
    fetchTMs();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Transit Mixers"
        subtitle="Manage TM registry"
        actions={
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); setError(''); }}
            className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200"
          >
            <Plus size={16} /> Add TM
          </button>
        }
      />

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editId ? 'Edit TM' : 'Add New TM'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700 transition-colors"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">TM Number</label>
                <input type="text" value={form.tm_number} onChange={e => setForm(f => ({ ...f, tm_number: e.target.value.toUpperCase() }))} placeholder="e.g. TM-001" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Code</label>
                <input type="text" value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} placeholder="e.g. GJ-05" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Wheels</label>
                <select value={form.wheels} onChange={e => setForm(f => ({ ...f, wheels: e.target.value }))} className="select-field">
                  {WHEEL_OPTIONS.map(w => <option key={w} value={w}>{w} Wheels</option>)}
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editId ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : tms.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center"><Truck size={24} className="text-gray-300" /></div>
          <p className="text-sm">No transit mixers added yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tms.map((tm, i) => (
            <div key={tm.id} className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow duration-200 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center"><Truck size={14} className="text-gray-500" /></div>
                  <div>
                    <p className="font-bold text-gray-900 text-sm">{tm.tm_number}</p>
                    <p className="text-xs text-gray-400">Code: {tm.code}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => startEdit(tm)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                  <button onClick={() => deleteTM(tm.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg px-3 py-2 text-center">
                <p className="text-xs text-gray-400">Wheels</p>
                <p className="font-bold text-gray-800">{tm.wheels}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
