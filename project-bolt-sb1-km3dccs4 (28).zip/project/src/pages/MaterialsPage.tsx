import { useState, useEffect } from 'react';
import { supabase, type Material } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Package, Trash2, Pencil, X, Check, Loader2 } from 'lucide-react';

const emptyForm = { material_name: '', bhav_per_ton: '', royalty_bhav_per_ton: '' };

export default function MaterialsPage() {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  useEffect(() => { fetchMaterials(); }, []);

  async function fetchMaterials() {
    setLoading(true);
    const { data } = await supabase.from('materials').select('*').order('created_at', { ascending: false });
    setMaterials(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.material_name || !form.bhav_per_ton || !form.royalty_bhav_per_ton) {
      setError('All fields are required.');
      return;
    }
    setSaving(true);
    const payload = {
      material_name: form.material_name,
      bhav_per_ton: parseFloat(form.bhav_per_ton),
      royalty_bhav_per_ton: parseFloat(form.royalty_bhav_per_ton),
    };
    if (editId) {
      const { error: err } = await supabase.from('materials').update(payload).eq('id', editId);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('materials').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
    fetchMaterials();
  }

  function startEdit(mat: Material) {
    setEditId(mat.id);
    setForm({ material_name: mat.material_name, bhav_per_ton: String(mat.bhav_per_ton), royalty_bhav_per_ton: String(mat.royalty_bhav_per_ton) });
    setShowForm(true);
    setError('');
  }

  async function deleteMaterial(id: string) {
    if (!confirm('Delete this material?')) return;
    await supabase.from('materials').delete().eq('id', id);
    fetchMaterials();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Materials"
        subtitle="Manage material types and pricing"
        actions={
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); setError(''); }}
            className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200"
          >
            <Plus size={16} /> Add Material
          </button>
        }
      />

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editId ? 'Edit Material' : 'Add New Material'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700 transition-colors"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Material Name</label>
                <input type="text" value={form.material_name} onChange={e => setForm(f => ({ ...f, material_name: e.target.value }))} placeholder="e.g. Crushed Stone" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Bhav Per Ton (Rs.)</label>
                <input type="number" step="0.01" value={form.bhav_per_ton} onChange={e => setForm(f => ({ ...f, bhav_per_ton: e.target.value }))} placeholder="0.00" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Royalty Bhav Per Ton (Rs.)</label>
                <input type="number" step="0.01" value={form.royalty_bhav_per_ton} onChange={e => setForm(f => ({ ...f, royalty_bhav_per_ton: e.target.value }))} placeholder="0.00" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editId ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : materials.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center"><Package size={24} className="text-gray-300" /></div>
          <p className="text-sm">No materials added yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {materials.map((mat, i) => (
            <div key={mat.id} className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow duration-200 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center"><Package size={14} className="text-gray-500" /></div>
                  <p className="font-semibold text-gray-900 text-sm">{mat.material_name}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => startEdit(mat)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                  <button onClick={() => deleteMaterial(mat.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 rounded-lg p-2">
                  <p className="text-gray-400">Bhav / Ton</p>
                  <p className="font-semibold text-gray-800">Rs. {Number(mat.bhav_per_ton).toFixed(2)}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2">
                  <p className="text-gray-400">Royalty / Ton</p>
                  <p className="font-semibold text-gray-800">Rs. {Number(mat.royalty_bhav_per_ton).toFixed(2)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
