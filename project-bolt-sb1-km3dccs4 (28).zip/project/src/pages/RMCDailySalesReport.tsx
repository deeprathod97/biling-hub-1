import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, type RMCBill, type Site, type TM } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Printer, Filter, X, Loader2, Calendar, Truck, MapPin, Construction, Smartphone } from 'lucide-react';

const CONCRETE_GRADES = ['M5', 'M7.5', 'M10', 'M20', 'M25', 'M30', 'M35', 'M40'];

export default function RMCDailySalesReport() {
  const [bills, setBills] = useState<RMCBill[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [tms, setTMs] = useState<TM[]>([]);
  const [loading, setLoading] = useState(false);

  const [startDate, setStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [filterTM, setFilterTM] = useState('');
  const [filterSite, setFilterSite] = useState('');
  const [filterGrade, setFilterGrade] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    Promise.all([
      supabase.from('sites').select('*').order('site_name'),
      supabase.from('tms').select('*').order('tm_number'),
    ]).then(([s, t]) => {
      setSites(s.data ?? []);
      setTMs(t.data ?? []);
    });
  }, []);

  async function fetchReport() {
    setLoading(true);
    let query = supabase
      .from('rmc_bills')
      .select('*')
      .gte('bill_date', startDate)
      .lte('bill_date', endDate + 'T23:59:59')
      .order('bill_date', { ascending: true });

    if (filterTM) query = query.eq('tm_number', filterTM);
    if (filterSite) query = query.eq('site_id', filterSite);
    if (filterGrade) query = query.eq('concrete_grade', filterGrade);

    const { data } = await query;
    setBills(data ?? []);
    setLoading(false);
  }

  useEffect(() => { fetchReport(); }, []);

  const totalMcb = bills.reduce((a, b) => a + Number(b.quantity_mcb), 0);
  const totalAmount = bills.reduce((a, b) => a + Number(b.total_amount), 0);

  function clearFilters() {
    setFilterTM('');
    setFilterSite('');
    setFilterGrade('');
  }

  const hasFilters = filterTM || filterSite || filterGrade;

  const handlePrint = useCallback(() => {
    const el = printRef.current;
    if (!el) return;
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }
      doc.open();
      doc.write(`<html><head><title>RMC Daily Sales Report</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#fff;padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #000;padding:5px 8px;text-align:left}th{background:#000;color:#fff;font-weight:bold}.text-right{text-align:right}.total-row{background:#f0f0f0;font-weight:bold}@media print{body{margin:0}}}</style></head><body>${el.innerHTML}</body></html>`);
      doc.close();
      iframe.contentWindow?.focus();
      setTimeout(() => { try { iframe.contentWindow?.print(); } catch {} setTimeout(() => document.body.removeChild(iframe), 1000); }, 500);
    } else {
      const win = window.open('', '_blank', 'width=900,height=700');
      if (!win) return;
      win.document.write(`<html><head><title>RMC Daily Sales Report</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#fff;padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #000;padding:5px 8px;text-align:left}th{background:#000;color:#fff;font-weight:bold}.text-right{text-align:right}.total-row{background:#f0f0f0;font-weight:bold}@media print{body{margin:0}}}</style></head><body>${el.innerHTML}</body></html>`);
      win.document.close();
      win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }, []);

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      <PageHeader
        title="RMC Daily Sales Report"
        subtitle="Ready Mix Concrete daily sales with filters"
        actions={
          <div className="flex gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${showFilters ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}
            >
              <Filter size={15} /> Filters {hasFilters && <span className="w-2 h-2 rounded-full bg-red-500" />}
            </button>
            <button
              onClick={handlePrint}
              disabled={bills.length === 0}
              className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Printer size={15} className="hidden sm:block" />
              <Smartphone size={15} className="sm:hidden" />
              Print
            </button>
          </div>
        }
      />

      {/* Date Range */}
      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Start Date</label>
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="input-field" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">End Date</label>
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="input-field" />
        </div>
        <button onClick={fetchReport} className="px-5 py-2 bg-gray-900 text-white rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
          Generate
        </button>
      </div>

      {/* Filter Panel */}
      {showFilters && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4 animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Filters</h3>
            {hasFilters && (
              <button onClick={clearFilters} className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700 transition-colors">
                <X size={12} /> Clear All
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1"><MapPin size={12} className="inline mr-1" />Site</label>
              <select value={filterSite} onChange={e => setFilterSite(e.target.value)} className="select-field">
                <option value="">All Sites</option>
                {sites.map(s => <option key={s.id} value={s.id}>{s.site_name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1"><Truck size={12} className="inline mr-1" />TM Number</label>
              <select value={filterTM} onChange={e => setFilterTM(e.target.value)} className="select-field">
                <option value="">All TMs</option>
                {tms.map(t => <option key={t.id} value={t.tm_number}>{t.tm_number}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1"><Construction size={12} className="inline mr-1" />Concrete Grade</label>
              <select value={filterGrade} onChange={e => setFilterGrade(e.target.value)} className="select-field">
                <option value="">All Grades</option>
                {CONCRETE_GRADES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Report */}
      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <SummaryCard label="Total Bills" value={String(bills.length)} />
            <SummaryCard label="Total MCB" value={`${totalMcb.toFixed(3)}`} />
            <SummaryCard label="Total Amount" value={`Rs. ${totalAmount.toFixed(2)}`} accent />
            <SummaryCard label="Period" value={`${formatDate(startDate)} - ${formatDate(endDate)}`} />
          </div>

          {/* Printable Content */}
          <div ref={printRef}>
            {/* Company Header - visible in print */}
            <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '10px', marginBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '4px' }}>
                <img
                  src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg"
                  alt="Logo"
                  style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '6px' }}
                />
                <div>
                  <div style={{ fontSize: '20px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
                  <div style={{ fontSize: '11px', marginTop: '2px' }}>Ready Mix Concrete Supplier | Sayla, Gujarat</div>
                  <div style={{ fontSize: '10px', color: '#555' }}>GST No: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod</div>
                </div>
              </div>
              <div style={{ fontSize: '14px', fontWeight: 'bold', marginTop: '6px', letterSpacing: '2px' }}>RMC DAILY SALES REPORT</div>
              <div style={{ fontSize: '11px', marginTop: '2px', color: '#333' }}>Period: {formatDate(startDate)} to {formatDate(endDate)}</div>
            </div>

            {bills.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
                <Calendar size={32} className="text-gray-200" />
                <p className="text-sm">No RMC bills found for the selected period.</p>
              </div>
            ) : (
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-900 text-white">
                        <th className="px-3 py-2.5 text-left text-xs font-semibold">Date</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold">Bill No</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold">Site Name</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold hidden sm:table-cell">Location</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold">Grade</th>
                        <th className="px-3 py-2.5 text-left text-xs font-semibold">TM No</th>
                        <th className="px-3 py-2.5 text-right text-xs font-semibold">MCB</th>
                        <th className="px-3 py-2.5 text-right text-xs font-semibold">Carting Bhada</th>
                        <th className="px-3 py-2.5 text-right text-xs font-semibold">Amount (Rs.)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bills.map((bill, i) => (
                        <tr
                          key={bill.id}
                          className={`border-b border-gray-100 hover:bg-gray-50 transition-colors animate-slide-up ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}
                          style={{ animationDelay: `${i * 20}ms` }}
                        >
                          <td className="px-3 py-2.5 text-xs text-gray-600">{formatDate(bill.bill_date)}</td>
                          <td className="px-3 py-2.5 text-xs font-semibold text-gray-900">{bill.bill_number}</td>
                          <td className="px-3 py-2.5 text-xs text-gray-700">{bill.site_name}</td>
                          <td className="px-3 py-2.5 text-xs text-gray-500 hidden sm:table-cell">{bill.site_location}</td>
                          <td className="px-3 py-2.5 text-xs"><span className="px-1.5 py-0.5 bg-gray-100 rounded text-gray-700 font-medium">{bill.concrete_grade}</span></td>
                          <td className="px-3 py-2.5 text-xs text-gray-700">{bill.tm_number}</td>
                          <td className="px-3 py-2.5 text-xs text-right font-semibold text-gray-900">{Number(bill.quantity_mcb).toFixed(3)}</td>
                          <td className="px-3 py-2.5 text-xs text-right text-gray-600">{Number(bill.carting_bhada).toFixed(2)}</td>
                          <td className="px-3 py-2.5 text-xs text-right font-semibold text-gray-900">{Number(bill.total_amount).toFixed(2)}</td>
                        </tr>
                      ))}
                      <tr className="bg-gray-900 text-white">
                        <td className="px-3 py-3 text-xs font-bold" colSpan={6}>TOTAL</td>
                        <td className="px-3 py-3 text-xs text-right font-bold">{totalMcb.toFixed(3)}</td>
                        <td className="px-3 py-3 text-xs text-right font-bold">-</td>
                        <td className="px-3 py-3 text-xs text-right font-bold">Rs. {totalAmount.toFixed(2)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Print Footer */}
            <div style={{ borderTop: '1px solid #000', marginTop: '16px', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
              D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | This is a computer generated report
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function SummaryCard({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className={`rounded-xl border p-3 ${accent ? 'bg-gray-900 border-gray-800 text-white' : 'bg-white border-gray-200 text-gray-900'}`}>
      <p className={`text-xs mb-0.5 ${accent ? 'text-gray-400' : 'text-gray-500'}`}>{label}</p>
      <p className="text-base font-bold">{value}</p>
    </div>
  );
}
