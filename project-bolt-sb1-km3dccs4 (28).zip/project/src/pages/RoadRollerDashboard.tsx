import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, type RoadRollerBill, type RoadRoller, type Site } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Trash2, Pencil, X, Check, Loader2, Printer, Smartphone, IndianRupee, FileText, Filter } from 'lucide-react';

const RATE_TYPE_LABELS: Record<string, string> = {
  per_hour_rent: 'Per Hour Rent',
  '8_hour_shift': '8 Hour Shift',
  '12_hour_shift': '12 Hour Shift',
  per_day_full: 'Per Day Full Package',
  per_km_village: 'Per Km (3.75m)',
  per_sqm_stab: 'Per Sqm Stab.',
};

const LOGO = 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg';

export default function RoadRollerDashboard() {
  const [bills, setBills] = useState<RoadRollerBill[]>([]);
  const [rollers, setRollers] = useState<RoadRoller[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);

  const [showPayModal, setShowPayModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedBill, setSelectedBill] = useState<RoadRollerBill | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payError, setPayError] = useState('');
  const [editForm, setEditForm] = useState({ quantity: '', rate: '', notes: '', bill_date: '' });
  const [editError, setEditError] = useState('');
  const [editSaving, setEditSaving] = useState(false);
  const [filterSite, setFilterSite] = useState('');
  const [filterRoller, setFilterRoller] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.from('road_rollers').select('*').order('company_name').then(({ data }) => setRollers(data ?? []));
    supabase.from('sites').select('*').order('site_name').then(({ data }) => setSites(data ?? []));
  }, []);

  useEffect(() => { fetchBills(); }, [filterSite, filterRoller]);

  async function fetchBills() {
    setLoading(true);
    let q = supabase.from('road_roller_bills').select('*').order('created_at', { ascending: false });
    if (filterSite) q = q.eq('site_id', filterSite);
    if (filterRoller) q = q.eq('roller_id', filterRoller);
    const { data } = await q;
    setBills(data ?? []);
    setLoading(false);
  }

  const totalBills = bills.length;
  const totalAmount = bills.reduce((a, b) => a + Number(b.amount), 0);
  const totalQty = bills.reduce((a, b) => a + Number(b.quantity), 0);
  const totalPaid = bills.reduce((a, b) => a + Number(b.paid_amount), 0);
  const totalPending = bills.reduce((a, b) => a + Number(b.pending_amount), 0);
  const fmt = (n: number) => `Rs. ${Number(n).toFixed(2)}`;

  function openPayModal(b: RoadRollerBill) { setSelectedBill(b); setPayAmount(String(b.pending_amount)); setPayError(''); setShowPayModal(true); }
  function openEditModal(b: RoadRollerBill) { setSelectedBill(b); setEditForm({ quantity: String(b.quantity), rate: String(b.rate), notes: b.notes, bill_date: b.bill_date }); setEditError(''); setShowEditModal(true); }

  async function handlePay() {
    if (!selectedBill) return; setPayError('');
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) { setPayError('Enter a valid amount.'); return; }
    if (amt > selectedBill.pending_amount) { setPayError('Amount exceeds pending balance.'); return; }
    const newPaid = Number(selectedBill.paid_amount) + amt;
    const newPending = Number(selectedBill.pending_amount) - amt;
    const { error: err } = await supabase.from('road_roller_bills').update({ paid_amount: newPaid, pending_amount: newPending, payment_status: newPending <= 0 ? 'paid' : 'partial' }).eq('id', selectedBill.id);
    if (err) { setPayError(err.message); return; }
    setShowPayModal(false); fetchBills();
  }

  async function handleEdit() {
    if (!selectedBill) return; setEditError('');
    if (!editForm.quantity || !editForm.rate) { setEditError('Quantity and rate are required.'); return; }
    setEditSaving(true);
    const newAmount = parseFloat(editForm.rate) * parseFloat(editForm.quantity);
    const newPending = newAmount - Number(selectedBill.paid_amount);
    if (newPending < 0) { setEditError('Paid amount exceeds new total.'); setEditSaving(false); return; }
    const { error: err } = await supabase.from('road_roller_bills').update({
      quantity: parseFloat(editForm.quantity), rate: parseFloat(editForm.rate), amount: newAmount, pending_amount: newPending,
      notes: editForm.notes, bill_date: editForm.bill_date,
      payment_status: newPending <= 0 ? 'paid' : selectedBill.payment_status === 'paid' ? 'partial' : selectedBill.payment_status
    }).eq('id', selectedBill.id);
    if (err) { setEditError(err.message); setEditSaving(false); return; }
    setEditSaving(false); setShowEditModal(false); fetchBills();
  }

  async function deleteBill(id: string) {
    if (!confirm('Delete this bill?')) return;
    await supabase.from('road_roller_bills').delete().eq('id', id);
    fetchBills();
  }

  function printWindow(html: string, w = 800, h = 900) {
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }
      doc.open(); doc.write(html); doc.close();
      iframe.contentWindow?.focus();
      setTimeout(() => { try { iframe.contentWindow?.print(); } catch {} setTimeout(() => document.body.removeChild(iframe), 1000); }, 500);
    } else {
      const win = window.open('', '_blank', `width=${w},height=${h}`);
      if (!win) return;
      win.document.write(html); win.document.close(); win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }

  const printBill = useCallback((b: RoadRollerBill) => {
    printWindow(`<html><head><title>Bill #${b.bill_number}</title><style>
      *{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;padding:30px;background:#fff}
      .header{text-align:center;border-bottom:2px solid #000;padding-bottom:10px;margin-bottom:15px}
      .logo{width:50px;height:50px;border-radius:6px;object-fit:cover}.company{font-size:20px;font-weight:bold;letter-spacing:1px}
      .title{font-size:14px;font-weight:bold;margin-top:10px;letter-spacing:1px}
      .info-box{border:1px solid #000;margin-bottom:12px;padding:10px}
      .row{display:flex;justify-content:space-between;padding:4px 0;font-size:11px;border-bottom:1px solid #eee}.row:last-child{border-bottom:none}
      .label{color:#555}.value{font-weight:bold}
      .amount-box{background:#000;color:#fff;padding:10px;text-align:center;font-size:16px;font-weight:bold;margin-top:12px;border-radius:4px}
      .signature{margin-top:50px;display:flex;justify-content:space-between}
      .sig-box{text-align:center;width:150px}.sig-line{border-top:1px solid #000;margin-top:40px;padding-top:5px;font-size:10px}
      @media print{body{margin:0;padding:15px}}
    </style></head><body>
      <div class="header">
        <img src="${LOGO}" class="logo" alt="Logo" />
        <div class="company">D ROCK SAND PVT LTD</div>
        <div style="font-size:10px;color:#555;margin-top:2px">Sayla, Gujarat | GST: 7EGH5HFN0401Z</div>
        <div class="title">ROAD ROLLER BILL - #${b.bill_number}</div>
        <div style="font-size:10px;margin-top:4px">Date: ${new Date(b.bill_date).toLocaleDateString('en-IN')}</div>
      </div>
      <div class="info-box">
        <div class="row"><span class="label">Bill No:</span><span class="value">${b.bill_number}</span></div>
        <div class="row"><span class="label">Site:</span><span class="value">${b.site_name}</span></div>
        <div class="row"><span class="label">Road Roller:</span><span class="value">${b.roller_name}</span></div>
        <div class="row"><span class="label">Code:</span><span class="value">${b.roller_code || '-'}</span></div>
      </div>
      <div class="info-box">
        <div class="row"><span class="label">Rate Type:</span><span class="value">${RATE_TYPE_LABELS[b.rate_type] || b.rate_type}</span></div>
        <div class="row"><span class="label">Rate:</span><span class="value">Rs. ${Number(b.rate).toFixed(2)} / ${b.unit}</span></div>
        <div class="row"><span class="label">Quantity:</span><span class="value">${b.quantity} ${b.unit}</span></div>
        <div class="row"><span class="label">Total Amount:</span><span class="value">Rs. ${Number(b.amount).toFixed(2)}</span></div>
        <div class="row"><span class="label">Paid:</span><span class="value" style="color:green">Rs. ${Number(b.paid_amount).toFixed(2)}</span></div>
        <div class="row"><span class="label">Pending:</span><span class="value" style="color:red">Rs. ${Number(b.pending_amount).toFixed(2)}</span></div>
      </div>
      <div class="amount-box">NET PAYABLE: Rs. ${Number(b.pending_amount).toFixed(2)}</div>
      ${b.notes ? `<div style="margin-top:10px;font-size:10px;color:#555">Notes: ${b.notes}</div>` : ''}
      <div class="signature">
        <div class="sig-box"><div class="sig-line">Contractor</div></div>
        <div class="sig-box"><div class="sig-line">Authorized Signatory</div></div>
      </div>
      <div style="text-align:center;margin-top:20px;font-size:9px;color:#888">D Rock Sand Pvt Ltd | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod | Computer Generated Document</div>
    </body></html>`);
  }, []);

  const printSlip = useCallback((b: RoadRollerBill) => {
    printWindow(`<html><head><title>Slip #${b.bill_number}</title><style>
      *{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;padding:15px;background:#fff;width:280px;margin:0 auto}
      .header{text-align:center;padding-bottom:8px;border-bottom:1px dashed #000;margin-bottom:8px}
      .company{font-size:14px;font-weight:bold}.title{font-size:11px;font-weight:bold;margin-top:6px}
      .row{display:flex;justify-content:space-between;padding:3px 0;font-size:10px}.label{color:#555}.value{font-weight:bold}
      .line{border-top:1px dashed #000;margin:6px 0}.amount{text-align:center;font-size:14px;font-weight:bold;margin:8px 0}
      @media print{body{margin:0;padding:10px;width:100%}}
    </style></head><body>
      <div class="header"><div class="company">D ROCK SAND PVT LTD</div><div style="font-size:8px;color:#555;margin-top:2px">Sayla, Gujarat</div><div class="title">ROAD ROLLER SLIP</div></div>
      <div class="row"><span class="label">Bill #:</span><span class="value">${b.bill_number}</span></div>
      <div class="row"><span class="label">Date:</span><span class="value">${new Date(b.bill_date).toLocaleDateString('en-IN')}</span></div>
      <div class="row"><span class="label">Site:</span><span class="value">${b.site_name}</span></div>
      <div class="row"><span class="label">Road Roller:</span><span class="value">${b.roller_name}</span></div>
      <div class="line"></div>
      <div class="row"><span class="label">Rate Type:</span><span class="value">${RATE_TYPE_LABELS[b.rate_type] || b.rate_type}</span></div>
      <div class="row"><span class="label">Rate:</span><span class="value">Rs. ${Number(b.rate).toFixed(2)}/${b.unit}</span></div>
      <div class="row"><span class="label">Qty:</span><span class="value">${b.quantity} ${b.unit}</span></div>
      <div class="line"></div>
      <div class="row"><span class="label">Amount:</span><span class="value">Rs. ${Number(b.amount).toFixed(2)}</span></div>
      <div class="row"><span class="label">Paid:</span><span class="value" style="color:green">Rs. ${Number(b.paid_amount).toFixed(2)}</span></div>
      <div class="row"><span class="label">Pending:</span><span class="value" style="color:red">Rs. ${Number(b.pending_amount).toFixed(2)}</span></div>
      <div class="amount">Rs. ${Number(b.pending_amount).toFixed(2)}</div>
      <div style="text-align:center;font-size:8px;color:#888;margin-top:8px">D Rock Sand Pvt Ltd</div>
    </body></html>`, 320, 600);
  }, []);

  const handlePrintReport = useCallback(() => {
    const el = printRef.current; if (!el) return;
    printWindow(`<html><head><title>Road Roller Report</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#fff;padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{width:100%;border-collapse:collapse;font-size:10px}th,td{border:1px solid #000;padding:4px 6px;text-align:left}th{background:#000;color:#fff;font-weight:bold}@media print{body{margin:0}}</style></head><body>${el.innerHTML}</body></html>`, 1000, 700);
  }, []);

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Road Roller Bills"
        subtitle="View and manage all road roller bills"
        actions={
          <button onClick={handlePrintReport} disabled={bills.length === 0} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed">
            <Printer size={15} className="hidden sm:block" /><Smartphone size={15} className="sm:hidden" /> Print Report
          </button>
        }
      />

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
        {[
          { label: 'Total Bills', value: totalBills, cls: 'border-gray-200 bg-white', vcls: 'text-gray-900' },
          { label: 'Total Quantity', value: totalQty, cls: 'border-gray-200 bg-white', vcls: 'text-gray-900' },
          { label: 'Total Amount', value: fmt(totalAmount), cls: 'border-gray-200 bg-white', vcls: 'text-gray-900' },
          { label: 'Total Paid', value: fmt(totalPaid), cls: 'border-green-200 bg-green-50', vcls: 'text-green-700' },
          { label: 'Pending', value: fmt(totalPending), cls: 'border-red-200 bg-red-50', vcls: 'text-red-700' },
        ].map(({ label, value, cls, vcls }) => (
          <div key={label} className={`rounded-xl border p-3 ${cls}`}>
            <p className="text-xs text-gray-500">{label}</p>
            <p className={`text-lg font-bold ${vcls}`}>{value}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${showFilters ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}>
          <Filter size={15} /> Filters {(filterSite || filterRoller) && <span className="w-2 h-2 rounded-full bg-red-500" />}
        </button>
      </div>

      {showFilters && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Filters</h3>
            {(filterSite || filterRoller) && <button onClick={() => { setFilterSite(''); setFilterRoller(''); }} className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700"><X size={12} /> Reset</button>}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select value={filterSite} onChange={e => setFilterSite(e.target.value)} className="select-field">
              <option value="">All Sites</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
            </select>
            <select value={filterRoller} onChange={e => setFilterRoller(e.target.value)} className="select-field">
              <option value="">All Road Rollers</option>
              {rollers.map(r => <option key={r.id} value={r.id}>{r.company_name} - {r.model} ({r.code || 'No code'})</option>)}
            </select>
          </div>
        </div>
      )}

      {/* Pay Modal */}
      {showPayModal && selectedBill && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">Pay Bill #{selectedBill.bill_number}</h2>
              <button onClick={() => setShowPayModal(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              {payError && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{payError}</p>}
              <p className="text-sm text-gray-600">Pending: <span className="font-bold text-red-700">{fmt(selectedBill.pending_amount)}</span></p>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Amount to Pay</label>
                <input type="number" step="0.01" value={payAmount} onChange={e => setPayAmount(e.target.value)} className="input-field" />
              </div>
            </div>
            <div className="px-6 pb-6">
              <button onClick={handlePay} className="w-full py-3 rounded-xl bg-green-600 text-white text-sm font-semibold hover:bg-green-700 flex items-center justify-center gap-2">
                <IndianRupee size={16} /> Pay {fmt(parseFloat(payAmount) || 0)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedBill && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">Edit Bill #{selectedBill.bill_number}</h2>
              <button onClick={() => setShowEditModal(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              {editError && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{editError}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Bill Date</label>
                <input type="date" value={editForm.bill_date} onChange={e => setEditForm(f => ({ ...f, bill_date: e.target.value }))} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Rate (Rs.)</label>
                <input type="number" step="0.01" value={editForm.rate} onChange={e => setEditForm(f => ({ ...f, rate: e.target.value }))} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Quantity ({selectedBill.unit})</label>
                <input type="number" step="0.01" value={editForm.quantity} onChange={e => setEditForm(f => ({ ...f, quantity: e.target.value }))} className="input-field" />
              </div>
              <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                <div className="flex justify-between text-sm font-bold">
                  <span>New Amount:</span>
                  <span>{fmt(parseFloat(editForm.rate || '0') * parseFloat(editForm.quantity || '0'))}</span>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                <textarea value={editForm.notes} onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))} rows={2} className="input-field resize-none" />
              </div>
            </div>
            <div className="px-6 pb-6">
              <button onClick={handleEdit} disabled={editSaving} className="w-full py-3 rounded-xl bg-gray-900 text-white text-sm font-semibold hover:bg-gray-700 flex items-center justify-center gap-2 disabled:opacity-40">
                {editSaving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />} Update Bill
              </button>
            </div>
          </div>
        </div>
      )}

      <div ref={printRef}>
        <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '10px', marginBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '4px' }}>
            <img src={LOGO} alt="Logo" style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '6px' }} />
            <div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
              <div style={{ fontSize: '11px', marginTop: '2px' }}>Road Roller Bills Report | Sayla, Gujarat</div>
              <div style={{ fontSize: '10px', color: '#555' }}>GST No: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod</div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '14px', flexWrap: 'wrap' }}>
          {[['Bills', totalBills, '#f3f4f6', '#111'], ['Amount', fmt(totalAmount), '#f3f4f6', '#111'], ['Qty', totalQty, '#f3f4f6', '#111'], ['Paid', fmt(totalPaid), '#dcfce7', '#166534'], ['Pending', fmt(totalPending), '#fee2e2', '#991b1b']].map(([l, v, bg, c]) => (
            <div key={String(l)} style={{ display: 'inline-block', padding: '6px 12px', borderRadius: '4px', fontSize: '11px', fontWeight: 'bold', background: String(bg), color: String(c) }}>{l}: {String(v)}</div>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
        ) : bills.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
            <FileText size={32} className="text-gray-200" />
            <p className="text-sm">No bills found.</p>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-gray-900 text-white">
                    {['Bill #', 'Date', 'Site', 'Road Roller', 'Rate Type', 'Rate', 'Qty', 'Amount', 'Paid', 'Pending', 'Status', 'Actions'].map(h => (
                      <th key={h} className="px-2 py-2 text-left font-semibold whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {bills.map((b, i) => (
                    <tr key={b.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                      <td className="px-2 py-2 font-semibold whitespace-nowrap">{b.bill_number}</td>
                      <td className="px-2 py-2 whitespace-nowrap">{new Date(b.bill_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</td>
                      <td className="px-2 py-2">{b.site_name}</td>
                      <td className="px-2 py-2 font-medium">{b.roller_name}</td>
                      <td className="px-2 py-2"><span className="px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-700 text-xs whitespace-nowrap">{RATE_TYPE_LABELS[b.rate_type] || b.rate_type}</span></td>
                      <td className="px-2 py-2 text-right whitespace-nowrap">{Number(b.rate).toFixed(2)}</td>
                      <td className="px-2 py-2 text-right">{b.quantity}</td>
                      <td className="px-2 py-2 text-right font-bold whitespace-nowrap">{fmt(b.amount)}</td>
                      <td className="px-2 py-2 text-right text-green-700 whitespace-nowrap">{fmt(b.paid_amount)}</td>
                      <td className="px-2 py-2 text-right text-red-700 font-medium whitespace-nowrap">{fmt(b.pending_amount)}</td>
                      <td className="px-2 py-2 text-center">
                        <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${b.payment_status === 'paid' ? 'bg-green-100 text-green-800' : b.payment_status === 'partial' ? 'bg-orange-100 text-orange-800' : 'bg-red-100 text-red-800'}`}>
                          {b.payment_status.charAt(0).toUpperCase() + b.payment_status.slice(1)}
                        </span>
                      </td>
                      <td className="px-2 py-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => printBill(b)} className="p-1 rounded text-gray-400 hover:text-gray-700 hover:bg-gray-100" title="Print Bill"><Printer size={12} /></button>
                          <button onClick={() => printSlip(b)} className="p-1 rounded text-gray-400 hover:text-gray-700 hover:bg-gray-100" title="Print Slip"><FileText size={12} /></button>
                          <button onClick={() => openPayModal(b)} disabled={b.pending_amount <= 0} className="p-1 rounded text-gray-400 hover:text-green-600 hover:bg-green-50 disabled:opacity-40" title="Pay"><IndianRupee size={12} /></button>
                          <button onClick={() => openEditModal(b)} className="p-1 rounded text-gray-400 hover:text-gray-700 hover:bg-gray-100" title="Edit"><Pencil size={12} /></button>
                          <button onClick={() => deleteBill(b.id)} className="p-1 rounded text-gray-400 hover:text-red-600 hover:bg-red-50" title="Delete"><Trash2 size={12} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-100 font-bold text-xs">
                    <td className="px-2 py-2" colSpan={6}>TOTAL</td>
                    <td className="px-2 py-2 text-right">{totalQty}</td>
                    <td className="px-2 py-2 text-right">{fmt(totalAmount)}</td>
                    <td className="px-2 py-2 text-right text-green-700">{fmt(totalPaid)}</td>
                    <td className="px-2 py-2 text-right text-red-700">{fmt(totalPending)}</td>
                    <td /><td />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
        <div style={{ borderTop: '1px solid #000', marginTop: '16px', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
          D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | Computer Generated Report
        </div>
      </div>
    </div>
  );
}
