import { useState, useEffect } from 'react';
import { supabase, type Truck } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Truck as TruckIcon, Trash2, Pencil, X, Check, Loader2 } from 'lucide-react';

const emptyForm = { select_code: '', truck_number: '', wheels: '6' };
const WHEEL_OPTIONS = [4, 6, 10, 12, 14, 18, 22];

export default function TrucksPage() {
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');

  useEffect(() => { fetchTrucks(); }, []);

  async function fetchTrucks() {
    setLoading(true);
    const { data } = await supabase.from('trucks').select('*').order('created_at', { ascending: false });
    setTrucks(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.select_code || !form.truck_number || !form.wheels) {
      setError('All fields are required.');
      return;
    }
    setSaving(true);
    const payload = { select_code: form.select_code, truck_number: form.truck_number.toUpperCase(), wheels: parseInt(form.wheels) };
    if (editId) {
      const { error: err } = await supabase.from('trucks').update(payload).eq('id', editId);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('trucks').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditId(null);
    setForm(emptyForm);
    fetchTrucks();
  }

  function startEdit(truck: Truck) {
    setEditId(truck.id);
    setForm({ select_code: truck.select_code, truck_number: truck.truck_number, wheels: String(truck.wheels) });
    setShowForm(true);
    setError('');
  }

  async function deleteTruck(id: string) {
    if (!confirm('Delete this truck?')) return;
    await supabase.from('trucks').delete().eq('id', id);
    fetchTrucks();
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Trucks"
        subtitle="Manage truck registry"
        actions={
          <button
            onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); setError(''); }}
            className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors duration-200"
          >
            <Plus size={16} /> Add Truck
          </button>
        }
      />

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editId ? 'Edit Truck' : 'Add New Truck'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700 transition-colors"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Select Code</label>
                <input type="text" value={form.select_code} onChange={e => setForm(f => ({ ...f, select_code: e.target.value }))} placeholder="e.g. GJ-05" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Truck Number</label>
                <input type="text" value={form.truck_number} onChange={e => setForm(f => ({ ...f, truck_number: e.target.value.toUpperCase() }))} placeholder="e.g. GJ05AB1234" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Wheels</label>
                <select value={form.wheels} onChange={e => setForm(f => ({ ...f, wheels: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent bg-white">
                  {WHEEL_OPTIONS.map(w => <option key={w} value={w}>{w} Wheels</option>)}
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editId ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : trucks.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center"><TruckIcon size={24} className="text-gray-300" /></div>
          <p className="text-sm">No trucks added yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {trucks.map((truck, i) => (
            <div key={truck.id} className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow duration-200 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center"><TruckIcon size={14} className="text-gray-500" /></div>
                  <div>
                    <p className="font-bold text-gray-900 text-sm">{truck.truck_number}</p>
                    <p className="text-xs text-gray-400">Code: {truck.select_code}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => startEdit(truck)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                  <button onClick={() => deleteTruck(truck.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg px-3 py-2 text-center">
                <p className="text-xs text-gray-400">Wheels</p>
                <p className="font-bold text-gray-800">{truck.wheels}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
