import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, type Employee, type EmployeeAttendance, type EmployeeAdvance, type SalaryPayment } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Calculator, Printer, Smartphone, Pencil, Trash2, X, Check, Loader2, IndianRupee, Users, Filter, FileText } from 'lucide-react';

export default function SalaryPage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payments, setPayments] = useState<SalaryPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCalc, setShowCalc] = useState(false);
  const [showPayModal, setShowPayModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<SalaryPayment | null>(null);

  // Filters
  const [selectedMonth, setSelectedMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; });
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Calculator state
  const [calcEmployee, setCalcEmployee] = useState('');
  const [calcMonth, setCalcMonth] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; });
  const [calcAdjustment, setCalcAdjustment] = useState('0'); // Manual adjustment (+ or -)
  const [calcData, setCalcData] = useState<{
    basic: number; daysPresent: number; daysAbsent: number; daysHalf: number;
    presentAmount: number; halfDayAmount: number; advanceDeduction: number; adjustment: number; netSalary: number;
  } | null>(null);

  // Pay modal
  const [payAmount, setPayAmount] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [payError, setPayError] = useState('');

  const printRef = useRef<HTMLDivElement>(null);
  const slipRef = useRef<HTMLDivElement>(null);

  const [year, month] = selectedMonth.split('-').map(Number);
  const monthName = new Date(year, month - 1, 1).toLocaleString('en-IN', { month: 'long', year: 'numeric' });

  useEffect(() => {
    supabase.from('employees').select('*').order('name').then(({ data }) => setEmployees(data ?? []));
  }, []);

  useEffect(() => { fetchPayments(); }, [selectedMonth, selectedEmployee]);

  async function fetchPayments() {
    setLoading(true);
    let query = supabase.from('salary_payments').select('*').eq('month', month).eq('year', year).order('created_at', { ascending: false });
    if (selectedEmployee) query = query.eq('employee_id', selectedEmployee);
    const { data } = await query;
    setPayments(data ?? []);
    setLoading(false);
  }

  const totalNetSalary = payments.reduce((a, p) => a + Number(p.net_salary), 0);
  const totalPaid = payments.reduce((a, p) => a + Number(p.paid_amount), 0);
  const totalPending = payments.reduce((a, p) => a + Number(p.pending_amount), 0);

  async function calculateSalary() {
    if (!calcEmployee || !calcMonth) return;
    const [y, m] = calcMonth.split('-').map(Number);
    const emp = employees.find(e => e.id === calcEmployee);
    if (!emp) return;

    const startDate = `${y}-${String(m).padStart(2, '0')}-01`;
    const endDate = `${y}-${String(m).padStart(2, '0')}-${String(new Date(y, m, 0).getDate()).padStart(2, '0')}`;

    // Attendance
    const { data: attendance } = await supabase.from('employee_attendance').select('*').eq('employee_id', calcEmployee).gte('attendance_date', startDate).lte('attendance_date', endDate);
    const daysPresent = (attendance ?? []).filter(r => r.status === 'present').length;
    const daysAbsent = (attendance ?? []).filter(r => r.status === 'absent').length;
    const daysHalf = (attendance ?? []).filter(r => r.status === 'half-day').length;

    // Advances in that month
    const { data: advances } = await supabase.from('employee_advances').select('*').eq('employee_id', calcEmployee).gte('advance_date', startDate).lte('advance_date', endDate);
    const advanceDeduction = (advances ?? []).reduce((a, r) => a + Number(r.amount), 0);

    const daysInMonth = new Date(y, m, 0).getDate();
    const basic = Number(emp.salary);
    const perDay = basic / daysInMonth;
    const presentAmount = daysPresent * perDay;
    const halfDayAmount = daysHalf * (perDay / 2);
    const adjustment = parseFloat(calcAdjustment) || 0;
    const netSalary = presentAmount + halfDayAmount - advanceDeduction + adjustment;

    setCalcData({
      basic, daysPresent, daysAbsent, daysHalf,
      presentAmount, halfDayAmount, advanceDeduction, adjustment, netSalary
    });
  }

  useEffect(() => { if (calcEmployee && calcMonth) calculateSalary(); }, [calcEmployee, calcMonth, calcAdjustment]);

  async function handleSavePayment() {
    if (!calcData || !calcEmployee || !calcMonth) return;
    setSaving(true);
    const [y, m] = calcMonth.split('-').map(Number);
    const emp = employees.find(e => e.id === calcEmployee);
    const payload = {
      employee_id: calcEmployee,
      employee_name: emp?.name ?? '',
      month: m,
      year: y,
      basic_salary: calcData.basic,
      days_present: calcData.daysPresent,
      days_absent: calcData.daysAbsent,
      days_half: calcData.daysHalf,
      present_amount: calcData.presentAmount,
      half_day_amount: calcData.halfDayAmount,
      advance_deduction: calcData.advanceDeduction,
      adjustment: calcData.adjustment,
      net_salary: calcData.netSalary,
      paid_amount: 0,
      pending_amount: calcData.netSalary,
      payment_status: 'pending',
      notes: '',
    };
    const { error } = await supabase.from('salary_payments').upsert(payload, { onConflict: 'employee_id,month,year' });
    if (error) { alert(error.message); setSaving(false); return; }
    setSaving(false);
    setShowCalc(false);
    setCalcEmployee('');
    setCalcAdjustment('0');
    setCalcData(null);
    fetchPayments();
  }

  function openPayModal(payment: SalaryPayment) {
    setSelectedPayment(payment);
    setPayAmount(String(payment.pending_amount));
    setPayNotes('');
    setPayError('');
    setShowPayModal(true);
  }

  async function handlePay() {
    if (!selectedPayment) return;
    setPayError('');
    const amount = parseFloat(payAmount);
    if (isNaN(amount) || amount <= 0) { setPayError('Enter a valid amount.'); return; }
    if (amount > selectedPayment.pending_amount) { setPayError('Amount exceeds pending balance.'); return; }
    setSaving(true);
    const newPaid = Number(selectedPayment.paid_amount) + amount;
    const newPending = Number(selectedPayment.pending_amount) - amount;
    const status = newPending <= 0 ? 'paid' : 'partial';
    const { error } = await supabase.from('salary_payments').update({
      paid_amount: newPaid,
      pending_amount: newPending,
      payment_status: status,
      notes: selectedPayment.notes + (payNotes ? `\nPayment: Rs. ${amount.toFixed(2)} - ${payNotes}` : `\nPayment: Rs. ${amount.toFixed(2)}`)
    }).eq('id', selectedPayment.id);
    if (error) { setPayError(error.message); setSaving(false); return; }
    setSaving(false);
    setShowPayModal(false);
    setSelectedPayment(null);
    fetchPayments();
  }

  async function deletePayment(id: string) {
    if (!confirm('Delete this salary record?')) return;
    await supabase.from('salary_payments').delete().eq('id', id);
    fetchPayments();
  }

  const handlePrint = useCallback(() => {
    const el = printRef.current;
    if (!el) return;
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
    const html = `<html><head><title>Salary Report</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#fff;padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{width:100%;border-collapse:collapse;font-size:10px}th,td{border:1px solid #000;padding:4px 6px;text-align:left}th{background:#000;color:#fff;font-weight:bold}.text-right{text-align:right}.paid{color:green;font-weight:bold}.pending{color:red;font-weight:bold}.partial{color:orange;font-weight:bold}.total-row{background:#f0f0f0;font-weight:bold}@media print{body{margin:0}}</style></head><body>${el.innerHTML}</body></html>`;
    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }
      doc.open(); doc.write(html); doc.close();
      iframe.contentWindow?.focus();
      setTimeout(() => { try { iframe.contentWindow?.print(); } catch {} setTimeout(() => document.body.removeChild(iframe), 1000); }, 500);
    } else {
      const win = window.open('', '_blank', 'width=900,height=700');
      if (!win) return;
      win.document.write(html); win.document.close(); win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }, []);

  const printSlip = useCallback((payment: SalaryPayment) => {
    const emp = employees.find(e => e.id === payment.employee_id);
    const slipHtml = `
      <html><head><title>Salary Slip</title>
      <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:Arial,sans-serif;padding:40px;background:#fff}
        .header{text-align:center;border-bottom:2px solid #000;padding-bottom:15px;margin-bottom:20px}
        .logo{width:60px;height:60px;border-radius:8px}
        .company{font-size:22px;font-weight:bold;letter-spacing:2px;margin-top:8px}
        .tagline{font-size:11px;color:#555;margin-top:2px}
        .title{font-size:16px;font-weight:bold;margin-top:15px;letter-spacing:1px}
        .slip-box{border:2px solid #000;padding:20px;margin-bottom:20px}
        .row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #ddd;font-size:12px}
        .row:last-child{border-bottom:none}
        .label{color:#555}
        .value{font-weight:bold}
        .calc-section{margin-top:15px}
        .calc-title{font-size:12px;font-weight:bold;margin-bottom:8px;border-bottom:1px solid #000;padding-bottom:4px}
        .calc-row{display:flex;justify-content:space-between;padding:4px 0;font-size:11px}
        .net-row{background:#f0f0f0;padding:8px;margin-top:10px;font-size:14px;font-weight:bold;display:flex;justify-content:space-between}
        .signature{margin-top:40px;display:flex;justify-content:space-between}
        .sig-box{text-align:center;width:150px}
        .sig-line{border-top:1px solid #000;margin-top:40px;padding-top:5px;font-size:10px}
        @media print{body{margin:0}}
      </style></head>
      <body>
        <div class="header">
          <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg" class="logo" alt="Logo" />
          <div class="company">D ROCK SAND PVT LTD</div>
          <div class="tagline">Sayla, Gujarat | GST: 7EGH5HFN0401Z</div>
          <div class="title">SALARY SLIP - ${new Date(payment.year, payment.month - 1).toLocaleString('en-IN', { month: 'long', year: 'numeric' }).toUpperCase()}</div>
        </div>
        <div class="slip-box">
          <div class="row"><span class="label">Employee Name:</span><span class="value">${payment.employee_name}</span></div>
          <div class="row"><span class="label">Work:</span><span class="value">${emp?.work_name || '-'}</span></div>
          <div class="row"><span class="label">Basic Salary:</span><span class="value">Rs. ${Number(payment.basic_salary).toFixed(2)}</span></div>
        </div>
        <div class="calc-section">
          <div class="calc-title">EARNINGS & DEDUCTIONS</div>
          <div class="calc-row"><span>Days Present (${payment.days_present}):</span><span>Rs. ${Number(payment.present_amount).toFixed(2)}</span></div>
          <div class="calc-row"><span>Half Days (${payment.days_half}):</span><span>Rs. ${Number(payment.half_day_amount).toFixed(2)}</span></div>
          <div class="calc-row"><span>Days Absent:</span><span>${payment.days_absent} days</span></div>
          <div class="calc-row" style="color:#dc2626"><span>Advance Deduction:</span><span>- Rs. ${Number(payment.advance_deduction).toFixed(2)}</span></div>
          <div class="calc-row" style="color:${Number(payment.adjustment) >= 0 ? '#16a34a' : '#dc2626'}"><span>Adjustment:</span><span>${Number(payment.adjustment) >= 0 ? '+' : ''}Rs. ${Number(payment.adjustment).toFixed(2)}</span></div>
          <div class="net-row"><span>NET SALARY:</span><span>Rs. ${Number(payment.net_salary).toFixed(2)}</span></div>
        </div>
        <div style="margin-top:15px;padding:10px;background:#f9f9f9;border:1px solid #ddd">
          <div style="display:flex;justify-content:space-between;font-size:11px">
            <span>Paid: <strong style="color:green">Rs. ${Number(payment.paid_amount).toFixed(2)}</strong></span>
            <span>Pending: <strong style="color:red">Rs. ${Number(payment.pending_amount).toFixed(2)}</strong></span>
          </div>
        </div>
        <div class="signature">
          <div class="sig-box"><div class="sig-line">Employee Signature</div></div>
          <div class="sig-box"><div class="sig-line">Authorized Signatory</div></div>
        </div>
        <div style="text-align:center;margin-top:30px;font-size:9px;color:#888">
          D Rock Sand Pvt Ltd | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod | Computer Generated Document
        </div>
      </body></html>
    `;
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }
      doc.open(); doc.write(slipHtml); doc.close();
      iframe.contentWindow?.focus();
      setTimeout(() => { try { iframe.contentWindow?.print(); } catch {} setTimeout(() => document.body.removeChild(iframe), 1000); }, 500);
    } else {
      const win = window.open('', '_blank', 'width=800,height=900');
      if (!win) return;
      win.document.write(slipHtml); win.document.close(); win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }, [employees]);

  const formatMoney = (n: number) => `Rs. ${Number(n).toFixed(2)}`;

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Salary Management"
        subtitle="Calculate and manage employee salaries"
        actions={
          <div className="flex gap-2">
            <button onClick={handlePrint} disabled={payments.length === 0} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
              <Printer size={15} className="hidden sm:block" /><Smartphone size={15} className="sm:hidden" /> Print Report
            </button>
            <button onClick={() => { setShowCalc(true); setCalcEmployee(''); setCalcMonth(selectedMonth); }} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
              <Calculator size={16} /> Calculate Salary
            </button>
          </div>
        }
      />

      {/* Dashboard Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Total Net Salary</p>
          <p className="text-xl font-bold text-gray-900">{formatMoney(totalNetSalary)}</p>
        </div>
        <div className="rounded-xl border border-green-200 bg-green-50 p-4">
          <p className="text-xs text-green-600">Total Paid</p>
          <p className="text-xl font-bold text-green-700">{formatMoney(totalPaid)}</p>
        </div>
        <div className="rounded-xl border border-red-200 bg-red-50 p-4">
          <p className="text-xs text-red-600">Total Pending</p>
          <p className="text-xl font-bold text-red-700">{formatMoney(totalPending)}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2">
          <span className="text-sm text-gray-700 font-medium">{monthName}</span>
        </div>
        <input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="input-field" />
        <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${showFilters ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}>
          <Filter size={15} /> Filters {selectedEmployee && <span className="w-2 h-2 rounded-full bg-red-500" />}
        </button>
      </div>

      {showFilters && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4 animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Filters</h3>
            {selectedEmployee && <button onClick={() => setSelectedEmployee('')} className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700"><X size={12} /> Clear</button>}
          </div>
          <select value={selectedEmployee} onChange={e => setSelectedEmployee(e.target.value)} className="select-field max-w-[250px]">
            <option value="">All Employees</option>
            {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
      )}

      {/* Calculate Salary Modal */}
      {showCalc && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">Calculate Salary</h2>
              <button onClick={() => setShowCalc(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Employee</label>
                <select value={calcEmployee} onChange={e => setCalcEmployee(e.target.value)} className="select-field">
                  <option value="">-- Select Employee --</option>
                  {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.work_name}) - Rs. {Number(e.salary).toFixed(2)}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Month</label>
                <input type="month" value={calcMonth} onChange={e => setCalcMonth(e.target.value)} className="input-field" />
              </div>

              {calcData && (
                <div className="bg-gray-50 rounded-xl p-4 space-y-2 border border-gray-100">
                  <div className="flex justify-between text-xs"><span className="text-gray-500">Basic Salary:</span><span className="font-semibold">{formatMoney(calcData.basic)}</span></div>
                  <div className="flex justify-between text-xs"><span className="text-gray-500">Days Present:</span><span className="font-semibold text-green-700">{calcData.daysPresent} ({formatMoney(calcData.presentAmount)})</span></div>
                  <div className="flex justify-between text-xs"><span className="text-gray-500">Days Absent:</span><span className="font-semibold text-red-700">{calcData.daysAbsent}</span></div>
                  <div className="flex justify-between text-xs"><span className="text-gray-500">Half Days:</span><span className="font-semibold text-blue-700">{calcData.daysHalf} ({formatMoney(calcData.halfDayAmount)})</span></div>
                  <div className="flex justify-between text-xs text-red-600"><span className="text-gray-500">Advance Deduction:</span><span className="font-semibold">-{formatMoney(calcData.advanceDeduction)}</span></div>
                </div>
              )}

              {/* Manual Adjustment Input */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Amount Adjustment (+/-)</label>
                <input
                  type="number"
                  step="0.01"
                  value={calcAdjustment}
                  onChange={e => setCalcAdjustment(e.target.value)}
                  placeholder="e.g. 500 or -200"
                  className="input-field"
                />
                <p className="text-[10px] text-gray-400 mt-1">Use positive for bonus/extra, negative for deductions</p>
              </div>

              {calcData && (
                <div className="bg-gray-100 rounded-lg p-3 border border-gray-200">
                  <div className="flex justify-between text-sm font-bold"><span className="text-gray-700">Net Salary:</span><span className="text-gray-900">{formatMoney(calcData.netSalary)}</span></div>
                </div>
              )}
            </div>
            <div className="px-6 pb-6">
              <button onClick={handleSavePayment} disabled={!calcData || saving} className="w-full py-3 rounded-xl bg-gray-900 text-white text-sm font-semibold hover:bg-gray-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed">
                {saving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                Save Salary Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pay Modal */}
      {showPayModal && selectedPayment && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">Pay Salary</h2>
              <button onClick={() => setShowPayModal(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              {payError && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{payError}</p>}
              <p className="text-sm text-gray-600">Employee: <span className="font-semibold">{selectedPayment.employee_name}</span></p>
              <p className="text-sm text-gray-600">Pending: <span className="font-bold text-red-700">{formatMoney(selectedPayment.pending_amount)}</span></p>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Amount to Pay</label>
                <input type="number" step="0.01" value={payAmount} onChange={e => setPayAmount(e.target.value)} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                <textarea value={payNotes} onChange={e => setPayNotes(e.target.value)} rows={2} className="input-field resize-none" />
              </div>
            </div>
            <div className="px-6 pb-6">
              <button onClick={handlePay} disabled={saving} className="w-full py-3 rounded-xl bg-green-600 text-white text-sm font-semibold hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed">
                {saving ? <Loader2 size={16} className="animate-spin" /> : <IndianRupee size={16} />}
                Pay Rs. {payAmount || '0'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Printable Content */}
      <div ref={printRef}>
        {/* Print Header */}
        <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '10px', marginBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '4px' }}>
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg" alt="Logo" style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '6px' }} />
            <div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
              <div style={{ fontSize: '11px', marginTop: '2px' }}>Salary Report | Sayla, Gujarat</div>
              <div style={{ fontSize: '10px', color: '#555' }}>GST No: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod</div>
            </div>
          </div>
          <div style={{ fontSize: '14px', fontWeight: 'bold', marginTop: '6px', letterSpacing: '2px' }}>SALARY REPORT - {monthName.toUpperCase()}</div>
        </div>

        {/* Print Summary */}
        <div style={{ display: 'flex', gap: '10px', marginBottom: '14px', flexWrap: 'wrap' }}>
          <div style={{ display: 'inline-block', padding: '8px 16px', borderRadius: '6px', fontSize: '12px', fontWeight: 'bold', background: '#f3f4f6', color: '#111' }}>Total Net: {formatMoney(totalNetSalary)}</div>
          <div style={{ display: 'inline-block', padding: '8px 16px', borderRadius: '6px', fontSize: '12px', fontWeight: 'bold', background: '#dcfce7', color: '#166534' }}>Total Paid: {formatMoney(totalPaid)}</div>
          <div style={{ display: 'inline-block', padding: '8px 16px', borderRadius: '6px', fontSize: '12px', fontWeight: 'bold', background: '#fee2e2', color: '#991b1b' }}>Total Pending: {formatMoney(totalPending)}</div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
        ) : payments.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
            <IndianRupee size={32} className="text-gray-200" />
            <p className="text-sm">No salary records for this month.</p>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-gray-900 text-white">
                    <th className="px-2 py-2 text-left font-semibold">#</th>
                    <th className="px-2 py-2 text-left font-semibold">Employee</th>
                    <th className="px-2 py-2 text-right font-semibold">Basic</th>
                    <th className="px-2 py-2 text-center font-semibold">Present</th>
                    <th className="px-2 py-2 text-center font-semibold">Absent</th>
                    <th className="px-2 py-2 text-center font-semibold">Half</th>
                    <th className="px-2 py-2 text-right font-semibold">Advance</th>
                    <th className="px-2 py-2 text-right font-semibold">Net</th>
                    <th className="px-2 py-2 text-right font-semibold">Paid</th>
                    <th className="px-2 py-2 text-right font-semibold">Pending</th>
                    <th className="px-2 py-2 text-center font-semibold">Status</th>
                    <th className="px-2 py-2 text-center font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.map((p, i) => (
                    <tr key={p.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                      <td className="px-2 py-2 text-gray-500">{i + 1}</td>
                      <td className="px-2 py-2 font-semibold text-gray-900">{p.employee_name}</td>
                      <td className="px-2 py-2 text-right text-gray-700">{formatMoney(p.basic_salary)}</td>
                      <td className="px-2 py-2 text-center text-green-700 font-medium">{p.days_present}</td>
                      <td className="px-2 py-2 text-center text-red-700 font-medium">{p.days_absent}</td>
                      <td className="px-2 py-2 text-center text-blue-700 font-medium">{p.days_half}</td>
                      <td className="px-2 py-2 text-right text-red-600 font-medium">-{formatMoney(p.advance_deduction)}</td>
                      <td className="px-2 py-2 text-right font-bold text-gray-900">{formatMoney(p.net_salary)}</td>
                      <td className="px-2 py-2 text-right text-green-700 font-medium">{formatMoney(p.paid_amount)}</td>
                      <td className="px-2 py-2 text-right text-red-700 font-medium">{formatMoney(p.pending_amount)}</td>
                      <td className="px-2 py-2 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${p.payment_status === 'paid' ? 'bg-green-100 text-green-800' : p.payment_status === 'partial' ? 'bg-orange-100 text-orange-800' : 'bg-red-100 text-red-800'}`}>
                          {p.payment_status.charAt(0).toUpperCase() + p.payment_status.slice(1)}
                        </span>
                      </td>
                      <td className="px-2 py-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => printSlip(p)} className="p-1 rounded text-gray-400 hover:text-gray-700 hover:bg-gray-100" title="Print Slip"><FileText size={13} /></button>
                          <button onClick={() => openPayModal(p)} disabled={p.pending_amount <= 0} className="p-1 rounded text-gray-400 hover:text-green-600 hover:bg-green-50 disabled:opacity-40" title="Pay"><IndianRupee size={13} /></button>
                          <button onClick={() => deletePayment(p.id)} className="p-1 rounded text-gray-400 hover:text-red-600 hover:bg-red-50" title="Delete"><Trash2 size={13} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-100 font-bold">
                    <td className="px-2 py-2" colSpan={7}>TOTAL</td>
                    <td className="px-2 py-2 text-right">{formatMoney(totalNetSalary)}</td>
                    <td className="px-2 py-2 text-right text-green-700">{formatMoney(totalPaid)}</td>
                    <td className="px-2 py-2 text-right text-red-700">{formatMoney(totalPending)}</td>
                    <td /><td />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}

        {/* Print Footer */}
        <div style={{ borderTop: '1px solid #000', marginTop: '16px', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
          D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | This is a computer generated report
        </div>
      </div>
    </div>
  );
}
