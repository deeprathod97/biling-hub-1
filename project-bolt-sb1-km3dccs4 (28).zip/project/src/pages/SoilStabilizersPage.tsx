import { useState, useEffect } from 'react';
import { supabase, type SoilStabilizer } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, Layers } from 'lucide-react';

export default function SoilStabilizersPage() {
  const [items, setItems] = useState<SoilStabilizer[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<SoilStabilizer | null>(null);
  const [form, setForm] = useState({ company_name: '', model: '', code: '' });
  const [error, setError] = useState('');

  useEffect(() => { fetchItems(); }, []);

  async function fetchItems() {
    setLoading(true);
    const { data } = await supabase.from('soil_stabilizers').select('*').order('created_at', { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  }

  function openAdd() {
    setEditItem(null);
    setForm({ company_name: '', model: '', code: '' });
    setError('');
    setShowForm(true);
  }

  function openEdit(item: SoilStabilizer) {
    setEditItem(item);
    setForm({ company_name: item.company_name, model: item.model, code: item.code });
    setError('');
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.company_name || !form.model) { setError('Company and Model are required.'); return; }
    setSaving(true);
    if (editItem) {
      const { error: err } = await supabase.from('soil_stabilizers').update(form).eq('id', editItem.id);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('soil_stabilizers').insert(form);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    fetchItems();
  }

  async function deleteItem(id: string) {
    if (!confirm('Delete this soil stabilizer?')) return;
    await supabase.from('soil_stabilizer_rates').delete().eq('stabilizer_id', id);
    await supabase.from('soil_stabilizers').delete().eq('id', id);
    fetchItems();
  }

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Soil Stabilizers"
        subtitle="Manage soil stabilizer machines and equipment"
        actions={
          <button onClick={openAdd} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700">
            <Plus size={16} /> Add Soil Stabilizer
          </button>
        }
      />

      <div className="rounded-xl border border-gray-200 bg-white p-3 mb-5 inline-block">
        <p className="text-xs text-gray-500">Total Soil Stabilizers</p>
        <p className="text-xl font-bold text-gray-900">{items.length}</p>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editItem ? 'Edit' : 'Add'} Soil Stabilizer</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Company Name</label>
                <input type="text" value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))} className="input-field" placeholder="e.g. Wirtgen, Caterpillar, Hamm" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Model</label>
                <input type="text" value={form.model} onChange={e => setForm(f => ({ ...f, model: e.target.value }))} className="input-field" placeholder="e.g. WR 240i, RM-500" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Code</label>
                <input type="text" value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} className="input-field" placeholder="e.g. SS-001" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editItem ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : items.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <Layers size={32} className="text-gray-200" />
          <p className="text-sm">No soil stabilizers added yet.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map(item => (
            <div key={item.id} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between gap-4 hover:border-gray-300 transition-colors">
              <div className="min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">{item.company_name} - {item.model}</p>
                <p className="text-xs text-gray-500">{item.code || 'No code'}</p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button onClick={() => openEdit(item)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><Pencil size={14} /></button>
                <button onClick={() => deleteItem(item.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
