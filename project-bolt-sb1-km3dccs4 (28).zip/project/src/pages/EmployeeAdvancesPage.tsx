import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, type Employee, type EmployeeAdvance } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, IndianRupee, Printer, Smartphone, Filter } from 'lucide-react';

const emptyForm = { employee_id: '', advance_date: new Date().toISOString().split('T')[0], amount: '', notes: '' };

export default function EmployeeAdvancesPage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [records, setRecords] = useState<EmployeeAdvance[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editRecord, setEditRecord] = useState<EmployeeAdvance | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState('');
  const [startDate, setStartDate] = useState(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`; });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [filterEmployee, setFilterEmployee] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.from('employees').select('*').order('name').then(({ data }) => setEmployees(data ?? []));
  }, []);

  useEffect(() => { fetchRecords(); }, [startDate, endDate, filterEmployee]);

  async function fetchRecords() {
    setLoading(true);
    let query = supabase.from('employee_advances').select('*').gte('advance_date', startDate).lte('advance_date', endDate).order('advance_date', { ascending: false });
    if (filterEmployee) query = query.eq('employee_id', filterEmployee);
    const { data } = await query;
    setRecords(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.employee_id || !form.amount) { setError('Employee and amount are required.'); return; }
    setSaving(true);
    const emp = employees.find(e => e.id === form.employee_id);
    const payload = {
      employee_id: form.employee_id,
      employee_name: emp?.name ?? '',
      advance_date: form.advance_date,
      amount: parseFloat(form.amount) || 0,
      notes: form.notes,
    };
    if (editRecord) {
      const { error: err } = await supabase.from('employee_advances').update(payload).eq('id', editRecord.id);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('employee_advances').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditRecord(null);
    setForm(emptyForm);
    fetchRecords();
  }

  function startEdit(rec: EmployeeAdvance) {
    setEditRecord(rec);
    setForm({ employee_id: rec.employee_id, advance_date: rec.advance_date, amount: String(rec.amount), notes: rec.notes });
    setShowForm(true);
    setError('');
  }

  async function deleteRecord(id: string) {
    if (!confirm('Delete this advance record?')) return;
    await supabase.from('employee_advances').delete().eq('id', id);
    fetchRecords();
  }

  const totalAdvance = records.reduce((a, r) => a + Number(r.amount), 0);

  // Per-employee summary
  const employeeSummary = records.reduce<Record<string, { name: string; total: number; count: number }>>((acc, r) => {
    if (!acc[r.employee_id]) acc[r.employee_id] = { name: r.employee_name, total: 0, count: 0 };
    acc[r.employee_id].total += Number(r.amount);
    acc[r.employee_id].count += 1;
    return acc;
  }, {});
  const summaryList = Object.values(employeeSummary).sort((a, b) => b.total - a.total);

  const handlePrint = useCallback(() => {
    const el = printRef.current;
    if (!el) return;
    const isMobile = /Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
    const html = `<html><head><title>Advance Report</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:#fff;padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #000;padding:5px 8px;text-align:left}th{background:#000;color:#fff;font-weight:bold}.text-right{text-align:right}.total-row{background:#f0f0f0;font-weight:bold}@media print{body{margin:0}}}</style></head><body>${el.innerHTML}</body></html>`;
    if (isMobile) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (!doc) { document.body.removeChild(iframe); return; }
      doc.open(); doc.write(html); doc.close();
      iframe.contentWindow?.focus();
      setTimeout(() => { try { iframe.contentWindow?.print(); } catch {} setTimeout(() => document.body.removeChild(iframe), 1000); }, 500);
    } else {
      const win = window.open('', '_blank', 'width=900,height=700');
      if (!win) return;
      win.document.write(html); win.document.close(); win.focus();
      setTimeout(() => { win.print(); win.close(); }, 300);
    }
  }, []);

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' });

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto">
      <PageHeader
        title="Employee Advances"
        subtitle="Track advance payments to employees"
        actions={
          <div className="flex gap-2">
            <button onClick={handlePrint} disabled={records.length === 0} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
              <Printer size={15} className="hidden sm:block" /><Smartphone size={15} className="sm:hidden" /> Print
            </button>
            <button onClick={() => { setShowForm(true); setEditRecord(null); setForm(emptyForm); setError(''); }} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
              <Plus size={16} /> Add Advance
            </button>
          </div>
        }
      />

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
        <div className="rounded-xl border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Total Advances</p>
          <p className="text-xl font-bold text-gray-900">{records.length}</p>
        </div>
        <div className="rounded-xl border border-gray-800 bg-gray-900 p-3">
          <p className="text-xs text-gray-400">Total Amount</p>
          <p className="text-xl font-bold text-white">Rs. {totalAdvance.toFixed(2)}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Employees</p>
          <p className="text-xl font-bold text-gray-900">{summaryList.length}</p>
        </div>
      </div>

      {/* Date Range & Filters */}
      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Start Date</label>
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="input-field" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">End Date</label>
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="input-field" />
        </div>
        <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${showFilters ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'}`}>
          <Filter size={15} /> Filter {filterEmployee && <span className="w-2 h-2 rounded-full bg-red-500" />}
        </button>
      </div>

      {showFilters && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4 animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Filters</h3>
            {filterEmployee && (
              <button onClick={() => setFilterEmployee('')} className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700"><X size={12} /> Clear</button>
            )}
          </div>
          <select value={filterEmployee} onChange={e => setFilterEmployee(e.target.value)} className="select-field max-w-[250px]">
            <option value="">All Employees</option>
            {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
      )}

      {/* Employee-wise Summary */}
      {summaryList.length > 0 && (
        <div className="bg-white border border-gray-200 rounded-xl p-4 mb-5 shadow-sm">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Employee-wise Summary</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {summaryList.map((s, i) => (
              <div key={i} className="flex items-center justify-between bg-gray-50 rounded-lg px-4 py-3">
                <div>
                  <p className="text-sm font-semibold text-gray-900">{s.name}</p>
                  <p className="text-xs text-gray-500">{s.count} advance{ s.count > 1 ? 's' : ''}</p>
                </div>
                <p className="text-sm font-bold text-gray-900">Rs. {s.total.toFixed(2)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editRecord ? 'Edit Advance' : 'Add Advance'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Employee</label>
                <select value={form.employee_id} onChange={e => setForm(f => ({ ...f, employee_id: e.target.value }))} className="select-field">
                  <option value="">-- Select Employee --</option>
                  {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.work_name})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Date</label>
                <input type="date" value={form.advance_date} onChange={e => setForm(f => ({ ...f, advance_date: e.target.value }))} className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Amount (Rs.)</label>
                <input type="number" step="0.01" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} placeholder="0.00" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
                <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2} className="input-field resize-none" placeholder="Optional notes..." />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <IndianRupee size={15} />}
                  {editRecord ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Content */}
      <div ref={printRef}>
        {/* Company Header for print */}
        <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '10px', marginBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '4px' }}>
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjyrGom2IWcy6Ooi6j1VloueaBAKMkGvBpCBkFOnkrfIuwy6i9f0_jf5XN5ImRqFX6cTmYNm_cWiyWu8Z_ELr89fmeEKjz2OG-90NfcgSIiOh2Og1otN2jYbP2RG9GuAMeo2E81BGZm6szbWifu7meKWVEbbIz1cBdukK2MdO9sids34NNoKkcAVyJd6yT8/s320/WhatsApp%20Image%202026-05-03%20at%205.52.01%20PM.jpeg" alt="Logo" style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '6px' }} />
            <div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', letterSpacing: '1px' }}>D ROCK SAND PVT LTD</div>
              <div style={{ fontSize: '11px', marginTop: '2px' }}>Employee Advance Report | Sayla, Gujarat</div>
              <div style={{ fontSize: '10px', color: '#555' }}>GST No: 7EGH5HFN0401Z | CEO: Mr. Vinod Bhai Rathod | CTO: Mr. Deep Bhai Rathod</div>
            </div>
          </div>
          <div style={{ fontSize: '14px', fontWeight: 'bold', marginTop: '6px', letterSpacing: '2px' }}>ADVANCE PAYMENT REPORT</div>
          <div style={{ fontSize: '11px', marginTop: '2px', color: '#333' }}>Period: {formatDate(startDate)} to {formatDate(endDate)}</div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
        ) : records.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
            <IndianRupee size={32} className="text-gray-200" />
            <p className="text-sm">No advance records for this period.</p>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-900 text-white">
                    <th className="px-4 py-3 text-left text-xs font-semibold">#</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold">Employee</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold">Amount (Rs.)</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold hidden sm:table-cell">Notes</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((rec, i) => (
                    <tr key={rec.id} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                      <td className="px-4 py-3 text-xs text-gray-500">{i + 1}</td>
                      <td className="px-4 py-3 text-xs text-gray-700">{formatDate(rec.advance_date)}</td>
                      <td className="px-4 py-3 text-xs font-semibold text-gray-900">{rec.employee_name}</td>
                      <td className="px-4 py-3 text-xs text-right font-bold text-gray-900">Rs. {Number(rec.amount).toFixed(2)}</td>
                      <td className="px-4 py-3 text-xs text-gray-500 hidden sm:table-cell max-w-[200px] truncate">{rec.notes || '-'}</td>
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => startEdit(rec)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"><Pencil size={14} /></button>
                          <button onClick={() => deleteRecord(rec.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-gray-900 text-white">
                    <td className="px-4 py-3 text-xs font-bold" colSpan={3}>TOTAL</td>
                    <td className="px-4 py-3 text-xs text-right font-bold">Rs. {totalAdvance.toFixed(2)}</td>
                    <td className="hidden sm:table-cell" />
                    <td />
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Per-employee summary for print */}
        {summaryList.length > 0 && (
          <div style={{ marginTop: '16px' }}>
            <div style={{ fontSize: '12px', fontWeight: 'bold', marginBottom: '6px', borderBottom: '1px solid #000', paddingBottom: '4px' }}>EMPLOYEE-WISE ADVANCE SUMMARY</div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px' }}>
              <thead>
                <tr><th style={{ border: '1px solid #000', padding: '4px 8px', background: '#000', color: '#fff' }}>Employee</th><th style={{ border: '1px solid #000', padding: '4px 8px', background: '#000', color: '#fff', textAlign: 'center' }}>Count</th><th style={{ border: '1px solid #000', padding: '4px 8px', background: '#000', color: '#fff', textAlign: 'right' }}>Total Amount</th></tr>
              </thead>
              <tbody>
                {summaryList.map((s, i) => (
                  <tr key={i} style={{ background: i % 2 === 0 ? '#fff' : '#f9f9f9' }}>
                    <td style={{ border: '1px solid #000', padding: '4px 8px' }}>{s.name}</td>
                    <td style={{ border: '1px solid #000', padding: '4px 8px', textAlign: 'center' }}>{s.count}</td>
                    <td style={{ border: '1px solid #000', padding: '4px 8px', textAlign: 'right', fontWeight: 'bold' }}>Rs. {s.total.toFixed(2)}</td>
                  </tr>
                ))}
                <tr style={{ background: '#f0f0f0' }}>
                  <td style={{ border: '1px solid #000', padding: '4px 8px', fontWeight: 'bold' }}>TOTAL</td>
                  <td style={{ border: '1px solid #000', padding: '4px 8px', textAlign: 'center', fontWeight: 'bold' }}>{records.length}</td>
                  <td style={{ border: '1px solid #000', padding: '4px 8px', textAlign: 'right', fontWeight: 'bold' }}>Rs. {totalAdvance.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {/* Print Footer */}
        <div style={{ borderTop: '1px solid #000', marginTop: '16px', paddingTop: '8px', textAlign: 'center', fontSize: '10px', color: '#666' }}>
          D Rock Sand Pvt Ltd | Sayla, Gujarat | GST: 7EGH5HFN0401Z | This is a computer generated report
        </div>
      </div>
    </div>
  );
}
