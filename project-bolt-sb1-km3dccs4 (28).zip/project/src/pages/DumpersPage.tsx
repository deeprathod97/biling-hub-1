import { useState, useEffect } from 'react';
import { supabase, type Dumper, type Site } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Plus, Trash2, Pencil, X, Check, Loader2, Truck } from 'lucide-react';

export default function DumpersPage() {
  const [items, setItems] = useState<Dumper[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<Dumper | null>(null);
  const [form, setForm] = useState({ company_name: '', model: '', wheel: '', code: '', site_id: '', site_name: '', party_name: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    supabase.from('sites').select('*').order('site_name').then(({ data }) => setSites(data ?? []));
    fetchItems();
  }, []);

  async function fetchItems() {
    setLoading(true);
    const { data } = await supabase.from('dumpers').select('*').order('created_at', { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.company_name || !form.model) { setError('Company and Model are required.'); return; }
    setSaving(true);
    const site = sites.find(s => s.id === form.site_id);
    const payload = { ...form, site_name: site?.site_name ?? '' };
    if (editItem) {
      const { error: err } = await supabase.from('dumpers').update(payload).eq('id', editItem.id);
      if (err) { setError(err.message); setSaving(false); return; }
    } else {
      const { error: err } = await supabase.from('dumpers').insert(payload);
      if (err) { setError(err.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    setEditItem(null);
    setForm({ company_name: '', model: '', wheel: '', code: '', site_id: '', site_name: '', party_name: '' });
    fetchItems();
  }

  function startEdit(item: Dumper) {
    setEditItem(item);
    setForm({ company_name: item.company_name, model: item.model, wheel: item.wheel, code: item.code, site_id: item.site_id ?? '', site_name: item.site_name, party_name: item.party_name });
    setShowForm(true);
    setError('');
  }

  async function deleteItem(id: string) {
    if (!confirm('Delete this dumper?')) return;
    await supabase.from('dumper_rates').delete().eq('dumper_id', id);
    await supabase.from('dumpers').delete().eq('id', id);
    fetchItems();
  }

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <PageHeader
        title="Dumpers"
        subtitle="Manage dumper vehicles and equipment"
        actions={
          <button onClick={() => { setShowForm(true); setEditItem(null); setForm({ company_name: '', model: '', wheel: '', code: '', site_id: '', site_name: '', party_name: '' }); setError(''); }} className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700">
            <Plus size={16} /> Add Dumper
          </button>
        }
      />

      <div className="rounded-xl border border-gray-200 bg-white p-3 mb-5 inline-block">
        <p className="text-xs text-gray-500">Total Dumpers</p>
        <p className="text-xl font-bold text-gray-900">{items.length}</p>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-modal-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-900">{editItem ? 'Edit' : 'Add'} Dumper</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-700"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Company Name</label>
                <input type="text" value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))} className="input-field" placeholder="e.g. Tata, BharatBenz, Ashok Leyland" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Model</label>
                <input type="text" value={form.model} onChange={e => setForm(f => ({ ...f, model: e.target.value }))} className="input-field" placeholder="e.g. 2528K, 3128K" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Wheel</label>
                <input type="text" value={form.wheel} onChange={e => setForm(f => ({ ...f, wheel: e.target.value }))} className="input-field" placeholder="e.g. 6x4, 8x4, 10x4" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Code</label>
                <input type="text" value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} className="input-field" placeholder="e.g. DMP-001" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Site</label>
                <select value={form.site_id} onChange={e => setForm(f => ({ ...f, site_id: e.target.value }))} className="select-field">
                  <option value="">-- Select Site --</option>
                  {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Party Name</label>
                <input type="text" value={form.party_name} onChange={e => setForm(f => ({ ...f, party_name: e.target.value }))} className="input-field" placeholder="e.g. ABC Transport" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 flex items-center justify-center gap-2">
                  {saving ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                  {editItem ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 size={28} className="animate-spin text-gray-400" /></div>
      ) : items.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-gray-400 gap-3">
          <Truck size={32} className="text-gray-200" />
          <p className="text-sm">No dumpers added yet.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map(item => (
            <div key={item.id} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between gap-4 hover:border-gray-300 transition-colors">
              <div className="min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">{item.company_name} - {item.model}</p>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  {item.wheel && <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700">{item.wheel}</span>}
                  {item.code && <span className="text-xs text-gray-500">{item.code}</span>}
                  {item.site_name && <span className="text-xs text-blue-600">{item.site_name}</span>}
                  {item.party_name && <span className="text-xs text-green-600">{item.party_name}</span>}
                </div>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button onClick={() => startEdit(item)} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><Pencil size={14} /></button>
                <button onClick={() => deleteItem(item.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
