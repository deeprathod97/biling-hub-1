-- Create raw_materials table
CREATE TABLE IF NOT EXISTS raw_materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL UNIQUE DEFAULT '00000',
  party_name TEXT NOT NULL,
  mobile_number TEXT,
  address TEXT,
  material_name TEXT NOT NULL,
  quantity DECIMAL(10, 3) NOT NULL DEFAULT 0,
  quantity_type TEXT NOT NULL DEFAULT 'kg' CHECK (quantity_type IN ('bag', 'kg', 'ton', 'quintal')),
  total_amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE raw_materials ENABLE ROW LEVEL SECURITY;

-- Create policies for public access
CREATE POLICY "select_raw_materials" ON raw_materials FOR SELECT USING (true);
CREATE POLICY "insert_raw_materials" ON raw_materials FOR INSERT WITH CHECK (true);
CREATE POLICY "update_raw_materials" ON raw_materials FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_raw_materials" ON raw_materials FOR DELETE USING (true);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_raw_materials_bill_number ON raw_materials(bill_number);
CREATE INDEX IF NOT EXISTS idx_raw_materials_created_at ON raw_materials(created_at DESC);