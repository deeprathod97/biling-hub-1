-- Drop existing policies that require authentication
DROP POLICY IF EXISTS select_parties ON parties;
DROP POLICY IF EXISTS insert_parties ON parties;
DROP POLICY IF EXISTS update_parties ON parties;
DROP POLICY IF EXISTS delete_parties ON parties;

DROP POLICY IF EXISTS select_packings ON packings;
DROP POLICY IF EXISTS insert_packings ON packings;
DROP POLICY IF EXISTS update_packings ON packings;
DROP POLICY IF EXISTS delete_packings ON packings;

DROP POLICY IF EXISTS select_bills ON bills;
DROP POLICY IF EXISTS insert_bills ON bills;
DROP POLICY IF EXISTS update_bills ON bills;
DROP POLICY IF EXISTS delete_bills ON bills;

DROP POLICY IF EXISTS select_bill_items ON bill_items;
DROP POLICY IF EXISTS insert_bill_items ON bill_items;
DROP POLICY IF EXISTS update_bill_items ON bill_items;
DROP POLICY IF EXISTS delete_bill_items ON bill_items;

DROP POLICY IF EXISTS select_payments ON payments;
DROP POLICY IF EXISTS insert_payments ON payments;
DROP POLICY IF EXISTS update_payments ON payments;
DROP POLICY IF EXISTS delete_payments ON payments;

-- Create new policies allowing all access (for development without auth)
CREATE POLICY "select_parties" ON parties FOR SELECT USING (true);
CREATE POLICY "insert_parties" ON parties FOR INSERT WITH CHECK (true);
CREATE POLICY "update_parties" ON parties FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_parties" ON parties FOR DELETE USING (true);

CREATE POLICY "select_packings" ON packings FOR SELECT USING (true);
CREATE POLICY "insert_packings" ON packings FOR INSERT WITH CHECK (true);
CREATE POLICY "update_packings" ON packings FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_packings" ON packings FOR DELETE USING (true);

CREATE POLICY "select_bills" ON bills FOR SELECT USING (true);
CREATE POLICY "insert_bills" ON bills FOR INSERT WITH CHECK (true);
CREATE POLICY "update_bills" ON bills FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_bills" ON bills FOR DELETE USING (true);

CREATE POLICY "select_bill_items" ON bill_items FOR SELECT USING (true);
CREATE POLICY "insert_bill_items" ON bill_items FOR INSERT WITH CHECK (true);
CREATE POLICY "update_bill_items" ON bill_items FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_bill_items" ON bill_items FOR DELETE USING (true);

CREATE POLICY "select_payments" ON payments FOR SELECT USING (true);
CREATE POLICY "insert_payments" ON payments FOR INSERT WITH CHECK (true);
CREATE POLICY "update_payments" ON payments FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_payments" ON payments FOR DELETE USING (true);