-- Dealers table
CREATE TABLE dealers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  mobile_number TEXT NOT NULL,
  address TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE dealers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_dealers" ON dealers FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_dealers" ON dealers FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_dealers" ON dealers FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_dealers" ON dealers FOR DELETE TO authenticated USING (true);

-- Dealer Packings table (packing specific to dealers)
CREATE TABLE dealer_packings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_id UUID REFERENCES dealers(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  kg DECIMAL NOT NULL,
  bhav_per_kg DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE dealer_packings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_dealer_packings" ON dealer_packings FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_dealer_packings" ON dealer_packings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_dealer_packings" ON dealer_packings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_dealer_packings" ON dealer_packings FOR DELETE TO authenticated USING (true);

-- Selling Bills table
CREATE TABLE selling_bills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL UNIQUE,
  dealer_id UUID REFERENCES dealers(id) ON DELETE SET NULL,
  total_amount DECIMAL NOT NULL DEFAULT 0,
  paid_amount DECIMAL NOT NULL DEFAULT 0,
  pending_amount DECIMAL NOT NULL DEFAULT 0,
  delivery_charge DECIMAL NOT NULL DEFAULT 0,
  notes TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE selling_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_selling_bills" ON selling_bills FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_selling_bills" ON selling_bills FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_selling_bills" ON selling_bills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_selling_bills" ON selling_bills FOR DELETE TO authenticated USING (true);

-- Selling Bill Items table
CREATE TABLE selling_bill_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES selling_bills(id) ON DELETE CASCADE,
  packing_id UUID REFERENCES dealer_packings(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  kg DECIMAL NOT NULL,
  bhav_per_kg DECIMAL NOT NULL,
  amount DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE selling_bill_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_selling_bill_items" ON selling_bill_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_selling_bill_items" ON selling_bill_items FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_selling_bill_items" ON selling_bill_items FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_selling_bill_items" ON selling_bill_items FOR DELETE TO authenticated USING (true);

-- Selling Payments table
CREATE TABLE selling_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES selling_bills(id) ON DELETE SET NULL,
  amount DECIMAL NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE selling_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_selling_payments" ON selling_payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_selling_payments" ON selling_payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_selling_payments" ON selling_payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_selling_payments" ON selling_payments FOR DELETE TO authenticated USING (true);

-- Indexes
CREATE INDEX idx_dealer_packings_dealer_id ON dealer_packings(dealer_id);
CREATE INDEX idx_selling_bills_dealer_id ON selling_bills(dealer_id);
CREATE INDEX idx_selling_bill_items_bill_id ON selling_bill_items(bill_id);
CREATE INDEX idx_selling_payments_bill_id ON selling_payments(bill_id);