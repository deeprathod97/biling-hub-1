-- Drop authenticated-only policies on dealer tables
DROP POLICY IF EXISTS select_dealers ON dealers;
DROP POLICY IF EXISTS insert_dealers ON dealers;
DROP POLICY IF EXISTS update_dealers ON dealers;
DROP POLICY IF EXISTS delete_dealers ON dealers;

DROP POLICY IF EXISTS select_dealer_packings ON dealer_packings;
DROP POLICY IF EXISTS insert_dealer_packings ON dealer_packings;
DROP POLICY IF EXISTS update_dealer_packings ON dealer_packings;
DROP POLICY IF EXISTS delete_dealer_packings ON dealer_packings;

DROP POLICY IF EXISTS select_selling_bills ON selling_bills;
DROP POLICY IF EXISTS insert_selling_bills ON selling_bills;
DROP POLICY IF EXISTS update_selling_bills ON selling_bills;
DROP POLICY IF EXISTS delete_selling_bills ON selling_bills;

DROP POLICY IF EXISTS select_selling_bill_items ON selling_bill_items;
DROP POLICY IF EXISTS insert_selling_bill_items ON selling_bill_items;
DROP POLICY IF EXISTS update_selling_bill_items ON selling_bill_items;
DROP POLICY IF EXISTS delete_selling_bill_items ON selling_bill_items;

DROP POLICY IF EXISTS select_selling_payments ON selling_payments;
DROP POLICY IF EXISTS insert_selling_payments ON selling_payments;
DROP POLICY IF EXISTS update_selling_payments ON selling_payments;
DROP POLICY IF EXISTS delete_selling_payments ON selling_payments;

-- Recreate policies without authenticated requirement (matching existing tables pattern)
CREATE POLICY "select_dealers" ON dealers FOR SELECT USING (true);
CREATE POLICY "insert_dealers" ON dealers FOR INSERT WITH CHECK (true);
CREATE POLICY "update_dealers" ON dealers FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_dealers" ON dealers FOR DELETE USING (true);

CREATE POLICY "select_dealer_packings" ON dealer_packings FOR SELECT USING (true);
CREATE POLICY "insert_dealer_packings" ON dealer_packings FOR INSERT WITH CHECK (true);
CREATE POLICY "update_dealer_packings" ON dealer_packings FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_dealer_packings" ON dealer_packings FOR DELETE USING (true);

CREATE POLICY "select_selling_bills" ON selling_bills FOR SELECT USING (true);
CREATE POLICY "insert_selling_bills" ON selling_bills FOR INSERT WITH CHECK (true);
CREATE POLICY "update_selling_bills" ON selling_bills FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_selling_bills" ON selling_bills FOR DELETE USING (true);

CREATE POLICY "select_selling_bill_items" ON selling_bill_items FOR SELECT USING (true);
CREATE POLICY "insert_selling_bill_items" ON selling_bill_items FOR INSERT WITH CHECK (true);
CREATE POLICY "update_selling_bill_items" ON selling_bill_items FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_selling_bill_items" ON selling_bill_items FOR DELETE USING (true);

CREATE POLICY "select_selling_payments" ON selling_payments FOR SELECT USING (true);
CREATE POLICY "insert_selling_payments" ON selling_payments FOR INSERT WITH CHECK (true);
CREATE POLICY "update_selling_payments" ON selling_payments FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_selling_payments" ON selling_payments FOR DELETE USING (true);