import { useState, useEffect, useRef } from 'react'
import { supabase, type Party, type Packing, type Bill, type BillItem, type Payment, type RawMaterial, type Dealer, type DealerPacking, type SellingBill, type SellingBillItem, type SellingPayment } from './lib/supabase'
import {
  Home, Users, Package, Receipt, Calculator, Printer, Download, Trash2,
  Edit, Plus, DollarSign, TrendingUp, Clock, CheckCircle, X,
  Building2, Phone, MapPin, Hash, IndianRupee, Menu, ChevronDown,
  FileText, BarChart3, PieChart as PieChartIcon, Layers, Smartphone,
  Truck, Store, ShoppingCart
} from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend, AreaChart, Area
} from 'recharts'
import { useRegisterSW } from 'virtual:pwa-register/react'

const COMPANY_LOGO = "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgIpGW0MHn912LhkgNpgMXWB-U5iDwGIpNnMp_vYePgtB34nIFPQBtkfDG8-EzpMCTQp5MBZpF9it_db2JrlsVHV_zGesW1I_D9OWh1mHY6gItSlXldQBv1MrD4ioZS8_w3UFFbPcmlJeTC0ejy0_utjXqeagW-pXi25NBKTR6f75__r4QXN4QPZT6sIb9H/s320/ChatGPT%20Image%20May%2028,%202026,%2010_08_04%20PM.png"

const COMPANY_INFO = {
  name: "Jay Khodiyar Cattle Feed",
  address: "Sudamda, Sayla, Paliyad Road",
  mobile: "9737468847",
  gst: "248CLL3OZ5TL1Z",
  owners: [
    { name: "Deep Bhai Rathod", mobile: "9737468847" },
    { name: "Vinod Bhai Rathod", mobile: "6354152897" }
  ],
  otherBusinesses: [
    { name: "Jay Khodiyar Stone Industries", location: "Sudamda" },
    { name: "D ROCK SAND PVT LTD", location: "Mota Keral Sayla" },
    { name: "D ROCK CONGRATULATIONS PVT LTD", location: "Sayla" },
    { name: "D CONCRETE PVT LTD", location: "Dholera" },
    { name: "Raj Khodiyar Aggregate LLP", location: "Sayla" },
    { name: "Deep Coronation", location: "Damngar" },
    { name: "Jay Shree Khodiyar Quarry", location: "Methali" },
    { name: "Ramdev Stone Crusher", location: "Juna Jasapar" },
    { name: "D ROCK SAND", location: "Vadagam" },
    { name: "D Minerals Co", location: "Savaliya" }
  ]
}

const COLORS = ['#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#8b5cf6', '#ec4899']

type View = 'dashboard' | 'parties' | 'packings' | 'new-bill' | 'bills' | 'payments' | 'raw-materials' | 'raw-material-entry' | 'dealers' | 'dealer-packings' | 'selling-dashboard' | 'new-selling-bill' | 'selling-bills' | 'selling-payments'

function App() {
  const [view, setView] = useState<View>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showInstallPrompt, setShowInstallPrompt] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  const {
    needRefresh: [needRefresh],
    updateServiceWorker,
  } = useRegisterSW({
    onRegistered(r) {
      console.log('SW Registered:', r)
    },
    onRegisterError(error) {
      console.log('SW registration error:', error)
    },
  })

  useEffect(() => {
    // Check if app is already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true)
    }

    // Listen for beforeinstallprompt event
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setShowInstallPrompt(true)
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)

    // Listen for app installed event
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true)
      setShowInstallPrompt(false)
      setDeferredPrompt(null)
    })

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstallClick = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === 'accepted') {
      setIsInstalled(true)
    }

    setDeferredPrompt(null)
    setShowInstallPrompt(false)
  }

  const menuItems = [
    { id: 'dashboard' as View, label: 'Dashboard', icon: Home },
    { id: 'parties' as View, label: 'Parties', icon: Users },
    { id: 'packings' as View, label: 'Products/Packing', icon: Package },
    { id: 'raw-material-entry' as View, label: 'Raw Material Entry', icon: FileText },
    { id: 'raw-materials' as View, label: 'Raw Materials', icon: Layers },
    { id: 'new-bill' as View, label: 'New Bill', icon: Plus },
    { id: 'bills' as View, label: 'Bills', icon: Receipt },
    { id: 'payments' as View, label: 'Payments', icon: IndianRupee },
    { id: 'selling-dashboard' as View, label: 'Selling Dashboard', icon: BarChart3 },
    { id: 'dealers' as View, label: 'Dealers', icon: Store },
    { id: 'dealer-packings' as View, label: 'Dealer Packings', icon: Package },
    { id: 'new-selling-bill' as View, label: 'New Selling Bill', icon: ShoppingCart },
    { id: 'selling-bills' as View, label: 'Selling Bills', icon: Receipt },
    { id: 'selling-payments' as View, label: 'Selling Payments', icon: IndianRupee },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex">
      {/* PWA Install Prompt */}
      {showInstallPrompt && !isInstalled && (
        <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg animate-slide-down">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={COMPANY_LOGO} alt="App Icon" className="w-10 h-10 rounded-lg shadow-md" />
              <div>
                <p className="font-semibold text-sm">Install Jay Khodiyar App</p>
                <p className="text-xs text-amber-100">Add to home screen for quick access</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleInstallClick}
                className="flex items-center gap-2 px-4 py-2 bg-white text-amber-600 font-semibold rounded-lg hover:bg-amber-50 transition-colors shadow-md"
              >
                <Smartphone size={18} /> Install
              </button>
              <button
                onClick={() => setShowInstallPrompt(false)}
                className="p-2 hover:bg-amber-600/50 rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Update Available Banner */}
      {needRefresh && (
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-800 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm">New version available!</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateServiceWorker(true)}
                className="px-4 py-2 bg-amber-500 text-white font-semibold rounded-lg hover:bg-amber-600 transition-colors text-sm"
              >
                Update Now
              </button>
              <button
                onClick={() => updateServiceWorker(false)}
                className="px-3 py-2 text-slate-300 hover:text-white transition-colors text-sm"
              >
                Later
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-gradient-to-b from-slate-800 to-slate-900 text-white transition-all duration-300 flex flex-col`}>
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <img src={COMPANY_LOGO} alt="Logo" className="w-10 h-10 rounded-full object-cover" />
            {sidebarOpen && <span className="font-bold text-sm leading-tight">Jay Khodiyar<br/>Cattle Feed</span>}
          </div>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                view === item.id
                  ? 'bg-amber-500 text-slate-900 font-semibold'
                  : 'hover:bg-slate-700 text-slate-300'
              }`}
            >
              <item.icon size={20} />
              {sidebarOpen && <span className="text-sm">{item.label}</span>}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-slate-700">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center justify-center gap-2 py-2 text-slate-400 hover:text-white transition-colors"
          >
            <Menu size={18} />
            {sidebarOpen && <span className="text-sm"> Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <header className="bg-white shadow-sm border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-800">
              {menuItems.find(m => m.id === view)?.label || 'Dashboard'}
            </h1>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="font-semibold text-slate-800">{COMPANY_INFO.name}</p>
                <p className="text-sm text-slate-500">{COMPANY_INFO.mobile}</p>
              </div>
              <img src={COMPANY_LOGO} alt="Company" className="w-12 h-12 rounded-full object-cover" />
            </div>
          </div>
        </header>

        <div className="p-6">
          {view === 'dashboard' && <Dashboard setView={setView} />}
          {view === 'parties' && <PartiesView />}
          {view === 'packings' && <PackingsView />}
          {view === 'new-bill' && <NewBillView setView={setView} />}
          {view === 'bills' && <BillsView />}
          {view === 'payments' && <PaymentsView />}
          {view === 'raw-material-entry' && <RawMaterialEntry setView={setView} />}
          {view === 'raw-materials' && <RawMaterialsView />}
          {view === 'dealers' && <DealersView />}
          {view === 'dealer-packings' && <DealerPackingsView />}
          {view === 'selling-dashboard' && <SellingDashboard setView={setView} />}
          {view === 'new-selling-bill' && <NewSellingBillView setView={setView} />}
          {view === 'selling-bills' && <SellingBillsView />}
          {view === 'selling-payments' && <SellingPaymentsView />}
        </div>
      </main>
    </div>
  )
}

// Dashboard Component
function Dashboard({ setView }: { setView: (v: View) => void }) {
  const [stats, setStats] = useState({
    totalBills: 0,
    totalAmount: 0,
    totalPaid: 0,
    totalPending: 0,
    totalParties: 0,
    totalProducts: 0,
    totalRawMaterials: 0,
    rawMaterialAmount: 0
  })
  const [recentBills, setRecentBills] = useState<(Bill & { party: Party })[]>([])
  const [monthlyData, setMonthlyData] = useState<{ month: string; sales: number }[]>([])
  const [partyData, setPartyData] = useState<{ name: string; value: number }[]>([])
  const [paymentTrend, setPaymentTrend] = useState<{ date: string; payments: number }[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardData()
  }, [])

  async function loadDashboardData() {
    try {
      const [billsRes, partiesRes, packingsRes, rawMaterialsRes, paymentsRes] = await Promise.all([
        supabase.from('bills').select('*, party:parties(*)').order('created_at', { ascending: false }).limit(10),
        supabase.from('parties').select('id', { count: 'exact' }),
        supabase.from('packings').select('id', { count: 'exact' }),
        supabase.from('raw_materials').select('id, total_amount', { count: 'exact' }),
        supabase.from('payments').select('amount, payment_date').order('payment_date', { ascending: false }).limit(30)
      ])

      const bills = billsRes.data || []
      const totalAmount = bills.reduce((sum, b) => sum + (b.total_amount || 0), 0)
      const totalPaid = bills.reduce((sum, b) => sum + (b.paid_amount || 0), 0)
      const rawMaterialTotal = (rawMaterialsRes.data || []).reduce((sum, r) => sum + (r.total_amount || 0), 0)

      setStats({
        totalBills: bills.length,
        totalAmount,
        totalPaid,
        totalPending: totalAmount - totalPaid,
        totalParties: partiesRes.count || 0,
        totalProducts: packingsRes.count || 0,
        totalRawMaterials: rawMaterialsRes.count || 0,
        rawMaterialAmount: rawMaterialTotal
      })
      setRecentBills(bills as (Bill & { party: Party })[])

      // Monthly sales data
      const monthMap = new Map<string, number>()
      bills.forEach(bill => {
        const month = new Date(bill.created_at).toLocaleString('en', { month: 'short', year: '2-digit' })
        monthMap.set(month, (monthMap.get(month) || 0) + (bill.total_amount || 0))
      })
      setMonthlyData(Array.from(monthMap.entries()).slice(-6).map(([month, sales]) => ({ month, sales })))

      // Party-wise sales
      const partyMap = new Map<string, number>()
      bills.forEach(bill => {
        const name = bill.party?.name || 'Unknown'
        partyMap.set(name, (partyMap.get(name) || 0) + (bill.total_amount || 0))
      })
      setPartyData(Array.from(partyMap.entries()).slice(0, 5).map(([name, value]) => ({ name, value })))

      // Payment trend
      const paymentMap = new Map<string, number>()
      ;(paymentsRes.data || []).forEach(p => {
        const date = new Date(p.payment_date).toLocaleDateString('en', { day: '2-digit', month: 'short' })
        paymentMap.set(date, (paymentMap.get(date) || 0) + (p.amount || 0))
      })
      setPaymentTrend(Array.from(paymentMap.entries()).slice(-7).map(([date, payments]) => ({ date, payments })))

    } catch (error) {
      console.error('Error loading dashboard:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Bills" value={stats.totalBills} icon={Receipt} color="bg-blue-500" onClick={() => setView('bills')} />
        <StatCard title="Total Amount" value={`Rs. ${stats.totalAmount.toLocaleString()}`} icon={IndianRupee} color="bg-green-500" />
        <StatCard title="Paid Amount" value={`Rs. ${stats.totalPaid.toLocaleString()}`} icon={CheckCircle} color="bg-emerald-500" onClick={() => setView('payments')} />
        <StatCard title="Pending Amount" value={`Rs. ${stats.totalPending.toLocaleString()}`} icon={Clock} color="bg-amber-500" />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Parties" value={stats.totalParties} icon={Users} color="bg-indigo-500" onClick={() => setView('parties')} />
        <StatCard title="Total Products" value={stats.totalProducts} icon={Package} color="bg-rose-500" onClick={() => setView('packings')} />
        <StatCard title="Raw Materials" value={stats.totalRawMaterials} icon={Layers} color="bg-cyan-500" onClick={() => setView('raw-materials')} />
        <StatCard title="Material Amount" value={`Rs. ${stats.rawMaterialAmount.toLocaleString()}`} icon={TrendingUp} color="bg-purple-500" />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-800 mb-4">Quick Actions</h2>
        <div className="flex flex-wrap gap-3">
          <button onClick={() => setView('new-bill')} className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors">
            <Plus size={18} /> New Bill
          </button>
          <button onClick={() => setView('raw-material-entry')} className="flex items-center gap-2 px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors">
            <FileText size={18} /> Raw Material Entry
          </button>
          <button onClick={() => setView('parties')} className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
            <Users size={18} /> Add Party
          </button>
          <button onClick={() => setView('packings')} className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
            <Package size={18} /> Add Product
          </button>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Sales Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="text-slate-600" size={20} />
            <h3 className="text-lg font-semibold text-slate-800">Monthly Sales</h3>
          </div>
          {monthlyData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(v) => `Rs.${v/1000}k`} />
                <Tooltip formatter={(value: number) => [`Rs. ${value.toLocaleString()}`, 'Sales']} />
                <Bar dataKey="sales" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-slate-400">No sales data yet</div>
          )}
        </div>

        {/* Party-wise Sales Pie Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <PieChartIcon className="text-slate-600" size={20} />
            <h3 className="text-lg font-semibold text-slate-800">Sales by Party</h3>
          </div>
          {partyData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={partyData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name }) => name}>
                  {partyData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `Rs. ${value.toLocaleString()}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-slate-400">No party data yet</div>
          )}
        </div>
      </div>

      {/* Payment Trend */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="text-slate-600" size={20} />
          <h3 className="text-lg font-semibold text-slate-800">Payment Trend (Last 7 Days)</h3>
        </div>
        {paymentTrend.length > 0 ? (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={paymentTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="date" tick={{ fill: '#64748b', fontSize: 12 }} />
              <YAxis tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(v) => `Rs.${v/1000}k`} />
              <Tooltip formatter={(value: number) => [`Rs. ${value.toLocaleString()}`, 'Payments']} />
              <Line type="monotone" dataKey="payments" stroke="#10b981" strokeWidth={2} dot={{ fill: '#10b981' }} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[200px] flex items-center justify-center text-slate-400">No payment data yet</div>
        )}
      </div>

      {/* Recent Bills */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-800">Recent Bills</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Party</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Amount</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentBills.slice(0, 5).map((bill) => (
                <tr key={bill.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => setView('bills')}>
                  <td className="px-4 py-3 font-medium text-slate-800">{bill.bill_number}</td>
                  <td className="px-4 py-3 text-slate-600">{bill.party?.name || 'N/A'}</td>
                  <td className="px-4 py-3 text-slate-800">Rs. {bill.total_amount?.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      bill.status === 'paid' ? 'bg-green-100 text-green-700' :
                      bill.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {bill.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-sm">{new Date(bill.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Company Profile */}
      <CompanyProfile />
    </div>
  )
}

function StatCard({ title, value, icon: Icon, color, onClick }: { title: string; value: string | number; icon: React.ElementType; color: string; onClick?: () => void }) {
  return (
    <div
      className={`bg-white rounded-xl shadow-sm border border-slate-200 p-6 ${onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''}`}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-500">{title}</p>
          <p className="text-2xl font-bold text-slate-800 mt-1">{value}</p>
        </div>
        <div className={`${color} p-3 rounded-lg text-white`}>
          <Icon size={24} />
        </div>
      </div>
    </div>
  )
}

function CompanyProfile() {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-6 flex items-center justify-between hover:bg-slate-50 transition-colors"
      >
        <div className="flex items-center gap-4">
          <div className="relative">
            <img src={COMPANY_LOGO} alt="Company Logo" className="w-20 h-20 rounded-xl object-cover shadow-lg ring-2 ring-amber-500/20" />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-amber-500 rounded-full flex items-center justify-center shadow">
              <Building2 size={14} className="text-white" />
            </div>
          </div>
          <div className="text-left">
            <h2 className="text-xl font-bold text-slate-800">{COMPANY_INFO.name}</h2>
            <p className="text-slate-500 flex items-center gap-1 text-sm">
              <MapPin size={14} className="text-amber-500" />
              {COMPANY_INFO.address}
            </p>
          </div>
        </div>
        <ChevronDown className={`text-slate-400 transition-transform ${expanded ? 'rotate-180' : ''}`} size={24} />
      </button>

      {expanded && (
        <div className="px-6 pb-6 space-y-6">
          {/* Contact Information */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center gap-2 text-blue-600 mb-2">
                <Phone size={18} /> <span className="font-semibold">Contact</span>
              </div>
              <p className="text-slate-800 font-medium text-lg">{COMPANY_INFO.mobile}</p>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-green-100/50 rounded-lg p-4 border border-green-200">
              <div className="flex items-center gap-2 text-green-600 mb-2">
                <Hash size={18} /> <span className="font-semibold">GST Number</span>
              </div>
              <p className="text-slate-800 font-mono">{COMPANY_INFO.gst}</p>
            </div>
            <div className="bg-gradient-to-br from-amber-50 to-amber-100/50 rounded-lg p-4 border border-amber-200">
              <div className="flex items-center gap-2 text-amber-600 mb-2">
                <MapPin size={18} /> <span className="font-semibold">Location</span>
              </div>
              <p className="text-slate-800 text-sm">{COMPANY_INFO.address}</p>
            </div>
          </div>

          {/* Owners */}
          <div className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg p-5 border border-slate-200">
            <div className="flex items-center gap-2 text-slate-700 mb-4">
              <Users size={20} className="text-amber-500" /> <span className="font-bold text-lg">Business Owners</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {COMPANY_INFO.owners.map((owner, i) => (
                <div key={i} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {i + 1}
                    </div>
                    <div>
                      <p className="font-bold text-slate-800">{owner.name}</p>
                      <p className="text-slate-500 text-sm flex items-center gap-1">
                        <Phone size={12} /> {owner.mobile}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Other Businesses */}
          <div className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg p-5 border border-slate-200">
            <div className="flex items-center gap-2 text-slate-700 mb-4">
              <Building2 size={20} className="text-amber-500" /> <span className="font-bold text-lg">Other Business Ventures ({COMPANY_INFO.otherBusinesses.length})</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {COMPANY_INFO.otherBusinesses.map((biz, i) => (
                <div key={i} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-amber-300 transition-all group">
                  <div className="flex items-start gap-2">
                    <div className="w-8 h-8 bg-gradient-to-br from-slate-600 to-slate-700 rounded-lg flex items-center justify-center text-white font-bold text-xs shrink-0">
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-slate-800 text-sm leading-tight group-hover:text-amber-600 transition-colors">{biz.name}</p>
                      <p className="text-slate-500 text-xs flex items-center gap-1 mt-1">
                        <MapPin size={10} /> {biz.location}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Parties View
function PartiesView() {
  const [parties, setParties] = useState<Party[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editParty, setEditParty] = useState<Party | null>(null)
  const [formData, setFormData] = useState({ name: '', mobile_number: '', address: '' })

  useEffect(() => {
    loadParties()
  }, [])

  async function loadParties() {
    try {
      const { data } = await supabase.from('parties').select('*').order('name')
      setParties(data || [])
    } catch (error) {
      console.error('Error loading parties:', error)
    } finally {
      setLoading(false)
    }
  }

  function resetForm() {
    setFormData({ name: '', mobile_number: '', address: '' })
    setEditParty(null)
    setShowForm(false)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      if (editParty) {
        await supabase.from('parties').update({
          ...formData,
          updated_at: new Date().toISOString()
        }).eq('id', editParty.id)
      } else {
        await supabase.from('parties').insert(formData)
      }
      resetForm()
      loadParties()
    } catch (error) {
      console.error('Error saving party:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this party?')) return
    try {
      await supabase.from('parties').delete().eq('id', id)
      loadParties()
    } catch (error) {
      console.error('Error deleting party:', error)
    }
  }

  function startEdit(party: Party) {
    setEditParty(party)
    setFormData({
      name: party.name,
      mobile_number: party.mobile_number,
      address: party.address
    })
    setShowForm(true)
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div></div>
        <button
          onClick={() => { resetForm(); setShowForm(true) }}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
        >
          <Plus size={18} /> Add Party
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-800">
              {editParty ? 'Edit Party' : 'Add New Party'}
            </h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600">
              <X size={20} />
            </button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input
                type="text"
                placeholder="Party Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                required
              />
              <input
                type="tel"
                placeholder="Mobile Number"
                value={formData.mobile_number}
                onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                required
              />
              <input
                type="text"
                placeholder="Address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={resetForm} className="px-4 py-2 text-slate-600 hover:text-slate-800">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600">
                {editParty ? 'Update' : 'Submit'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Name</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Mobile</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Address</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {parties.map((party) => (
              <tr key={party.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{party.name}</td>
                <td className="px-4 py-3 text-slate-600">{party.mobile_number}</td>
                <td className="px-4 py-3 text-slate-600">{party.address}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-2">
                    <button onClick={() => startEdit(party)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                      <Edit size={16} />
                    </button>
                    <button onClick={() => handleDelete(party.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {parties.length === 0 && (
          <div className="p-8 text-center text-slate-500">No parties found. Add your first party!</div>
        )}
      </div>
    </div>
  )
}

// Packings View
function PackingsView() {
  const [packings, setPackings] = useState<Packing[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editPacking, setEditPacking] = useState<Packing | null>(null)
  const [formData, setFormData] = useState({ name: '', kg: '', rate_per_kg: '' })

  useEffect(() => {
    loadPackings()
  }, [])

  async function loadPackings() {
    try {
      const { data } = await supabase.from('packings').select('*').order('name')
      setPackings(data || [])
    } catch (error) {
      console.error('Error loading packings:', error)
    } finally {
      setLoading(false)
    }
  }

  function resetForm() {
    setFormData({ name: '', kg: '', rate_per_kg: '' })
    setEditPacking(null)
    setShowForm(false)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      const payload = {
        name: formData.name,
        kg: parseFloat(formData.kg),
        rate_per_kg: parseFloat(formData.rate_per_kg)
      }

      if (editPacking) {
        await supabase.from('packings').update(payload).eq('id', editPacking.id)
      } else {
        await supabase.from('packings').insert(payload)
      }
      resetForm()
      loadPackings()
    } catch (error) {
      console.error('Error saving packing:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this packing?')) return
    try {
      await supabase.from('packings').delete().eq('id', id)
      loadPackings()
    } catch (error) {
      console.error('Error deleting packing:', error)
    }
  }

  function startEdit(packing: Packing) {
    setEditPacking(packing)
    setFormData({
      name: packing.name,
      kg: packing.kg.toString(),
      rate_per_kg: packing.rate_per_kg.toString()
    })
    setShowForm(true)
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div></div>
        <button
          onClick={() => { resetForm(); setShowForm(true) }}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
        >
          <Plus size={18} /> Add Product/Packing
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-800">
              {editPacking ? 'Edit Product/Packing' : 'Add New Product/Packing'}
            </h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600">
              <X size={20} />
            </button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input
                type="text"
                placeholder="Product Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                required
              />
              <input
                type="number"
                step="0.01"
                placeholder="Weight (KG)"
                value={formData.kg}
                onChange={(e) => setFormData({ ...formData, kg: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                required
              />
              <input
                type="number"
                step="0.01"
                placeholder="Rate per KG"
                value={formData.rate_per_kg}
                onChange={(e) => setFormData({ ...formData, rate_per_kg: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={resetForm} className="px-4 py-2 text-slate-600 hover:text-slate-800">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600">
                {editPacking ? 'Update' : 'Submit'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Product Name</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Weight (KG)</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Rate/KG</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Total/Bag</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {packings.map((packing) => (
              <tr key={packing.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{packing.name}</td>
                <td className="px-4 py-3 text-slate-600">{packing.kg} KG</td>
                <td className="px-4 py-3 text-slate-600">Rs. {packing.rate_per_kg}/KG</td>
                <td className="px-4 py-3 text-slate-800 font-medium">Rs. {(packing.kg * packing.rate_per_kg).toFixed(2)}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-2">
                    <button onClick={() => startEdit(packing)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                      <Edit size={16} />
                    </button>
                    <button onClick={() => handleDelete(packing.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {packings.length === 0 && (
          <div className="p-8 text-center text-slate-500">No products found. Add your first product!</div>
        )}
      </div>
    </div>
  )
}

// Raw Material Entry
function RawMaterialEntry({ setView }: { setView: (v: View) => void }) {
  const [formData, setFormData] = useState({
    party_name: '',
    mobile_number: '',
    address: '',
    material_name: '',
    quantity: '',
    quantity_type: 'kg' as 'bag' | 'kg' | 'ton' | 'quintal',
    total_amount: '',
    notes: ''
  })
  const [billNumber, setBillNumber] = useState('00000')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    loadBillNumber()
  }, [])

  async function loadBillNumber() {
    try {
      const { data } = await supabase.from('raw_materials').select('bill_number').order('bill_number', { ascending: false }).limit(1)
      const lastBill = data?.[0]?.bill_number || '00000'
      const nextNum = parseInt(lastBill) + 1
      setBillNumber(nextNum.toString().padStart(5, '0'))
    } catch (error) {
      console.error('Error loading bill number:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await supabase.from('raw_materials').insert({
        bill_number: billNumber,
        party_name: formData.party_name,
        mobile_number: formData.mobile_number,
        address: formData.address,
        material_name: formData.material_name,
        quantity: parseFloat(formData.quantity),
        quantity_type: formData.quantity_type,
        total_amount: parseFloat(formData.total_amount),
        notes: formData.notes || null
      })
      setView('raw-materials')
    } catch (error) {
      console.error('Error saving raw material:', error)
      alert('Error saving record')
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="max-w-3xl mx-auto">
      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
        <div className="text-center pb-4 border-b border-slate-200">
          <h2 className="text-2xl font-bold text-slate-800">Raw Material Entry</h2>
          <p className="text-slate-500 mt-1">Bill Number: <span className="font-bold text-amber-600">{billNumber}</span></p>
        </div>

        {/* Party Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-700 flex items-center gap-2">
            <Users size={20} /> Party Details
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="text"
              placeholder="Party Name *"
              value={formData.party_name}
              onChange={(e) => setFormData({ ...formData, party_name: e.target.value })}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <input
              type="tel"
              placeholder="Mobile Number *"
              value={formData.mobile_number}
              onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <input
              type="text"
              placeholder="Address *"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
          </div>
        </div>

        {/* Material Details */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-700 flex items-center gap-2">
            <Layers size={20} /> Material Details
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="text"
              placeholder="Material Name *"
              value={formData.material_name}
              onChange={(e) => setFormData({ ...formData, material_name: e.target.value })}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <input
              type="number"
              step="0.001"
              placeholder="Quantity *"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <select
              value={formData.quantity_type}
              onChange={(e) => setFormData({ ...formData, quantity_type: e.target.value as 'bag' | 'kg' | 'ton' | 'quintal' })}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
            >
              <option value="bag">Bag</option>
              <option value="kg">KG</option>
              <option value="ton">Ton</option>
              <option value="quintal">Quintal</option>
            </select>
          </div>
        </div>

        {/* Amount & Notes */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Total Amount (Rs.) *</label>
              <input
                type="number"
                step="0.01"
                placeholder="Total Amount"
                value={formData.total_amount}
                onChange={(e) => setFormData({ ...formData, total_amount: e.target.value })}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 text-xl font-semibold"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Notes (Optional)</label>
              <input
                type="text"
                placeholder="Any additional notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={() => setView('dashboard')}
            className="px-6 py-2 text-slate-600 hover:text-slate-800"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="flex items-center gap-2 px-6 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 disabled:opacity-50"
          >
            {submitting ? 'Saving...' : 'Submit'}
          </button>
        </div>
      </form>
    </div>
  )
}

// Raw Materials View
function RawMaterialsView() {
  const [materials, setMaterials] = useState<RawMaterial[]>([])
  const [loading, setLoading] = useState(true)
  const [editMaterial, setEditMaterial] = useState<RawMaterial | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    party_name: '',
    mobile_number: '',
    address: '',
    material_name: '',
    quantity: '',
    quantity_type: 'kg' as 'bag' | 'kg' | 'ton' | 'quintal',
    total_amount: '',
    notes: ''
  })

  useEffect(() => {
    loadMaterials()
  }, [])

  async function loadMaterials() {
    try {
      const { data } = await supabase.from('raw_materials').select('*').order('created_at', { ascending: false })
      setMaterials(data || [])
    } catch (error) {
      console.error('Error loading materials:', error)
    } finally {
      setLoading(false)
    }
  }

  function resetForm() {
    setFormData({
      party_name: '',
      mobile_number: '',
      address: '',
      material_name: '',
      quantity: '',
      quantity_type: 'kg',
      total_amount: '',
      notes: ''
    })
    setEditMaterial(null)
    setShowForm(false)
  }

  function startEdit(material: RawMaterial) {
    setEditMaterial(material)
    setFormData({
      party_name: material.party_name,
      mobile_number: material.mobile_number,
      address: material.address,
      material_name: material.material_name,
      quantity: material.quantity.toString(),
      quantity_type: material.quantity_type,
      total_amount: material.total_amount.toString(),
      notes: material.notes || ''
    })
    setShowForm(true)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      if (editMaterial) {
        await supabase.from('raw_materials').update({
          ...formData,
          quantity: parseFloat(formData.quantity),
          total_amount: parseFloat(formData.total_amount),
          updated_at: new Date().toISOString()
        }).eq('id', editMaterial.id)
      }
      resetForm()
      loadMaterials()
    } catch (error) {
      console.error('Error updating material:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this record?')) return
    try {
      await supabase.from('raw_materials').delete().eq('id', id)
      loadMaterials()
    } catch (error) {
      console.error('Error deleting material:', error)
    }
  }

  async function handlePrint(material: RawMaterial) {
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Raw Material #${material.bill_number}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 15px; }
              .details { margin: 16px 0; line-height: 1.8; }
              .total { font-size: 20px; font-weight: bold; text-align: right; margin: 20px 0; padding: 10px; background: #f0f0f0; }
              @media print { body { -webkit-print-color-adjust: exact; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1 style="margin: 0;">${COMPANY_INFO.name}</h1>
              <p style="margin: 5px 0;">${COMPANY_INFO.address}</p>
              <p>Mobile: ${COMPANY_INFO.mobile}</p>
            </div>
            <div style="display: flex; justify-content: space-between; margin: 20px 0;">
              <div><strong>Bill No:</strong> ${material.bill_number}</div>
              <div><strong>Date:</strong> ${new Date(material.created_at).toLocaleDateString()}</div>
            </div>
            <div class="details">
              <p><strong>Party Name:</strong> ${material.party_name}</p>
              <p><strong>Mobile:</strong> ${material.mobile_number}</p>
              <p><strong>Address:</strong> ${material.address}</p>
            </div>
            <hr />
            <div class="details">
              <p><strong>Material:</strong> ${material.material_name}</p>
              <p><strong>Quantity:</strong> ${material.quantity} ${material.quantity_type}</p>
            </div>
            <div class="total">Total: Rs. ${material.total_amount.toFixed(2)}</div>
            ${material.notes ? `<p><strong>Notes:</strong> ${material.notes}</p>` : ''}
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  async function downloadPDF(material: RawMaterial) {
    handlePrint(material)
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  const totalAmount = materials.reduce((sum, m) => sum + m.total_amount, 0)

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500">Total Raw Material Value</p>
            <p className="text-3xl font-bold text-cyan-600">Rs. {totalAmount.toLocaleString()}</p>
          </div>
          <div className="bg-cyan-100 p-4 rounded-xl">
            <Layers className="text-cyan-600" size={32} />
          </div>
        </div>
      </div>

      {showForm && editMaterial && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Edit Raw Material</h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <input type="text" placeholder="Party Name" value={formData.party_name}
                onChange={(e) => setFormData({ ...formData, party_name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
              <input type="tel" placeholder="Mobile" value={formData.mobile_number}
                onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
              <input type="text" placeholder="Address" value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <input type="text" placeholder="Material" value={formData.material_name}
                onChange={(e) => setFormData({ ...formData, material_name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
              <input type="number" step="0.001" placeholder="Quantity" value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
              <select value={formData.quantity_type}
                onChange={(e) => setFormData({ ...formData, quantity_type: e.target.value as any })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg">
                <option value="bag">Bag</option>
                <option value="kg">KG</option>
                <option value="ton">Ton</option>
                <option value="quintal">Quintal</option>
              </select>
              <input type="number" step="0.01" placeholder="Amount" value={formData.total_amount}
                onChange={(e) => setFormData({ ...formData, total_amount: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={resetForm} className="px-4 py-2 text-slate-600">Cancel</button>
              <button type="submit" className="px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600">Update</button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-3 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
              <th className="px-3 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Party</th>
              <th className="px-3 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Material</th>
              <th className="px-3 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Qty</th>
              <th className="px-3 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Amount</th>
              <th className="px-3 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              <th className="px-3 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {materials.map((material) => (
              <tr key={material.id} className="hover:bg-slate-50">
                <td className="px-3 py-3 font-bold text-slate-800">{material.bill_number}</td>
                <td className="px-3 py-3">
                  <p className="font-medium text-slate-800">{material.party_name}</p>
                  <p className="text-xs text-slate-500">{material.mobile_number}</p>
                </td>
                <td className="px-3 py-3 text-slate-600">{material.material_name}</td>
                <td className="px-3 py-3 text-slate-600">{material.quantity} {material.quantity_type}</td>
                <td className="px-3 py-3 font-semibold text-slate-800">Rs. {material.total_amount.toLocaleString()}</td>
                <td className="px-3 py-3 text-slate-500 text-sm">{new Date(material.created_at).toLocaleDateString()}</td>
                <td className="px-3 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => handlePrint(material)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Print">
                      <Printer size={16} />
                    </button>
                    <button onClick={() => downloadPDF(material)} className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg" title="PDF">
                      <Download size={16} />
                    </button>
                    <button onClick={() => startEdit(material)} className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg" title="Edit">
                      <Edit size={16} />
                    </button>
                    <button onClick={() => handleDelete(material.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {materials.length === 0 && (
          <div className="p-8 text-center text-slate-500">No raw materials found.</div>
        )}
      </div>
    </div>
  )
}

// New Bill View
function NewBillView({ setView }: { setView: (v: View) => void }) {
  const [parties, setParties] = useState<Party[]>([])
  const [packings, setPackings] = useState<Packing[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedParty, setSelectedParty] = useState('')
  const [items, setItems] = useState<Array<{ packing_id: string; quantity: number }>>([])
  const [billNumber, setBillNumber] = useState('')

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    try {
      const [partiesRes, packingsRes, billsRes] = await Promise.all([
        supabase.from('parties').select('*').order('name'),
        supabase.from('packings').select('*').order('name'),
        supabase.from('bills').select('bill_number').order('bill_number', { ascending: false }).limit(1)
      ])

      setParties(partiesRes.data || [])
      setPackings(packingsRes.data || [])

      const lastBill = billsRes.data?.[0]?.bill_number || '00000'
      const nextNum = parseInt(lastBill) + 1
      setBillNumber(nextNum.toString().padStart(5, '0'))
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  function addItem() {
    setItems([...items, { packing_id: '', quantity: 1 }])
  }

  function removeItem(index: number) {
    setItems(items.filter((_, i) => i !== index))
  }

  function updateItem(index: number, field: 'packing_id' | 'quantity', value: string | number) {
    const newItems = [...items]
    if (field === 'packing_id') {
      newItems[index].packing_id = value as string
    } else {
      newItems[index].quantity = value as number
    }
    setItems(newItems)
  }

  function calculateItemTotal(item: { packing_id: string; quantity: number }) {
    const packing = packings.find(p => p.id === item.packing_id)
    if (!packing) return 0
    return packing.kg * packing.rate_per_kg * item.quantity
  }

  function calculateGrandTotal() {
    return items.reduce((sum, item) => sum + calculateItemTotal(item), 0)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!selectedParty || items.length === 0 || items.some(i => !i.packing_id)) {
      alert('Please select party and add at least one item')
      return
    }

    try {
      const totalAmount = calculateGrandTotal()

      const { data: bill } = await supabase.from('bills').insert({
        bill_number: billNumber,
        party_id: selectedParty,
        total_amount: totalAmount,
        pending_amount: totalAmount,
        status: 'pending'
      }).select().single()

      if (bill) {
        const billItems = items.map(item => {
          const packing = packings.find(p => p.id === item.packing_id)!
          return {
            bill_id: bill.id,
            packing_id: item.packing_id,
            quantity: item.quantity,
            kg: packing.kg,
            rate_per_kg: packing.rate_per_kg,
            amount: calculateItemTotal(item)
          }
        })
        await supabase.from('bill_items').insert(billItems)
      }

      setView('bills')
    } catch (error) {
      console.error('Error creating bill:', error)
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Bill Number</label>
            <input
              type="text"
              value={billNumber}
              onChange={(e) => setBillNumber(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-xl font-bold text-center"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Select Party</label>
            <select
              value={selectedParty}
              onChange={(e) => setSelectedParty(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              required
            >
              <option value="">Select Party</option>
              {parties.map(p => (
                <option key={p.id} value={p.id}>{p.name} - {p.mobile_number}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Items</h3>
            <button
              type="button"
              onClick={addItem}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <Plus size={16} /> Add Item
            </button>
          </div>

          <div className="space-y-3">
            {items.map((item, index) => {
              const packing = packings.find(p => p.id === item.packing_id)
              return (
                <div key={index} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                  <select
                    value={item.packing_id}
                    onChange={(e) => updateItem(index, 'packing_id', e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="">Select Product</option>
                    {packings.map(p => (
                      <option key={p.id} value={p.id}>{p.name} ({p.kg} KG @ Rs.{p.rate_per_kg}/KG)</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 0)}
                    className="w-24 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                    placeholder="Qty"
                  />
                  <div className="w-32 text-right font-medium text-slate-800">
                    {packing ? `Rs. ${calculateItemTotal(item).toFixed(2)}` : '-'}
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(index)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              )
            })}
          </div>
        </div>

        <div className="border-t border-slate-200 pt-4">
          <div className="flex items-center justify-between text-xl">
            <span className="font-semibold text-slate-700">Grand Total:</span>
            <span className="font-bold text-slate-900">Rs. {calculateGrandTotal().toFixed(2)}</span>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <button
            type="button"
            onClick={() => setView('bills')}
            className="px-4 py-2 text-slate-600 hover:text-slate-800"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
          >
            <Calculator size={18} /> Create Bill
          </button>
        </div>
      </form>
    </div>
  )
}

// Bills View
function BillsView() {
  const [bills, setBills] = useState<(Bill & { party: Party | null; items?: (BillItem & { packing: Packing | null })[] })[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedBill, setSelectedBill] = useState<typeof bills[0] | null>(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [showFullPaymentModal, setShowFullPaymentModal] = useState(false)
  const [paymentAmount, setPaymentAmount] = useState('')
  const [paymentNotes, setPaymentNotes] = useState('')
  const printRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    loadBills()
  }, [])

  async function loadBills() {
    try {
      const { data } = await supabase
        .from('bills')
        .select(`
          *,
          party:parties(*),
          items:bill_items(*, packing:packings(*))
        `)
        .order('created_at', { ascending: false })

      setBills(data || [])
    } catch (error) {
      console.error('Error loading bills:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this bill?')) return
    try {
      await supabase.from('bill_items').delete().eq('bill_id', id)
      await supabase.from('payments').delete().eq('bill_id', id)
      await supabase.from('bills').delete().eq('id', id)
      loadBills()
    } catch (error) {
      console.error('Error deleting bill:', error)
    }
  }

  async function handlePayment(fullPayment = false) {
    if (!selectedBill) return

    const amount = fullPayment ? selectedBill.pending_amount : parseFloat(paymentAmount)
    if (!amount || amount <= 0) return

    try {
      const newPaidAmount = (selectedBill.paid_amount || 0) + amount
      const newPendingAmount = (selectedBill.total_amount || 0) - newPaidAmount

      await supabase.from('payments').insert({
        bill_id: selectedBill.id,
        amount,
        notes: paymentNotes || (fullPayment ? 'Full Payment' : null)
      })

      await supabase.from('bills').update({
        paid_amount: newPaidAmount,
        pending_amount: newPendingAmount,
        status: newPendingAmount <= 0 ? 'paid' : newPaidAmount > 0 ? 'partial' : 'pending',
        updated_at: new Date().toISOString()
      }).eq('id', selectedBill.id)

      setShowPaymentModal(false)
      setShowFullPaymentModal(false)
      setPaymentAmount('')
      setPaymentNotes('')
      setSelectedBill(null)
      loadBills()
    } catch (error) {
      console.error('Error adding payment:', error)
    }
  }

  function handlePrint(bill: typeof bills[0], bw = false) {
    setSelectedBill(bill)
    setTimeout(() => {
      const printWindow = window.open('', '_blank')
      if (printWindow && printRef.current) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Bill #${bill.bill_number}</title>
              <style>
                body { font-family: ${bw ? 'Courier New, monospace' : 'Arial, sans-serif'}; padding: 20px; ${bw ? 'background: #fff; color: #000;' : ''} }
                table { width: 100%; border-collapse: collapse; margin: 16px 0; }
                th, td { border: 1px solid ${bw ? '#000' : '#ddd'}; padding: 8px; text-align: left; }
                th { background: ${bw ? '#fff' : '#f5f5f5'}; ${bw ? 'font-weight: bold;' : ''} }
                .header { text-align: center; margin-bottom: 20px; }
                .total { font-size: 18px; font-weight: bold; margin: 16px 0; }
                ${bw ? '@media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }' : ''}
              </style>
            </head>
            <body>
              ${printRef.current.innerHTML}
            </body>
          </html>
        `)
        printWindow.document.close()
        printWindow.print()
      }
    }, 100)
  }

  async function downloadPDF(bill: typeof bills[0]) {
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Bill #${bill.bill_number}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
              table { width: 100%; border-collapse: collapse; margin: 16px 0; }
              th, td { border: 1px solid #333; padding: 8px; text-align: left; }
              th { background: #f0f0f0; }
              .header { text-align: center; margin-bottom: 20px; }
              .total { font-size: 18px; font-weight: bold; margin: 16px 0; text-align: right; }
              @media print { body { -webkit-print-color-adjust: exact; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1 style="margin-bottom: 5px;">${COMPANY_INFO.name}</h1>
              <p>${COMPANY_INFO.address}</p>
              <p>Mobile: ${COMPANY_INFO.mobile} | GST: ${COMPANY_INFO.gst}</p>
            </div>
            <hr style="border: 2px solid #333; margin: 20px 0;">
            <div style="display: flex; justify-content: space-between; margin: 20px 0;">
              <div>
                <strong>Bill To:</strong><br/>
                ${bill.party?.name || 'N/A'}<br/>
                ${bill.party?.mobile_number || ''}<br/>
                ${bill.party?.address || ''}
              </div>
              <div style="text-align: right;">
                <strong>Bill No:</strong> ${bill.bill_number}<br/>
                <strong>Date:</strong> ${new Date(bill.created_at).toLocaleDateString()}
              </div>
            </div>
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product</th>
                  <th>Weight (KG)</th>
                  <th>Rate/KG</th>
                  <th>Qty</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                ${(bill.items || []).map((item, i) => `
                  <tr>
                    <td>${i + 1}</td>
                    <td>${item.packing?.name || 'N/A'}</td>
                    <td>${item.kg} KG</td>
                    <td>Rs. ${item.rate_per_kg}</td>
                    <td>${item.quantity}</td>
                    <td>Rs. ${item.amount.toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div class="total">
              Total: Rs. ${(bill.total_amount || 0).toFixed(2)}
            </div>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Party</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Total</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Paid</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Pending</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {bills.map((bill) => (
              <tr key={bill.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-bold text-slate-800">{bill.bill_number}</td>
                <td className="px-4 py-3 text-slate-600">{bill.party?.name || 'N/A'}</td>
                <td className="px-4 py-3 text-slate-800">Rs. {(bill.total_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-green-600">Rs. {(bill.paid_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-red-600">Rs. {(bill.pending_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    bill.status === 'paid' ? 'bg-green-100 text-green-700' :
                    bill.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {bill.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-500 text-sm">{new Date(bill.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1 flex-wrap">
                    <button
                      onClick={() => { setSelectedBill(bill); setShowPaymentModal(true) }}
                      className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg"
                      title="Add Payment"
                    >
                      <DollarSign size={16} />
                    </button>
                    <button
                      onClick={() => { setSelectedBill(bill); setShowFullPaymentModal(true) }}
                      className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg"
                      title="Full Payment"
                    >
                      <CheckCircle size={16} />
                    </button>
                    <button
                      onClick={() => handlePrint(bill, true)}
                      className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"
                      title="Print Bill (B&W)"
                    >
                      <Printer size={16} />
                    </button>
                    <button
                      onClick={() => downloadPDF(bill)}
                      className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg"
                      title="Download PDF"
                    >
                      <Download size={16} />
                    </button>
                    <button
                      onClick={() => handleDelete(bill.id)}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg"
                      title="Delete"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {bills.length === 0 && (
          <div className="p-8 text-center text-slate-500">No bills found. Create your first bill!</div>
        )}
      </div>

      {/* Print Template */}
      <div ref={printRef} style={{ display: 'none' }}>
        {selectedBill && (
          <div>
            <div className="text-center mb-5">
              <h1 className="text-xl font-bold">{COMPANY_INFO.name}</h1>
              <p>{COMPANY_INFO.address}</p>
              <p>Mobile: {COMPANY_INFO.mobile} | GST: {COMPANY_INFO.gst}</p>
            </div>
            <hr className="my-4" />
            <div className="flex justify-between my-4">
              <div>
                <strong>Bill To:</strong><br />
                {selectedBill.party?.name || 'N/A'}<br />
                {selectedBill.party?.mobile_number || ''}<br />
                {selectedBill.party?.address || ''}
              </div>
              <div style={{ textAlign: 'right' }}>
                <strong>Bill No:</strong> {selectedBill.bill_number}<br />
                <strong>Date:</strong> {new Date(selectedBill.created_at).toLocaleDateString()}
              </div>
            </div>
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product</th>
                  <th>Weight</th>
                  <th>Rate/KG</th>
                  <th>Qty</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {(selectedBill.items || []).map((item, i) => (
                  <tr key={item.id}>
                    <td>{i + 1}</td>
                    <td>{item.packing?.name || 'N/A'}</td>
                    <td>{item.kg} KG</td>
                    <td>Rs. {item.rate_per_kg}</td>
                    <td>{item.quantity}</td>
                    <td>Rs. {item.amount.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ textAlign: 'right', fontSize: '18px', fontWeight: 'bold', marginTop: '16px' }}>
              Total: Rs. {(selectedBill.total_amount || 0).toFixed(2)}
            </div>
            {selectedBill.paid_amount > 0 && (
              <div style={{ textAlign: 'right', marginTop: '8px' }}>
                Paid: Rs. {(selectedBill.paid_amount || 0).toFixed(2)} | Pending: Rs. {(selectedBill.pending_amount || 0).toFixed(2)}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedBill && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Add Payment</h3>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={20} />
              </button>
            </div>
            <div className="mb-4 p-3 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600">Bill: {selectedBill.bill_number}</p>
              <p className="text-sm text-slate-600">Pending: Rs. {(selectedBill.pending_amount || 0).toFixed(2)}</p>
            </div>
            <div className="space-y-4">
              <input
                type="number"
                step="0.01"
                placeholder="Payment Amount"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              />
              <input
                type="text"
                placeholder="Notes (optional)"
                value={paymentNotes}
                onChange={(e) => setPaymentNotes(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              />
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowPaymentModal(false)} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                <button onClick={() => handlePayment(false)} className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600">Add Payment</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Full Payment Modal */}
      {showFullPaymentModal && selectedBill && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Full Payment</h3>
              <button onClick={() => setShowFullPaymentModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={20} />
              </button>
            </div>
            <div className="mb-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
              <p className="text-sm text-slate-600">Bill: {selectedBill.bill_number}</p>
              <p className="text-lg font-bold text-amber-700">Full Amount: Rs. {(selectedBill.pending_amount || 0).toFixed(2)}</p>
            </div>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Notes (optional)"
                value={paymentNotes}
                onChange={(e) => setPaymentNotes(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              />
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowFullPaymentModal(false)} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                <button onClick={() => handlePayment(true)} className="px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600">Pay Full Amount</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Payments View
function PaymentsView() {
  const [payments, setPayments] = useState<(Payment & { bill: Bill & { party: Party | null } })[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadPayments()
  }, [])

  async function loadPayments() {
    try {
      const { data } = await supabase
        .from('payments')
        .select(`
          *,
          bill:bills(*, party:parties(*))
        `)
        .order('created_at', { ascending: false })

      setPayments(data || [])
    } catch (error) {
      console.error('Error loading payments:', error)
    } finally {
      setLoading(false)
    }
  }

  async function printPaymentSlip(payment: typeof payments[0]) {
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Payment Receipt</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; max-width: 400px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 20px; }
              .details { margin: 16px 0; line-height: 1.8; }
              .total { font-size: 24px; font-weight: bold; text-align: center; margin: 20px 0; padding: 10px; background: #f0f0f0; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1 style="margin: 0;">${COMPANY_INFO.name}</h1>
              <p style="margin: 5px 0;">${COMPANY_INFO.address}</p>
            </div>
            <hr />
            <div class="details">
              <p><strong>Receipt No:</strong> ${payment.id.slice(0, 8).toUpperCase()}</p>
              <p><strong>Bill No:</strong> ${payment.bill?.bill_number || 'N/A'}</p>
              <p><strong>Party:</strong> ${payment.bill?.party?.name || 'N/A'}</p>
              <p><strong>Date:</strong> ${new Date(payment.payment_date).toLocaleDateString()}</p>
            </div>
            <div class="total">
              Amount: Rs. ${payment.amount.toFixed(2)}
            </div>
            ${payment.notes ? `<p><strong>Notes:</strong> ${payment.notes}</p>` : ''}
            <hr style="margin: 20px 0;" />
            <p style="text-align: center; font-size: 12px; color: #666;">Thank you for your payment!</p>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  async function deletePayment(id: string) {
    if (!confirm('Are you sure you want to delete this payment?')) return
    try {
      const payment = payments.find(p => p.id === id)
      if (payment?.bill) {
        const newPaidAmount = (payment.bill.paid_amount || 0) - payment.amount
        const newPendingAmount = (payment.bill.total_amount || 0) - newPaidAmount
        await supabase.from('bills').update({
          paid_amount: newPaidAmount,
          pending_amount: newPendingAmount,
          status: newPendingAmount <= 0 ? 'paid' : newPaidAmount > 0 ? 'partial' : 'pending',
          updated_at: new Date().toISOString()
        }).eq('id', payment.bill.id)
      }
      await supabase.from('payments').delete().eq('id', id)
      loadPayments()
    } catch (error) {
      console.error('Error deleting payment:', error)
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  const totalPayments = payments.reduce((sum, p) => sum + p.amount, 0)

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500">Total Payments Received</p>
            <p className="text-3xl font-bold text-green-600">Rs. {totalPayments.toLocaleString()}</p>
          </div>
          <div className="bg-green-100 p-4 rounded-xl">
            <TrendingUp className="text-green-600" size={32} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Party</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Notes</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {payments.map((payment) => (
              <tr key={payment.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{payment.bill?.bill_number || 'N/A'}</td>
                <td className="px-4 py-3 text-slate-600">{payment.bill?.party?.name || 'N/A'}</td>
                <td className="px-4 py-3 text-green-600 font-semibold">Rs. {payment.amount.toLocaleString()}</td>
                <td className="px-4 py-3 text-slate-500 text-sm">{new Date(payment.payment_date).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-slate-500 text-sm">{payment.notes || '-'}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => printPaymentSlip(payment)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Print Slip">
                      <Printer size={16} />
                    </button>
                    <button onClick={() => deletePayment(payment.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {payments.length === 0 && (
          <div className="p-8 text-center text-slate-500">No payments found.</div>
        )}
      </div>
    </div>
  )
}

// Dealers View
function DealersView() {
  const [dealers, setDealers] = useState<Dealer[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editDealer, setEditDealer] = useState<Dealer | null>(null)
  const [formData, setFormData] = useState({ name: '', mobile_number: '', address: '' })
  const [search, setSearch] = useState('')

  useEffect(() => { loadDealers() }, [])

  async function loadDealers() {
    try {
      const { data } = await supabase.from('dealers').select('*').order('name')
      setDealers(data || [])
    } catch (error) {
      console.error('Error loading dealers:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      if (editDealer) {
        await supabase.from('dealers').update({ ...formData, updated_at: new Date().toISOString() }).eq('id', editDealer.id)
      } else {
        await supabase.from('dealers').insert(formData)
      }
      setFormData({ name: '', mobile_number: '', address: '' })
      setEditDealer(null)
      setShowForm(false)
      loadDealers()
    } catch (error) {
      console.error('Error saving dealer:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this dealer?')) return
    try {
      await supabase.from('dealers').delete().eq('id', id)
      loadDealers()
    } catch (error) {
      console.error('Error deleting dealer:', error)
    }
  }

  function startEdit(dealer: Dealer) {
    setEditDealer(dealer)
    setFormData({ name: dealer.name, mobile_number: dealer.mobile_number, address: dealer.address })
    setShowForm(true)
  }

  function cancelForm() {
    setShowForm(false)
    setEditDealer(null)
    setFormData({ name: '', mobile_number: '', address: '' })
  }

  const filteredDealers = dealers.filter(d =>
    d.name.toLowerCase().includes(search.toLowerCase()) ||
    d.mobile_number.includes(search) ||
    d.address.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Search dealers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 w-64"
          />
        </div>
        <button
          onClick={() => { setEditDealer(null); setFormData({ name: '', mobile_number: '', address: '' }); setShowForm(true) }}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
        >
          <Plus size={18} /> Add Dealer
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">{editDealer ? 'Edit Dealer' : 'Add New Dealer'}</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="text"
              placeholder="Dealer Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <input
              type="text"
              placeholder="Mobile Number"
              value={formData.mobile_number}
              onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
              className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <input
              type="text"
              placeholder="Address"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
              required
            />
            <div className="md:col-span-3 flex justify-end gap-3">
              <button type="button" onClick={cancelForm} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
              <button type="submit" className="flex items-center gap-2 px-6 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600">
                {editDealer ? <><Edit size={18} /> Update</> : <><Plus size={18} /> Add Dealer</>}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">#</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Name</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Mobile</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Address</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredDealers.map((dealer, i) => (
              <tr key={dealer.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{dealer.name}</td>
                <td className="px-4 py-3 text-slate-600 flex items-center gap-1"><Phone size={14} /> {dealer.mobile_number}</td>
                <td className="px-4 py-3 text-slate-600">{dealer.address}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => startEdit(dealer)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Edit"><Edit size={16} /></button>
                    <button onClick={() => handleDelete(dealer.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredDealers.length === 0 && (
          <div className="p-8 text-center text-slate-500">No dealers found. Add your first dealer!</div>
        )}
      </div>
    </div>
  )
}

// Dealer Packings View
function DealerPackingsView() {
  const [dealers, setDealers] = useState<Dealer[]>([])
  const [packings, setPackings] = useState<(DealerPacking & { dealer: Dealer | null })[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editPacking, setEditPacking] = useState<(DealerPacking & { dealer: Dealer | null }) | null>(null)
  const [selectedDealer, setSelectedDealer] = useState('')
  const [formData, setFormData] = useState({ product_name: '', kg: '', bhav_per_kg: '' })
  const [filterDealer, setFilterDealer] = useState('')

  useEffect(() => { loadData() }, [])

  async function loadData() {
    try {
      const [dealersRes, packingsRes] = await Promise.all([
        supabase.from('dealers').select('*').order('name'),
        supabase.from('dealer_packings').select('*, dealer:dealers(*)').order('product_name')
      ])
      setDealers(dealersRes.data || [])
      setPackings(packingsRes.data || [])
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!selectedDealer) { alert('Please select a dealer'); return }
    try {
      const payload = {
        dealer_id: selectedDealer,
        product_name: formData.product_name,
        kg: parseFloat(formData.kg),
        bhav_per_kg: parseFloat(formData.bhav_per_kg)
      }
      if (editPacking) {
        await supabase.from('dealer_packings').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editPacking.id)
      } else {
        await supabase.from('dealer_packings').insert(payload)
      }
      setFormData({ product_name: '', kg: '', bhav_per_kg: '' })
      setEditPacking(null)
      setShowForm(false)
      setSelectedDealer('')
      loadData()
    } catch (error) {
      console.error('Error saving packing:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this packing?')) return
    try {
      await supabase.from('dealer_packings').delete().eq('id', id)
      loadData()
    } catch (error) {
      console.error('Error deleting packing:', error)
    }
  }

  function startEdit(packing: typeof packings[0]) {
    setEditPacking(packing)
    setSelectedDealer(packing.dealer_id)
    setFormData({ product_name: packing.product_name, kg: packing.kg.toString(), bhav_per_kg: packing.bhav_per_kg.toString() })
    setShowForm(true)
  }

  function cancelForm() {
    setShowForm(false)
    setEditPacking(null)
    setFormData({ product_name: '', kg: '', bhav_per_kg: '' })
    setSelectedDealer('')
  }

  const filteredPackings = filterDealer
    ? packings.filter(p => p.dealer_id === filterDealer)
    : packings

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <select
          value={filterDealer}
          onChange={(e) => setFilterDealer(e.target.value)}
          className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
        >
          <option value="">All Dealers</option>
          {dealers.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
        <button
          onClick={() => { setEditPacking(null); setFormData({ product_name: '', kg: '', bhav_per_kg: '' }); setShowForm(true) }}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors"
        >
          <Plus size={18} /> Add Packing
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">{editPacking ? 'Edit Packing' : 'Add New Packing'}</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Select Dealer</label>
              <select
                value={selectedDealer}
                onChange={(e) => setSelectedDealer(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                required
              >
                <option value="">Select Dealer</option>
                {dealers.map(d => <option key={d.id} value={d.id}>{d.name} - {d.mobile_number}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Product Name</label>
              <input
                type="text"
                placeholder="Product Name"
                value={formData.product_name}
                onChange={(e) => setFormData({ ...formData, product_name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">KG</label>
              <input
                type="number"
                step="0.01"
                placeholder="Weight in KG"
                value={formData.kg}
                onChange={(e) => setFormData({ ...formData, kg: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Bhav Per KG</label>
              <input
                type="number"
                step="0.01"
                placeholder="Rate per KG"
                value={formData.bhav_per_kg}
                onChange={(e) => setFormData({ ...formData, bhav_per_kg: e.target.value })}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                required
              />
            </div>
            <div className="md:col-span-2 flex justify-end gap-3">
              <button type="button" onClick={cancelForm} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
              <button type="submit" className="flex items-center gap-2 px-6 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600">
                {editPacking ? <><Edit size={18} /> Update</> : <><Plus size={18} /> Add Packing</>}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">#</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Dealer</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Product</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">KG</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bhav/KG</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Total</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredPackings.map((packing, i) => (
              <tr key={packing.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{packing.dealer?.name || 'N/A'}</td>
                <td className="px-4 py-3 text-slate-700">{packing.product_name}</td>
                <td className="px-4 py-3 text-slate-600">{packing.kg} KG</td>
                <td className="px-4 py-3 text-slate-600">Rs. {packing.bhav_per_kg}</td>
                <td className="px-4 py-3 font-semibold text-slate-800">Rs. {(packing.kg * packing.bhav_per_kg).toFixed(2)}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => startEdit(packing)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Edit"><Edit size={16} /></button>
                    <button onClick={() => handleDelete(packing.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredPackings.length === 0 && (
          <div className="p-8 text-center text-slate-500">No packings found. Add your first packing!</div>
        )}
      </div>
    </div>
  )
}

// Selling Dashboard
function SellingDashboard({ setView }: { setView: (v: View) => void }) {
  const [stats, setStats] = useState({
    totalBills: 0, totalAmount: 0, totalPaid: 0, totalPending: 0, totalDealers: 0, totalPackings: 0,
    totalDeliveryCharge: 0, avgBillAmount: 0, collectionRate: 0
  })
  const [recentBills, setRecentBills] = useState<(SellingBill & { dealer: Dealer | null })[]>([])
  const [monthlyData, setMonthlyData] = useState<{ month: string; sales: number; paid: number }[]>([])
  const [dealerData, setDealerData] = useState<{ name: string; value: number }[]>([])
  const [statusData, setStatusData] = useState<{ name: string; value: number }[]>([])
  const [productData, setProductData] = useState<{ name: string; value: number }[]>([])
  const [dailyTrend, setDailyTrend] = useState<{ date: string; sales: number; payments: number }[]>([])
  const [paymentTrend, setPaymentTrend] = useState<{ month: string; collected: number; pending: number }[]>([])
  const [deliveryData, setDeliveryData] = useState<{ month: string; charges: number }[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadData() }, [])

  async function loadData() {
    try {
      const [billsRes, dealersRes, packingsRes, paymentsRes, billItemsRes] = await Promise.all([
        supabase.from('selling_bills').select('*, dealer:dealers(*)').order('created_at', { ascending: false }),
        supabase.from('dealers').select('id', { count: 'exact' }),
        supabase.from('dealer_packings').select('id', { count: 'exact' }),
        supabase.from('selling_payments').select('amount, payment_date, bill_id').order('payment_date', { ascending: false }).limit(60),
        supabase.from('selling_bill_items').select('product_name, amount, quantity')
      ])

      const bills = billsRes.data || []
      const totalAmount = bills.reduce((sum, b) => sum + (b.total_amount || 0), 0)
      const totalPaid = bills.reduce((sum, b) => sum + (b.paid_amount || 0), 0)
      const totalDeliveryCharge = bills.reduce((sum, b) => sum + (b.delivery_charge || 0), 0)

      setStats({
        totalBills: bills.length,
        totalAmount,
        totalPaid,
        totalPending: totalAmount - totalPaid,
        totalDealers: dealersRes.count || 0,
        totalPackings: packingsRes.count || 0,
        totalDeliveryCharge,
        avgBillAmount: bills.length > 0 ? totalAmount / bills.length : 0,
        collectionRate: totalAmount > 0 ? (totalPaid / totalAmount) * 100 : 0
      })
      setRecentBills(bills.slice(0, 10) as (SellingBill & { dealer: Dealer | null })[])

      // Monthly sales + paid data
      const monthMap = new Map<string, { sales: number; paid: number }>()
      bills.forEach(b => {
        const month = new Date(b.created_at).toLocaleString('en', { month: 'short', year: '2-digit' })
        const existing = monthMap.get(month) || { sales: 0, paid: 0 }
        monthMap.set(month, { sales: existing.sales + (b.total_amount || 0), paid: existing.paid + (b.paid_amount || 0) })
      })
      setMonthlyData(Array.from(monthMap.entries()).slice(-6).map(([month, v]) => ({ month, sales: v.sales, paid: v.paid })))

      // Dealer-wise sales
      const dealerMap = new Map<string, number>()
      bills.forEach(b => {
        const name = b.dealer?.name || 'Unknown'
        dealerMap.set(name, (dealerMap.get(name) || 0) + (b.total_amount || 0))
      })
      setDealerData(Array.from(dealerMap.entries()).slice(0, 6).map(([name, value]) => ({ name, value })))

      // Status breakdown
      const paidCount = bills.filter(b => b.status === 'paid').length
      const partialCount = bills.filter(b => b.status === 'partial').length
      const pendingCount = bills.filter(b => b.status === 'pending').length
      setStatusData([
        { name: 'Paid', value: paidCount },
        { name: 'Partial', value: partialCount },
        { name: 'Pending', value: pendingCount }
      ])

      // Product-wise breakdown
      const productMap = new Map<string, number>()
      ;(billItemsRes.data || []).forEach(item => {
        productMap.set(item.product_name, (productMap.get(item.product_name) || 0) + (item.amount || 0))
      })
      setProductData(Array.from(productMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, value]) => ({ name, value })))

      // Daily trend (last 14 days)
      const payments = paymentsRes.data || []
      const dailyMap = new Map<string, { sales: number; payments: number }>()
      bills.forEach(b => {
        const date = new Date(b.created_at).toLocaleDateString('en', { day: '2-digit', month: 'short' })
        const existing = dailyMap.get(date) || { sales: 0, payments: 0 }
        dailyMap.set(date, { sales: existing.sales + (b.total_amount || 0), payments: existing.payments })
      })
      payments.forEach(p => {
        const date = new Date(p.payment_date).toLocaleDateString('en', { day: '2-digit', month: 'short' })
        const existing = dailyMap.get(date) || { sales: 0, payments: 0 }
        dailyMap.set(date, { sales: existing.sales, payments: existing.payments + (p.amount || 0) })
      })
      setDailyTrend(Array.from(dailyMap.entries()).slice(-14).map(([date, v]) => ({ date, sales: v.sales, payments: v.payments })))

      // Payment collection trend (monthly)
      const payMonthMap = new Map<string, { collected: number; pending: number }>()
      bills.forEach(b => {
        const month = new Date(b.created_at).toLocaleString('en', { month: 'short', year: '2-digit' })
        const existing = payMonthMap.get(month) || { collected: 0, pending: 0 }
        payMonthMap.set(month, { collected: existing.collected + (b.paid_amount || 0), pending: existing.pending + (b.pending_amount || 0) })
      })
      setPaymentTrend(Array.from(payMonthMap.entries()).slice(-6).map(([month, v]) => ({ month, collected: v.collected, pending: v.pending })))

      // Delivery charge trend
      const deliveryMap = new Map<string, number>()
      bills.forEach(b => {
        const month = new Date(b.created_at).toLocaleString('en', { month: 'short', year: '2-digit' })
        deliveryMap.set(month, (deliveryMap.get(month) || 0) + (b.delivery_charge || 0))
      })
      setDeliveryData(Array.from(deliveryMap.entries()).slice(-6).map(([month, charges]) => ({ month, charges })))
    } catch (error) {
      console.error('Error loading selling dashboard:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>

  return (
    <div className="space-y-6">
      <CompanyProfile />

      {/* Key Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setView('selling-bills')}>
          <div className="flex flex-col items-center text-center">
            <div className="bg-amber-100 p-3 rounded-xl mb-2"><Receipt className="text-amber-600" size={24} /></div>
            <p className="text-xs text-slate-500">Total Bills</p>
            <p className="text-2xl font-bold text-slate-800">{stats.totalBills}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow">
          <div className="flex flex-col items-center text-center">
            <div className="bg-blue-100 p-3 rounded-xl mb-2"><IndianRupee className="text-blue-600" size={24} /></div>
            <p className="text-xs text-slate-500">Total Amount</p>
            <p className="text-xl font-bold text-slate-800">Rs. {stats.totalAmount.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow">
          <div className="flex flex-col items-center text-center">
            <div className="bg-green-100 p-3 rounded-xl mb-2"><CheckCircle className="text-green-600" size={24} /></div>
            <p className="text-xs text-slate-500">Total Paid</p>
            <p className="text-xl font-bold text-green-600">Rs. {stats.totalPaid.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow">
          <div className="flex flex-col items-center text-center">
            <div className="bg-red-100 p-3 rounded-xl mb-2"><Clock className="text-red-600" size={24} /></div>
            <p className="text-xs text-slate-500">Total Pending</p>
            <p className="text-xl font-bold text-red-600">Rs. {stats.totalPending.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setView('dealers')}>
          <div className="flex flex-col items-center text-center">
            <div className="bg-purple-100 p-3 rounded-xl mb-2"><Store className="text-purple-600" size={24} /></div>
            <p className="text-xs text-slate-500">Dealers</p>
            <p className="text-2xl font-bold text-slate-800">{stats.totalDealers}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setView('dealer-packings')}>
          <div className="flex flex-col items-center text-center">
            <div className="bg-teal-100 p-3 rounded-xl mb-2"><Package className="text-teal-600" size={24} /></div>
            <p className="text-xs text-slate-500">Packings</p>
            <p className="text-2xl font-bold text-slate-800">{stats.totalPackings}</p>
          </div>
        </div>
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl border border-amber-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-amber-600 font-medium">Delivery Charges</p>
              <p className="text-2xl font-bold text-amber-800">Rs. {stats.totalDeliveryCharge.toLocaleString()}</p>
            </div>
            <Truck className="text-amber-500" size={28} />
          </div>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-blue-600 font-medium">Avg Bill Amount</p>
              <p className="text-2xl font-bold text-blue-800">Rs. {stats.avgBillAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            </div>
            <BarChart3 className="text-blue-500" size={28} />
          </div>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-green-600 font-medium">Collection Rate</p>
              <p className="text-2xl font-bold text-green-800">{stats.collectionRate.toFixed(1)}%</p>
            </div>
            <TrendingUp className="text-green-500" size={28} />
          </div>
          <div className="mt-2 w-full bg-green-200 rounded-full h-2">
            <div className="bg-green-600 rounded-full h-2 transition-all duration-500" style={{ width: `${Math.min(stats.collectionRate, 100)}%` }}></div>
          </div>
        </div>
      </div>

      {/* Charts Row 1 - Sales Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {monthlyData.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Monthly Sales vs Collection</h3>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-amber-500 rounded"></span> Sales</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-500 rounded"></span> Collected</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} />
                <Legend />
                <Bar dataKey="sales" name="Sales" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="paid" name="Collected" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
        {statusData.some(d => d.value > 0) && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Bill Status Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={60} outerRadius={110} paddingAngle={5} dataKey="value" label={({ name, value, percent }) => `${name}: ${value} (${(percent * 100).toFixed(0)}%)`}>
                  {statusData.map((_, i) => <Cell key={i} fill={['#10b981', '#f59e0b', '#ef4444'][i]} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Charts Row 2 - Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {dailyTrend.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Daily Sales & Payments</h3>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-blue-500 rounded"></span> Sales</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-500 rounded"></span> Payments</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={dailyTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis />
                <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} />
                <Line type="monotone" dataKey="sales" name="Sales" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
                <Line type="monotone" dataKey="payments" name="Payments" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        {paymentTrend.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Payment Collection Trend</h3>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-500 rounded"></span> Collected</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-red-400 rounded"></span> Pending</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={paymentTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} />
                <Legend />
                <Bar dataKey="collected" name="Collected" stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} />
                <Bar dataKey="pending" name="Pending" stackId="a" fill="#f87171" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Charts Row 3 - Product & Dealer breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {productData.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Product-wise Sales</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={productData} cx="50%" cy="50%" outerRadius={110} dataKey="value" label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                  {productData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
        {dealerData.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Top Dealers by Sales</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dealerData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis type="category" dataKey="name" width={130} tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} />
                <Bar dataKey="value" name="Sales" radius={[0, 4, 4, 0]}>
                  {dealerData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Delivery Charge Trend */}
      {deliveryData.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Delivery Charges Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={deliveryData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} />
              <Area type="monotone" dataKey="charges" name="Delivery Charges" stroke="#f59e0b" fill="#fef3c7" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Recent Bills */}
      {recentBills.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">Recent Selling Bills</h3>
            <button onClick={() => setView('selling-bills')} className="text-sm text-amber-600 hover:text-amber-700 font-medium">View All</button>
          </div>
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Dealer</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Total</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Delivery</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentBills.slice(0, 8).map(bill => (
                <tr key={bill.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-bold text-slate-800">{bill.bill_number}</td>
                  <td className="px-4 py-3 text-slate-600">{bill.dealer?.name || 'N/A'}</td>
                  <td className="px-4 py-3 text-slate-800">Rs. {(bill.total_amount || 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-slate-500">{(bill.delivery_charge || 0) > 0 ? `Rs. ${(bill.delivery_charge || 0).toLocaleString()}` : '-'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      bill.status === 'paid' ? 'bg-green-100 text-green-700' :
                      bill.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>{bill.status}</span>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-sm">{new Date(bill.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// New Selling Bill View
function NewSellingBillView({ setView }: { setView: (v: View) => void }) {
  const [dealers, setDealers] = useState<Dealer[]>([])
  const [packings, setPackings] = useState<(DealerPacking & { dealer: Dealer | null })[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedDealer, setSelectedDealer] = useState('')
  const [billNumber, setBillNumber] = useState('')
  const [deliveryCharge, setDeliveryCharge] = useState('0')
  const [notes, setNotes] = useState('')
  const [items, setItems] = useState<Array<{ packing_id: string; quantity: number }>>([])

  useEffect(() => { loadData() }, [])

  async function loadData() {
    try {
      const [dealersRes, packingsRes, billsRes] = await Promise.all([
        supabase.from('dealers').select('*').order('name'),
        supabase.from('dealer_packings').select('*, dealer:dealers(*)').order('product_name'),
        supabase.from('selling_bills').select('bill_number').order('bill_number', { ascending: false }).limit(1)
      ])
      setDealers(dealersRes.data || [])
      setPackings(packingsRes.data || [])
      const lastBill = billsRes.data?.[0]?.bill_number || '00000'
      const nextNum = parseInt(lastBill) + 1
      setBillNumber(nextNum.toString().padStart(5, '0'))
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredPackings = selectedDealer
    ? packings.filter(p => p.dealer_id === selectedDealer)
    : packings

  function addItem() { setItems([...items, { packing_id: '', quantity: 1 }]) }
  function removeItem(index: number) { setItems(items.filter((_, i) => i !== index)) }
  function updateItem(index: number, field: 'packing_id' | 'quantity', value: string | number) {
    const newItems = [...items]
    if (field === 'packing_id') newItems[index].packing_id = value as string
    else newItems[index].quantity = value as number
    setItems(newItems)
  }

  function calculateItemTotal(item: { packing_id: string; quantity: number }) {
    const packing = packings.find(p => p.id === item.packing_id)
    if (!packing) return 0
    return packing.kg * packing.bhav_per_kg * item.quantity
  }

  function calculateSubTotal() { return items.reduce((sum, item) => sum + calculateItemTotal(item), 0) }
  function calculateGrandTotal() { return calculateSubTotal() + parseFloat(deliveryCharge || '0') }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!selectedDealer || items.length === 0 || items.some(i => !i.packing_id)) {
      alert('Please select dealer and add at least one item')
      return
    }
    try {
      const totalAmount = calculateGrandTotal()
      const deliveryChargeVal = parseFloat(deliveryCharge || '0')

      const { data: bill } = await supabase.from('selling_bills').insert({
        bill_number: billNumber,
        dealer_id: selectedDealer,
        total_amount: totalAmount,
        pending_amount: totalAmount,
        delivery_charge: deliveryChargeVal,
        notes: notes || null,
        status: 'pending'
      }).select().single()

      if (bill) {
        const billItems = items.map(item => {
          const packing = packings.find(p => p.id === item.packing_id)!
          return {
            bill_id: bill.id,
            packing_id: item.packing_id,
            product_name: packing.product_name,
            quantity: item.quantity,
            kg: packing.kg,
            bhav_per_kg: packing.bhav_per_kg,
            amount: calculateItemTotal(item)
          }
        })
        await supabase.from('selling_bill_items').insert(billItems)
      }
      setView('selling-bills')
    } catch (error) {
      console.error('Error creating selling bill:', error)
    }
  }

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>

  return (
    <div className="max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Bill Number</label>
            <input
              type="text"
              value={billNumber}
              onChange={(e) => setBillNumber(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-xl font-bold text-center"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Select Dealer</label>
            <select
              value={selectedDealer}
              onChange={(e) => setSelectedDealer(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              required
            >
              <option value="">Select Dealer</option>
              {dealers.map(d => (
                <option key={d.id} value={d.id}>{d.name} - {d.mobile_number}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Delivery Charge</label>
            <input
              type="number"
              step="0.01"
              value={deliveryCharge}
              onChange={(e) => setDeliveryCharge(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              placeholder="0"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Items</h3>
            <button
              type="button"
              onClick={addItem}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <Plus size={16} /> Add Item
            </button>
          </div>

          <div className="space-y-3">
            {items.map((item, index) => {
              const packing = packings.find(p => p.id === item.packing_id)
              return (
                <div key={index} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                  <select
                    value={item.packing_id}
                    onChange={(e) => updateItem(index, 'packing_id', e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="">Select Product</option>
                    {filteredPackings.map(p => (
                      <option key={p.id} value={p.id}>{p.product_name} ({p.kg} KG @ Rs.{p.bhav_per_kg}/KG)</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 0)}
                    className="w-24 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
                    placeholder="Qty"
                  />
                  <div className="w-32 text-right font-medium text-slate-800">
                    {packing ? `Rs. ${calculateItemTotal(item).toFixed(2)}` : '-'}
                  </div>
                  <button type="button" onClick={() => removeItem(index)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg">
                    <Trash2 size={18} />
                  </button>
                </div>
              )
            })}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Notes</label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
            rows={2}
            placeholder="Additional notes..."
          />
        </div>

        <div className="border-t border-slate-200 pt-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-600">Sub Total:</span>
            <span className="font-medium text-slate-800">Rs. {calculateSubTotal().toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 flex items-center gap-1"><Truck size={16} /> Delivery Charge:</span>
            <span className="font-medium text-slate-800">Rs. {parseFloat(deliveryCharge || '0').toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between text-xl border-t border-slate-200 pt-2">
            <span className="font-semibold text-slate-700">Grand Total:</span>
            <span className="font-bold text-slate-900">Rs. {calculateGrandTotal().toFixed(2)}</span>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <button type="button" onClick={() => setView('selling-bills')} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
          <button type="submit" className="flex items-center gap-2 px-6 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors">
            <Calculator size={18} /> Create Bill
          </button>
        </div>
      </form>
    </div>
  )
}

// Selling Bills View
function SellingBillsView() {
  const [bills, setBills] = useState<(SellingBill & { dealer: Dealer | null; items?: (SellingBillItem & { packing: DealerPacking | null })[] })[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedBill, setSelectedBill] = useState<typeof bills[0] | null>(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [showFullPaymentModal, setShowFullPaymentModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [paymentAmount, setPaymentAmount] = useState('')
  const [paymentNotes, setPaymentNotes] = useState('')
  const [editFormData, setEditFormData] = useState({ bill_number: '', delivery_charge: '', notes: '' })
  const printRef = useRef<HTMLDivElement>(null)

  useEffect(() => { loadBills() }, [])

  async function loadBills() {
    try {
      const { data } = await supabase
        .from('selling_bills')
        .select(`*, dealer:dealers(*), items:selling_bill_items(*, packing:dealer_packings(*))`)
        .order('created_at', { ascending: false })
      setBills(data || [])
    } catch (error) {
      console.error('Error loading selling bills:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this bill?')) return
    try {
      await supabase.from('selling_bill_items').delete().eq('bill_id', id)
      await supabase.from('selling_payments').delete().eq('bill_id', id)
      await supabase.from('selling_bills').delete().eq('id', id)
      loadBills()
    } catch (error) {
      console.error('Error deleting bill:', error)
    }
  }

  async function handlePayment(fullPayment = false) {
    if (!selectedBill) return
    const amount = fullPayment ? selectedBill.pending_amount : parseFloat(paymentAmount)
    if (!amount || amount <= 0) return
    try {
      const newPaidAmount = (selectedBill.paid_amount || 0) + amount
      const newPendingAmount = (selectedBill.total_amount || 0) - newPaidAmount
      await supabase.from('selling_payments').insert({
        bill_id: selectedBill.id,
        amount,
        notes: paymentNotes || (fullPayment ? 'Full Payment' : null)
      })
      await supabase.from('selling_bills').update({
        paid_amount: newPaidAmount,
        pending_amount: newPendingAmount,
        status: newPendingAmount <= 0 ? 'paid' : newPaidAmount > 0 ? 'partial' : 'pending',
        updated_at: new Date().toISOString()
      }).eq('id', selectedBill.id)
      setShowPaymentModal(false)
      setShowFullPaymentModal(false)
      setPaymentAmount('')
      setPaymentNotes('')
      setSelectedBill(null)
      loadBills()
    } catch (error) {
      console.error('Error adding payment:', error)
    }
  }

  function startEdit(bill: typeof bills[0]) {
    setSelectedBill(bill)
    setEditFormData({
      bill_number: bill.bill_number,
      delivery_charge: (bill.delivery_charge || 0).toString(),
      notes: bill.notes || ''
    })
    setShowEditModal(true)
  }

  async function handleEditSubmit() {
    if (!selectedBill) return
    try {
      const deliveryChargeVal = parseFloat(editFormData.delivery_charge || '0')
      const itemsTotal = (selectedBill.items || []).reduce((sum, item) => sum + item.amount, 0)
      const newTotal = itemsTotal + deliveryChargeVal
      const newPending = newTotal - (selectedBill.paid_amount || 0)

      await supabase.from('selling_bills').update({
        bill_number: editFormData.bill_number,
        delivery_charge: deliveryChargeVal,
        notes: editFormData.notes || null,
        total_amount: newTotal,
        pending_amount: newPending,
        status: newPending <= 0 ? 'paid' : (selectedBill.paid_amount || 0) > 0 ? 'partial' : 'pending',
        updated_at: new Date().toISOString()
      }).eq('id', selectedBill.id)
      setShowEditModal(false)
      setSelectedBill(null)
      loadBills()
    } catch (error) {
      console.error('Error updating bill:', error)
    }
  }

  function handlePrint(bill: typeof bills[0], bw = false) {
    setSelectedBill(bill)
    setTimeout(() => {
      const printWindow = window.open('', '_blank')
      if (printWindow && printRef.current) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Bill #${bill.bill_number}</title>
              <style>
                body { font-family: ${bw ? 'Courier New, monospace' : 'Arial, sans-serif'}; padding: 20px; ${bw ? 'background: #fff; color: #000;' : ''} }
                table { width: 100%; border-collapse: collapse; margin: 16px 0; }
                th, td { border: 1px solid ${bw ? '#000' : '#ddd'}; padding: 8px; text-align: left; }
                th { background: ${bw ? '#fff' : '#f5f5f5'}; ${bw ? 'font-weight: bold;' : ''} }
                .header { text-align: center; margin-bottom: 20px; }
                .total { font-size: 18px; font-weight: bold; margin: 16px 0; }
              </style>
            </head>
            <body>
              ${printRef.current.innerHTML}
            </body>
          </html>
        `)
        printWindow.document.close()
        printWindow.print()
      }
    }, 100)
  }

  async function downloadPDF(bill: typeof bills[0]) {
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Selling Bill #${bill.bill_number}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
              table { width: 100%; border-collapse: collapse; margin: 16px 0; }
              th, td { border: 1px solid #333; padding: 8px; text-align: left; }
              th { background: #f0f0f0; }
              .header { text-align: center; margin-bottom: 20px; }
              .total { font-size: 18px; font-weight: bold; margin: 16px 0; text-align: right; }
              @media print { body { -webkit-print-color-adjust: exact; } }
            </style>
          </head>
          <body>
            <div class="header">
              <h1 style="margin-bottom: 5px;">${COMPANY_INFO.name}</h1>
              <p>${COMPANY_INFO.address}</p>
              <p>Mobile: ${COMPANY_INFO.mobile} | GST: ${COMPANY_INFO.gst}</p>
            </div>
            <hr style="border: 2px solid #333; margin: 20px 0;">
            <div style="display: flex; justify-content: space-between; margin: 20px 0;">
              <div>
                <strong>Bill To:</strong><br/>
                ${bill.dealer?.name || 'N/A'}<br/>
                ${bill.dealer?.mobile_number || ''}<br/>
                ${bill.dealer?.address || ''}
              </div>
              <div style="text-align: right;">
                <strong>Bill No:</strong> ${bill.bill_number}<br/>
                <strong>Date:</strong> ${new Date(bill.created_at).toLocaleDateString()}
              </div>
            </div>
            <table>
              <thead>
                <tr><th>#</th><th>Product</th><th>Weight (KG)</th><th>Bhav/KG</th><th>Qty</th><th>Amount</th></tr>
              </thead>
              <tbody>
                ${(bill.items || []).map((item, i) => `
                  <tr>
                    <td>${i + 1}</td>
                    <td>${item.product_name}</td>
                    <td>${item.kg} KG</td>
                    <td>Rs. ${item.bhav_per_kg}</td>
                    <td>${item.quantity}</td>
                    <td>Rs. ${item.amount.toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            ${bill.delivery_charge > 0 ? `<div style="text-align: right;">Delivery Charge: Rs. ${bill.delivery_charge.toFixed(2)}</div>` : ''}
            <div class="total">Total: Rs. ${(bill.total_amount || 0).toFixed(2)}</div>
            ${bill.paid_amount > 0 ? `<div style="text-align: right;">Paid: Rs. ${(bill.paid_amount || 0).toFixed(2)} | Pending: Rs. ${(bill.pending_amount || 0).toFixed(2)}</div>` : ''}
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  async function printSlip(bill: typeof bills[0]) {
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Slip #${bill.bill_number}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 15px; max-width: 350px; margin: 0 auto; font-size: 14px; }
              .header { text-align: center; margin-bottom: 10px; }
              .details { margin: 10px 0; line-height: 1.6; }
              .total { font-size: 20px; font-weight: bold; text-align: center; margin: 10px 0; padding: 8px; background: #f0f0f0; }
              hr { margin: 10px 0; }
            </style>
          </head>
          <body>
            <div class="header">
              <strong>${COMPANY_INFO.name}</strong><br/>
              <small>${COMPANY_INFO.address} | ${COMPANY_INFO.mobile}</small>
            </div>
            <hr />
            <div class="details">
              <p><strong>Bill No:</strong> ${bill.bill_number}</p>
              <p><strong>Dealer:</strong> ${bill.dealer?.name || 'N/A'}</p>
              <p><strong>Date:</strong> ${new Date(bill.created_at).toLocaleDateString()}</p>
            </div>
            ${(bill.items || []).map((item, i) => `
              <div>${i + 1}. ${item.product_name} - ${item.quantity}x ${item.kg}KG @ Rs.${item.bhav_per_kg} = Rs.${item.amount.toFixed(2)}</div>
            `).join('')}
            ${bill.delivery_charge > 0 ? `<div>Delivery: Rs. ${bill.delivery_charge.toFixed(2)}</div>` : ''}
            <div class="total">Total: Rs. ${(bill.total_amount || 0).toFixed(2)}</div>
            ${bill.paid_amount > 0 ? `<div style="text-align: center;">Paid: Rs. ${(bill.paid_amount || 0).toFixed(2)} | Pending: Rs. ${(bill.pending_amount || 0).toFixed(2)}</div>` : ''}
            <hr />
            <p style="text-align: center; font-size: 11px; color: #666;">Thank you!</p>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Dealer</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Total</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Paid</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Pending</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Delivery</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {bills.map((bill) => (
              <tr key={bill.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-bold text-slate-800">{bill.bill_number}</td>
                <td className="px-4 py-3 text-slate-600">{bill.dealer?.name || 'N/A'}</td>
                <td className="px-4 py-3 text-slate-800">Rs. {(bill.total_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-green-600">Rs. {(bill.paid_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-red-600">Rs. {(bill.pending_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-slate-600">Rs. {(bill.delivery_charge || 0).toLocaleString()}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    bill.status === 'paid' ? 'bg-green-100 text-green-700' :
                    bill.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>{bill.status}</span>
                </td>
                <td className="px-4 py-3 text-slate-500 text-sm">{new Date(bill.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1 flex-wrap">
                    <button onClick={() => { setSelectedBill(bill); setShowPaymentModal(true) }} className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg" title="Payment"><DollarSign size={16} /></button>
                    <button onClick={() => { setSelectedBill(bill); setShowFullPaymentModal(true) }} className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg" title="Full Payment"><CheckCircle size={16} /></button>
                    <button onClick={() => startEdit(bill)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Edit"><Edit size={16} /></button>
                    <button onClick={() => handlePrint(bill, true)} className="p-1.5 text-slate-600 hover:bg-slate-50 rounded-lg" title="Print B&W"><Printer size={16} /></button>
                    <button onClick={() => downloadPDF(bill)} className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg" title="Download PDF"><Download size={16} /></button>
                    <button onClick={() => printSlip(bill)} className="p-1.5 text-orange-600 hover:bg-orange-50 rounded-lg" title="Print Slip"><FileText size={16} /></button>
                    <button onClick={() => handleDelete(bill.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {bills.length === 0 && (
          <div className="p-8 text-center text-slate-500">No selling bills found. Create your first selling bill!</div>
        )}
      </div>

      {/* Print Template */}
      <div ref={printRef} style={{ display: 'none' }}>
        {selectedBill && (
          <div>
            <div className="text-center mb-5">
              <h1 className="text-xl font-bold">{COMPANY_INFO.name}</h1>
              <p>{COMPANY_INFO.address}</p>
              <p>Mobile: {COMPANY_INFO.mobile} | GST: {COMPANY_INFO.gst}</p>
            </div>
            <hr className="my-4" />
            <div className="flex justify-between my-4">
              <div>
                <strong>Bill To:</strong><br />
                {selectedBill.dealer?.name || 'N/A'}<br />
                {selectedBill.dealer?.mobile_number || ''}<br />
                {selectedBill.dealer?.address || ''}
              </div>
              <div style={{ textAlign: 'right' }}>
                <strong>Bill No:</strong> {selectedBill.bill_number}<br />
                <strong>Date:</strong> {new Date(selectedBill.created_at).toLocaleDateString()}
              </div>
            </div>
            <table>
              <thead>
                <tr><th>#</th><th>Product</th><th>Weight</th><th>Bhav/KG</th><th>Qty</th><th>Amount</th></tr>
              </thead>
              <tbody>
                {(selectedBill.items || []).map((item, i) => (
                  <tr key={item.id}>
                    <td>{i + 1}</td>
                    <td>{item.product_name}</td>
                    <td>{item.kg} KG</td>
                    <td>Rs. {item.bhav_per_kg}</td>
                    <td>{item.quantity}</td>
                    <td>Rs. {item.amount.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {selectedBill.delivery_charge > 0 && <div style={{ textAlign: 'right' }}>Delivery Charge: Rs. {selectedBill.delivery_charge.toFixed(2)}</div>}
            <div style={{ textAlign: 'right', fontSize: '18px', fontWeight: 'bold', marginTop: '16px' }}>
              Total: Rs. {(selectedBill.total_amount || 0).toFixed(2)}
            </div>
            {selectedBill.paid_amount > 0 && (
              <div style={{ textAlign: 'right', marginTop: '8px' }}>
                Paid: Rs. {(selectedBill.paid_amount || 0).toFixed(2)} | Pending: Rs. {(selectedBill.pending_amount || 0).toFixed(2)}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedBill && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Add Payment</h3>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
            </div>
            <div className="mb-4 p-3 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600">Bill: {selectedBill.bill_number}</p>
              <p className="text-sm text-slate-600">Pending: Rs. {(selectedBill.pending_amount || 0).toFixed(2)}</p>
            </div>
            <div className="space-y-4">
              <input type="number" step="0.01" placeholder="Payment Amount" value={paymentAmount} onChange={(e) => setPaymentAmount(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500" />
              <input type="text" placeholder="Notes (optional)" value={paymentNotes} onChange={(e) => setPaymentNotes(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500" />
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowPaymentModal(false)} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                <button onClick={() => handlePayment(false)} className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600">Add Payment</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Full Payment Modal */}
      {showFullPaymentModal && selectedBill && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Full Payment</h3>
              <button onClick={() => setShowFullPaymentModal(false)} className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
            </div>
            <div className="mb-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
              <p className="text-sm text-slate-600">Bill: {selectedBill.bill_number}</p>
              <p className="text-lg font-bold text-amber-700">Full Amount: Rs. {(selectedBill.pending_amount || 0).toFixed(2)}</p>
            </div>
            <div className="space-y-4">
              <input type="text" placeholder="Notes (optional)" value={paymentNotes} onChange={(e) => setPaymentNotes(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500" />
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowFullPaymentModal(false)} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                <button onClick={() => handlePayment(true)} className="px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600">Pay Full Amount</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedBill && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-800">Edit Bill</h3>
              <button onClick={() => setShowEditModal(false)} className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Bill Number</label>
                <input type="text" value={editFormData.bill_number} onChange={(e) => setEditFormData({ ...editFormData, bill_number: e.target.value })} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Delivery Charge</label>
                <input type="number" step="0.01" value={editFormData.delivery_charge} onChange={(e) => setEditFormData({ ...editFormData, delivery_charge: e.target.value })} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Notes</label>
                <textarea value={editFormData.notes} onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500" rows={2} />
              </div>
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowEditModal(false)} className="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                <button onClick={handleEditSubmit} className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600"><Edit size={16} /> Update</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Selling Payments View
function SellingPaymentsView() {
  const [payments, setPayments] = useState<(SellingPayment & { bill: SellingBill & { dealer: Dealer | null } })[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadPayments() }, [])

  async function loadPayments() {
    try {
      const { data } = await supabase
        .from('selling_payments')
        .select(`*, bill:selling_bills(*, dealer:dealers(*))`)
        .order('created_at', { ascending: false })
      setPayments(data || [])
    } catch (error) {
      console.error('Error loading selling payments:', error)
    } finally {
      setLoading(false)
    }
  }

  async function printPaymentSlip(payment: typeof payments[0]) {
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Payment Receipt</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; max-width: 400px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 20px; }
              .details { margin: 16px 0; line-height: 1.8; }
              .total { font-size: 24px; font-weight: bold; text-align: center; margin: 20px 0; padding: 10px; background: #f0f0f0; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1 style="margin: 0;">${COMPANY_INFO.name}</h1>
              <p style="margin: 5px 0;">${COMPANY_INFO.address}</p>
            </div>
            <hr />
            <div class="details">
              <p><strong>Receipt No:</strong> ${payment.id.slice(0, 8).toUpperCase()}</p>
              <p><strong>Bill No:</strong> ${payment.bill?.bill_number || 'N/A'}</p>
              <p><strong>Dealer:</strong> ${payment.bill?.dealer?.name || 'N/A'}</p>
              <p><strong>Date:</strong> ${new Date(payment.payment_date).toLocaleDateString()}</p>
            </div>
            <div class="total">Amount: Rs. ${payment.amount.toFixed(2)}</div>
            ${payment.notes ? `<p><strong>Notes:</strong> ${payment.notes}</p>` : ''}
            <hr style="margin: 20px 0;" />
            <p style="text-align: center; font-size: 12px; color: #666;">Thank you for your payment!</p>
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    }
  }

  async function deletePayment(id: string) {
    if (!confirm('Are you sure you want to delete this payment?')) return
    try {
      const payment = payments.find(p => p.id === id)
      if (payment?.bill) {
        const newPaidAmount = (payment.bill.paid_amount || 0) - payment.amount
        const newPendingAmount = (payment.bill.total_amount || 0) - newPaidAmount
        await supabase.from('selling_bills').update({
          paid_amount: newPaidAmount,
          pending_amount: newPendingAmount,
          status: newPendingAmount <= 0 ? 'paid' : newPaidAmount > 0 ? 'partial' : 'pending',
          updated_at: new Date().toISOString()
        }).eq('id', payment.bill.id)
      }
      await supabase.from('selling_payments').delete().eq('id', id)
      loadPayments()
    } catch (error) {
      console.error('Error deleting payment:', error)
    }
  }

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>

  const totalPayments = payments.reduce((sum, p) => sum + p.amount, 0)

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500">Total Selling Payments Received</p>
            <p className="text-3xl font-bold text-green-600">Rs. {totalPayments.toLocaleString()}</p>
          </div>
          <div className="bg-green-100 p-4 rounded-xl"><TrendingUp className="text-green-600" size={32} /></div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Bill No</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Dealer</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Notes</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {payments.map((payment) => (
              <tr key={payment.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{payment.bill?.bill_number || 'N/A'}</td>
                <td className="px-4 py-3 text-slate-600">{payment.bill?.dealer?.name || 'N/A'}</td>
                <td className="px-4 py-3 text-green-600 font-semibold">Rs. {payment.amount.toLocaleString()}</td>
                <td className="px-4 py-3 text-slate-500 text-sm">{new Date(payment.payment_date).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-slate-500 text-sm">{payment.notes || '-'}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => printPaymentSlip(payment)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Print Slip"><Printer size={16} /></button>
                    <button onClick={() => deletePayment(payment.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {payments.length === 0 && (
          <div className="p-8 text-center text-slate-500">No selling payments found.</div>
        )}
      </div>
    </div>
  )
}

export default App
