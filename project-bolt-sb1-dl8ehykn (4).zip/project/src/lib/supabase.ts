import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Party = {
  id: string
  name: string
  mobile_number: string
  address: string
  created_at: string
  updated_at: string
}

export type Packing = {
  id: string
  name: string
  kg: number
  rate_per_kg: number
  created_at: string
  updated_at: string
}

export type Bill = {
  id: string
  bill_number: string
  party_id: string
  total_amount: number
  paid_amount: number
  pending_amount: number
  status: string
  created_at: string
  updated_at: string
  party?: Party
  items?: BillItem[]
}

export type BillItem = {
  id: string
  bill_id: string
  packing_id: string
  quantity: number
  kg: number
  rate_per_kg: number
  amount: number
  packing?: Packing
}

export type Payment = {
  id: string
  bill_id: string
  amount: number
  payment_date: string
  notes: string | null
  created_at: string
  bill?: Bill
}

export type RawMaterial = {
  id: string
  bill_number: string
  party_name: string
  mobile_number: string
  address: string
  material_name: string
  quantity: number
  quantity_type: 'bag' | 'kg' | 'ton' | 'quintal'
  total_amount: number
  notes: string | null
  created_at: string
  updated_at: string
}

export type Dealer = {
  id: string
  name: string
  mobile_number: string
  address: string
  created_at: string
  updated_at: string
}

export type DealerPacking = {
  id: string
  dealer_id: string
  product_name: string
  kg: number
  bhav_per_kg: number
  created_at: string
  updated_at: string
  dealer?: Dealer
}

export type SellingBill = {
  id: string
  bill_number: string
  dealer_id: string
  total_amount: number
  paid_amount: number
  pending_amount: number
  delivery_charge: number
  notes: string | null
  status: string
  created_at: string
  updated_at: string
  dealer?: Dealer
  items?: SellingBillItem[]
}

export type SellingBillItem = {
  id: string
  bill_id: string
  packing_id: string
  product_name: string
  quantity: number
  kg: number
  bhav_per_kg: number
  amount: number
  created_at: string
  packing?: DealerPacking
}

export type SellingPayment = {
  id: string
  bill_id: string
  amount: number
  payment_date: string
  notes: string | null
  created_at: string
  bill?: SellingBill
}

export type KKDealer = {
  id: string
  name: string
  mobile_number: string
  address: string
  created_at: string
  updated_at: string
}

export type KKDealerPacking = {
  id: string
  dealer_id: string
  product_name: string
  kg: number
  bhav_per_kg: number
  created_at: string
  updated_at: string
  dealer?: KKDealer
}

export type KKSellingBill = {
  id: string
  bill_number: string
  dealer_id: string
  total_amount: number
  paid_amount: number
  pending_amount: number
  delivery_charge: number
  notes: string | null
  status: string
  created_at: string
  updated_at: string
  dealer?: KKDealer
  items?: KKSellingBillItem[]
}

export type KKSellingBillItem = {
  id: string
  bill_id: string
  packing_id: string
  product_name: string
  quantity: number
  kg: number
  bhav_per_kg: number
  amount: number
  created_at: string
  packing?: KKDealerPacking
}

export type KKSellingPayment = {
  id: string
  bill_id: string
  amount: number
  payment_date: string
  notes: string | null
  created_at: string
  bill?: KKSellingBill
}
