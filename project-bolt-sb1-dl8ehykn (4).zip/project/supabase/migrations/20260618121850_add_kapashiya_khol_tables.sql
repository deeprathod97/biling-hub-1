-- Kapashiya Khol Dealers table
CREATE TABLE kk_dealers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  mobile_number TEXT NOT NULL,
  address TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE kk_dealers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_kk_dealers" ON kk_dealers FOR SELECT USING (true);
CREATE POLICY "insert_kk_dealers" ON kk_dealers FOR INSERT WITH CHECK (true);
CREATE POLICY "update_kk_dealers" ON kk_dealers FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_kk_dealers" ON kk_dealers FOR DELETE USING (true);

-- Kapashiya Khol Packings table
CREATE TABLE kk_dealer_packings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_id UUID REFERENCES kk_dealers(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  kg DECIMAL NOT NULL,
  bhav_per_kg DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE kk_dealer_packings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_kk_dealer_packings" ON kk_dealer_packings FOR SELECT USING (true);
CREATE POLICY "insert_kk_dealer_packings" ON kk_dealer_packings FOR INSERT WITH CHECK (true);
CREATE POLICY "update_kk_dealer_packings" ON kk_dealer_packings FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_kk_dealer_packings" ON kk_dealer_packings FOR DELETE USING (true);

-- Kapashiya Khol Selling Bills table
CREATE TABLE kk_selling_bills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL UNIQUE,
  dealer_id UUID REFERENCES kk_dealers(id) ON DELETE SET NULL,
  total_amount DECIMAL NOT NULL DEFAULT 0,
  paid_amount DECIMAL NOT NULL DEFAULT 0,
  pending_amount DECIMAL NOT NULL DEFAULT 0,
  delivery_charge DECIMAL NOT NULL DEFAULT 0,
  notes TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE kk_selling_bills ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_kk_selling_bills" ON kk_selling_bills FOR SELECT USING (true);
CREATE POLICY "insert_kk_selling_bills" ON kk_selling_bills FOR INSERT WITH CHECK (true);
CREATE POLICY "update_kk_selling_bills" ON kk_selling_bills FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_kk_selling_bills" ON kk_selling_bills FOR DELETE USING (true);

-- Kapashiya Khol Selling Bill Items table
CREATE TABLE kk_selling_bill_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES kk_selling_bills(id) ON DELETE CASCADE,
  packing_id UUID REFERENCES kk_dealer_packings(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  kg DECIMAL NOT NULL,
  bhav_per_kg DECIMAL NOT NULL,
  amount DECIMAL NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE kk_selling_bill_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_kk_selling_bill_items" ON kk_selling_bill_items FOR SELECT USING (true);
CREATE POLICY "insert_kk_selling_bill_items" ON kk_selling_bill_items FOR INSERT WITH CHECK (true);
CREATE POLICY "update_kk_selling_bill_items" ON kk_selling_bill_items FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_kk_selling_bill_items" ON kk_selling_bill_items FOR DELETE USING (true);

-- Kapashiya Khol Selling Payments table
CREATE TABLE kk_selling_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID REFERENCES kk_selling_bills(id) ON DELETE SET NULL,
  amount DECIMAL NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE kk_selling_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_kk_selling_payments" ON kk_selling_payments FOR SELECT USING (true);
CREATE POLICY "insert_kk_selling_payments" ON kk_selling_payments FOR INSERT WITH CHECK (true);
CREATE POLICY "update_kk_selling_payments" ON kk_selling_payments FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "delete_kk_selling_payments" ON kk_selling_payments FOR DELETE USING (true);

-- Indexes
CREATE INDEX idx_kk_dealer_packings_dealer_id ON kk_dealer_packings(dealer_id);
CREATE INDEX idx_kk_selling_bills_dealer_id ON kk_selling_bills(dealer_id);
CREATE INDEX idx_kk_selling_bill_items_bill_id ON kk_selling_bill_items(bill_id);
CREATE INDEX idx_kk_selling_payments_bill_id ON kk_selling_payments(bill_id);