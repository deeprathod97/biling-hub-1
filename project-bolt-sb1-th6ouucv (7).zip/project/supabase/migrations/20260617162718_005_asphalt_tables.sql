-- Create sites table
CREATE TABLE IF NOT EXISTS sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name TEXT NOT NULL,
  site_number TEXT NOT NULL,
  site_location TEXT,
  site_incharge TEXT,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create bituminous_grades table
CREATE TABLE IF NOT EXISTS bituminous_grades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grade_name TEXT NOT NULL,
  price_per_ton DECIMAL(12,2) DEFAULT 0,
  carting_bhadu DECIMAL(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create asphalt_bills table
CREATE TABLE IF NOT EXISTS asphalt_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_number TEXT NOT NULL,
  bill_date DATE NOT NULL DEFAULT CURRENT_DATE,
  site_id uuid REFERENCES sites(id),
  bituminous_grade_id uuid REFERENCES bituminous_grades(id),
  truck_id uuid REFERENCES trucks(id),
  quantity_ton DECIMAL(12,3) DEFAULT 0,
  rate_per_ton DECIMAL(12,2) DEFAULT 0,
  carting_bhadu DECIMAL(12,2) DEFAULT 0,
  material_amount DECIMAL(12,2) DEFAULT 0,
  carting_amount DECIMAL(12,2) DEFAULT 0,
  total_amount DECIMAL(12,2) DEFAULT 0,
  payment_amount DECIMAL(12,2) DEFAULT 0,
  pending_amount DECIMAL(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE sites ENABLE ROW LEVEL SECURITY;
ALTER TABLE bituminous_grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE asphalt_bills ENABLE ROW LEVEL SECURITY;

-- RLS Policies for sites
CREATE POLICY "select_sites" ON sites FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_sites" ON sites FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_sites" ON sites FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_sites" ON sites FOR DELETE TO authenticated USING (true);

-- RLS Policies for bituminous_grades
CREATE POLICY "select_bituminous_grades" ON bituminous_grades FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_bituminous_grades" ON bituminous_grades FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_bituminous_grades" ON bituminous_grades FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_bituminous_grades" ON bituminous_grades FOR DELETE TO authenticated USING (true);

-- RLS Policies for asphalt_bills
CREATE POLICY "select_asphalt_bills" ON asphalt_bills FOR SELECT TO authenticated USING (true);
CREATE POLICY "insert_asphalt_bills" ON asphalt_bills FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "update_asphalt_bills" ON asphalt_bills FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_asphalt_bills" ON asphalt_bills FOR DELETE TO authenticated USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_sites_site_number ON sites(site_number);
CREATE INDEX IF NOT EXISTS idx_bituminous_grades_name ON bituminous_grades(grade_name);
CREATE INDEX IF NOT EXISTS idx_asphalt_bills_bill_date ON asphalt_bills(bill_date);
CREATE INDEX IF NOT EXISTS idx_asphalt_bills_site ON asphalt_bills(site_id);