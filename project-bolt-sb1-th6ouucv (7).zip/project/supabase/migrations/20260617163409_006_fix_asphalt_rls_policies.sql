-- Drop existing RLS policies that require authentication
DROP POLICY IF EXISTS "select_sites" ON sites;
DROP POLICY IF EXISTS "insert_sites" ON sites;
DROP POLICY IF EXISTS "update_sites" ON sites;
DROP POLICY IF EXISTS "delete_sites" ON sites;

DROP POLICY IF EXISTS "select_bituminous_grades" ON bituminous_grades;
DROP POLICY IF EXISTS "insert_bituminous_grades" ON bituminous_grades;
DROP POLICY IF EXISTS "update_bituminous_grades" ON bituminous_grades;
DROP POLICY IF EXISTS "delete_bituminous_grades" ON bituminous_grades;

DROP POLICY IF EXISTS "select_asphalt_bills" ON asphalt_bills;
DROP POLICY IF EXISTS "insert_asphalt_bills" ON asphalt_bills;
DROP POLICY IF EXISTS "update_asphalt_bills" ON asphalt_bills;
DROP POLICY IF EXISTS "delete_asphalt_bills" ON asphalt_bills;

-- Create new RLS policies with anonymous access (same as existing tables)
CREATE POLICY "anon_select_sites" ON sites FOR SELECT USING (true);
CREATE POLICY "anon_insert_sites" ON sites FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_sites" ON sites FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_sites" ON sites FOR DELETE USING (true);

CREATE POLICY "anon_select_bituminous_grades" ON bituminous_grades FOR SELECT USING (true);
CREATE POLICY "anon_insert_bituminous_grades" ON bituminous_grades FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_bituminous_grades" ON bituminous_grades FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_bituminous_grades" ON bituminous_grades FOR DELETE USING (true);

CREATE POLICY "anon_select_asphalt_bills" ON asphalt_bills FOR SELECT USING (true);
CREATE POLICY "anon_insert_asphalt_bills" ON asphalt_bills FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_asphalt_bills" ON asphalt_bills FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_asphalt_bills" ON asphalt_bills FOR DELETE USING (true);