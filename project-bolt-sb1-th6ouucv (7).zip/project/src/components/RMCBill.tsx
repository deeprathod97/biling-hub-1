import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Printer,
  Save,
  IndianRupee,
  Truck,
  Layers,
  MapPin,
  Scale,
  FileText,
  Hash,
  Receipt
} from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

interface Site {
  id: string;
  site_name: string;
  site_number: string;
  site_location: string | null;
  site_incharge: string | null;
}

interface TM {
  id: string;
  tm_number: string;
  tm_code: string | null;
  wheel_count: number | null;
}

interface ConcreteGrade {
  id: string;
  grade_name: string;
  price_per_mqb: number;
  carting_bhadu: number;
}

interface RMCBillProps {
  mode: 'create' | 'edit' | 'view';
  billId?: string;
  onBack: () => void;
}

export default function RMCBill({ mode, billId, onBack }: RMCBillProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sites, setSites] = useState<Site[]>([]);
  const [tms, setTMs] = useState<TM[]>([]);
  const [grades, setGrades] = useState<ConcreteGrade[]>([]);
  const [lastBillNumber, setLastBillNumber] = useState(0);

  const [formData, setFormData] = useState({
    bill_number: '',
    bill_date: new Date().toISOString().split('T')[0],
    site_id: '',
    tm_id: '',
    concrete_grade_id: '',
    quantity_mqb: '',
    payment_amount: ''
  });

  const [selectedSite, setSelectedSite] = useState<Site | null>(null);
  const [selectedTM, setSelectedTM] = useState<TM | null>(null);
  const [selectedGrade, setSelectedGrade] = useState<ConcreteGrade | null>(null);

  const [calculated, setCalculated] = useState({
    rate_per_mqb: 0,
    carting_bhadu: 0,
    material_amount: 0,
    carting_amount: 0,
    total_amount: 0,
    pending_amount: 0
  });

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const site = sites.find(s => s.id === formData.site_id);
    setSelectedSite(site || null);
  }, [formData.site_id, sites]);

  useEffect(() => {
    const tm = tms.find(t => t.id === formData.tm_id);
    setSelectedTM(tm || null);
  }, [formData.tm_id, tms]);

  useEffect(() => {
    const grade = grades.find(g => g.id === formData.concrete_grade_id);
    setSelectedGrade(grade || null);
    if (grade) {
      setCalculated(prev => ({
        ...prev,
        rate_per_mqb: grade.price_per_mqb,
        carting_bhadu: grade.carting_bhadu
      }));
    }
  }, [formData.concrete_grade_id, grades]);

  useEffect(() => {
    calculateAmounts();
  }, [formData.quantity_mqb, formData.payment_amount, selectedGrade]);

  const fetchData = async () => {
    try {
      const [sitesRes, tmsRes, gradesRes, billsRes] = await Promise.all([
        supabase.from('sites').select('*').order('site_name'),
        supabase.from('tms').select('*').order('tm_number'),
        supabase.from('concrete_grades').select('*').order('grade_name'),
        supabase.from('rmc_bills').select('bill_number').order('created_at', { ascending: false }).limit(1)
      ]);

      setSites(sitesRes.data || []);
      setTMs(tmsRes.data || []);
      setGrades(gradesRes.data || []);

      if (billsRes.data && billsRes.data.length > 0) {
        const lastNum = parseInt(billsRes.data[0].bill_number) || 0;
        setLastBillNumber(lastNum);
        setFormData(prev => ({
          ...prev,
          bill_number: String(lastNum + 1).padStart(5, '0')
        }));
      } else {
        setFormData(prev => ({ ...prev, bill_number: '00001' }));
      }

      if (billId && (mode === 'edit' || mode === 'view')) {
        const { data: billData } = await supabase
          .from('rmc_bills')
          .select('*')
          .eq('id', billId)
          .single();

        if (billData) {
          setFormData({
            bill_number: billData.bill_number,
            bill_date: billData.bill_date,
            site_id: billData.site_id || '',
            tm_id: billData.tm_id || '',
            concrete_grade_id: billData.concrete_grade_id || '',
            quantity_mqb: billData.quantity_mqb?.toString() || '',
            payment_amount: billData.payment_amount?.toString() || ''
          });
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAmounts = () => {
    const quantityMqb = parseFloat(formData.quantity_mqb) || 0;
    const paymentAmount = parseFloat(formData.payment_amount) || 0;

    if (selectedGrade) {
      const materialAmount = quantityMqb * selectedGrade.price_per_mqb;
      const cartingAmount = quantityMqb * selectedGrade.carting_bhadu;
      const totalAmount = materialAmount + cartingAmount;

      setCalculated(prev => ({
        ...prev,
        material_amount: materialAmount,
        carting_amount: cartingAmount,
        total_amount: totalAmount,
        pending_amount: totalAmount - paymentAmount
      }));
    }
  };

  const handleSubmit = async () => {
    if (!formData.site_id) {
      alert('Please select a Site');
      return;
    }
    if (!formData.concrete_grade_id) {
      alert('Please select a Concrete Grade');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        bill_number: formData.bill_number,
        bill_date: formData.bill_date,
        site_id: formData.site_id,
        tm_id: formData.tm_id === 'no-tm' ? null : formData.tm_id || null,
        concrete_grade_id: formData.concrete_grade_id,
        quantity_mqb: parseFloat(formData.quantity_mqb) || 0,
        rate_per_mqb: calculated.rate_per_mqb,
        carting_bhadu: calculated.carting_bhadu,
        material_amount: calculated.material_amount,
        carting_amount: calculated.carting_amount,
        total_amount: calculated.total_amount,
        payment_amount: parseFloat(formData.payment_amount) || 0,
        pending_amount: calculated.pending_amount,
        updated_at: new Date().toISOString()
      };

      if (mode === 'edit' && billId) {
        await supabase
          .from('rmc_bills')
          .update(payload)
          .eq('id', billId);
      } else {
        await supabase.from('rmc_bills').insert([payload]);
      }

      onBack();
    } catch (error) {
      console.error('Error saving bill:', error);
      alert('Error saving bill. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handlePrint = () => {
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>RMC Bill - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .title-bar { background: #fff; border: 2px solid #000; color: #000; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; border: 1px solid #000; }
          .site-info { margin: 20px 0; padding: 15px; border: 1px solid #000; }
          .site-name { font-size: 16px; font-weight: bold; margin-bottom: 10px; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .amount-section { margin: 20px 0; padding: 15px; border: 1px solid #000; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; padding: 5px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 30px; border-top: 1px solid #000; padding-top: 15px; font-size: 12px; text-align: center; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title-bar">READY MIX CONCRETE BILL</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${formData.bill_number}</div>
          <div><strong>Date:</strong> ${formData.bill_date}</div>
        </div>

        <div class="site-info">
          <div class="site-name">${selectedSite?.site_name || 'N/A'}</div>
          <div class="info-row"><span>Site Number:</span><span>${selectedSite?.site_number || '-'}</span></div>
          ${selectedSite?.site_location ? `<div class="info-row"><span>Location:</span><span>${selectedSite.site_location}</span></div>` : ''}
          ${selectedSite?.site_incharge ? `<div class="info-row"><span>Incharge:</span><span>${selectedSite.site_incharge}</span></div>` : ''}
        </div>

        <div class="info-row">
          <span><strong>Concrete Grade:</strong> ${selectedGrade?.grade_name || 'N/A'}</span>
          <span><strong>TM:</strong> ${selectedTM?.tm_number || 'No TM'}</span>
        </div>

        <div class="info-row">
          <span><strong>Quantity:</strong> ${formData.quantity_mqb || 0} MQB</span>
          <span><strong>Rate:</strong> ${formatCurrency(calculated.rate_per_mqb)}/MQB</span>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount (${formData.quantity_mqb || 0} MQB x ${formatCurrency(calculated.rate_per_mqb)})</span>
            <span>${formatCurrency(calculated.material_amount)}</span>
          </div>
          <div class="amount-row">
            <span>Karting Bhadu (${formData.quantity_mqb || 0} MQB x ${formatCurrency(calculated.carting_bhadu)})</span>
            <span>${formatCurrency(calculated.carting_amount)}</span>
          </div>
          <div class="amount-row total">
            <span>Total Amount</span>
            <span>${formatCurrency(calculated.total_amount)}</span>
          </div>
          ${parseFloat(formData.payment_amount || '0') > 0 ? `
          <div class="amount-row">
            <span>Payment Received</span>
            <span>${formatCurrency(parseFloat(formData.payment_amount || '0'))}</span>
          </div>
          <div class="amount-row" style="font-weight: bold;">
            <span>Balance Due</span>
            <span>${formatCurrency(calculated.pending_amount)}</span>
          </div>
          ` : ''}
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleSlipPrint = () => {
    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Gate Pass - ${formData.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 10px; max-width: 300px; margin: 0 auto; font-size: 11px; }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 8px; }
          .company-name { font-weight: bold; font-size: 14px; }
          .title { border: 1px solid #000; padding: 5px; margin: 8px -10px; text-align: center; font-weight: bold; }
          .row { display: flex; justify-content: space-between; margin: 4px 0; }
          .total { font-weight: bold; border-top: 1px dashed #000; margin-top: 5px; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
        </div>
        <div class="title">GATE PASS</div>
        <div class="row"><span>Bill No:</span><span>${formData.bill_number}</span></div>
        <div class="row"><span>Date:</span><span>${formData.bill_date}</span></div>
        <div class="row"><span>Site:</span><span>${selectedSite?.site_name || '-'}</span></div>
        <div class="row"><span>Grade:</span><span>${selectedGrade?.grade_name || '-'}</span></div>
        <div class="row"><span>TM:</span><span>${selectedTM?.tm_number || '-'}</span></div>
        <div class="row"><span>Quantity:</span><span>${formData.quantity_mqb || 0} MQB</span></div>
        <div class="total row"><span>Total:</span><span>${formatCurrency(calculated.total_amount)}</span></div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const isViewMode = mode === 'view';
  const isEditMode = mode === 'edit' || mode === 'create';

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {mode === 'create' ? 'New RMC Bill' : mode === 'edit' ? 'Edit Bill' : 'View Bill'}
            </h1>
            <p className="text-gray-500 text-sm">Ready Mix Concrete Bill</p>
          </div>
        </div>
        <div className="flex gap-2">
          {isViewMode && (
            <>
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-xl font-semibold hover:bg-gray-900 transition-all"
              >
                <Printer className="w-4 h-4" />
                Print A4
              </button>
              <button
                onClick={handleSlipPrint}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-all"
              >
                <Receipt className="w-4 h-4" />
                Gate Pass
              </button>
            </>
          )}
          {isEditMode && (
            <button
              onClick={handleSubmit}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-3 bg-gray-800 text-white rounded-xl font-semibold hover:bg-gray-900 transition-all shadow-lg disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              {saving ? 'Saving...' : 'Save Bill'}
            </button>
          )}
        </div>
      </div>

      {/* Bill Info */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Bill Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Hash className="w-4 h-4 inline mr-1" />
              Bill Number
            </label>
            <input
              type="text"
              value={formData.bill_number}
              onChange={(e) => setFormData({ ...formData, bill_number: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100 font-mono font-bold"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FileText className="w-4 h-4 inline mr-1" />
              Bill Date
            </label>
            <input
              type="date"
              value={formData.bill_date}
              onChange={(e) => setFormData({ ...formData, bill_date: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Truck className="w-4 h-4 inline mr-1" />
              TM (Transit Mixer)
            </label>
            <select
              value={formData.tm_id}
              onChange={(e) => setFormData({ ...formData, tm_id: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100"
            >
              <option value="">Select TM</option>
              <option value="no-tm">No TM</option>
              {tms.map(t => (
                <option key={t.id} value={t.id}>{t.tm_number} {t.tm_code ? `(${t.tm_code})` : ''}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Site Selection */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-purple-500" />
          Site Details
        </h3>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Select Site *</label>
          <select
            value={formData.site_id}
            onChange={(e) => setFormData({ ...formData, site_id: e.target.value })}
            disabled={isViewMode}
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100"
          >
            <option value="">Select Site</option>
            {sites.map(s => (
              <option key={s.id} value={s.id}>{s.site_name} - #{s.site_number}</option>
            ))}
          </select>
          {selectedSite && (
            <div className="mt-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
              <p className="font-semibold text-gray-900">{selectedSite.site_name}</p>
              <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-gray-600">
                <p><strong>Site No:</strong> {selectedSite.site_number}</p>
                <p><strong>Location:</strong> {selectedSite.site_location || 'N/A'}</p>
                <p><strong>Incharge:</strong> {selectedSite.site_incharge || 'N/A'}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Concrete Grade Selection */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Layers className="w-5 h-5 text-rose-500" />
          Concrete Grade
        </h3>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Select Grade *</label>
          <select
            value={formData.concrete_grade_id}
            onChange={(e) => setFormData({ ...formData, concrete_grade_id: e.target.value })}
            disabled={isViewMode}
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100"
          >
            <option value="">Select Concrete Grade</option>
            {grades.map(g => (
              <option key={g.id} value={g.id}>{g.grade_name} - {formatCurrency(g.price_per_mqb)}/MQB</option>
            ))}
          </select>
          {selectedGrade && (
            <div className="mt-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
              <p className="font-semibold text-gray-900">{selectedGrade.grade_name}</p>
              <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-gray-600">
                <p><strong>Rate:</strong> {formatCurrency(selectedGrade.price_per_mqb)}/MQB</p>
                <p><strong>Karting:</strong> {formatCurrency(selectedGrade.carting_bhadu)}/MQB</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quantity & Calculations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Scale className="w-5 h-5 text-gray-500" />
            Quantity
          </h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantity (MQB) *</label>
            <input
              type="number"
              min="0"
              step="0.001"
              value={formData.quantity_mqb}
              onChange={(e) => setFormData({ ...formData, quantity_mqb: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100 text-2xl font-bold text-center"
              placeholder="0.000"
            />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <IndianRupee className="w-5 h-5 text-gray-500" />
            Calculations
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
              <span className="text-gray-600">Material Amount</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.material_amount)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
              <span className="text-gray-600">Karting Bhadu</span>
              <span className="font-semibold text-gray-900">{formatCurrency(calculated.carting_amount)}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-900 rounded-xl text-white">
              <span className="font-semibold">Total Amount</span>
              <span className="text-2xl font-bold">{formatCurrency(calculated.total_amount)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Payment Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Payment Amount (Rs)</label>
            <input
              type="number"
              min="0"
              step="1"
              value={formData.payment_amount}
              onChange={(e) => setFormData({ ...formData, payment_amount: e.target.value })}
              disabled={isViewMode}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none disabled:bg-gray-100"
              placeholder="0"
            />
          </div>
          <div className="flex items-center justify-center p-4 bg-gray-50 rounded-xl border border-gray-200">
            <div className="text-center">
              <p className="text-gray-600 text-sm">Payment Received</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(parseFloat(formData.payment_amount || '0'))}</p>
            </div>
          </div>
          <div className={`flex items-center justify-center p-4 rounded-xl border ${calculated.pending_amount > 0 ? 'bg-red-50 border-red-200' : 'bg-gray-100 border-gray-200'}`}>
            <div className="text-center">
              <p className={`text-sm ${calculated.pending_amount > 0 ? 'text-red-700' : 'text-gray-700'}`}>
                {calculated.pending_amount > 0 ? 'Balance Due' : 'Fully Paid'}
              </p>
              <p className={`text-2xl font-bold ${calculated.pending_amount > 0 ? 'text-red-700' : 'text-gray-900'}`}>
                {formatCurrency(Math.max(0, calculated.pending_amount))}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
