import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Search,
  MapPin,
  Building,
  User,
  Phone
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Site {
  id: string;
  site_name: string;
  site_number: string;
  site_location: string | null;
  site_incharge: string | null;
  created_at: string;
}

export default function Sites() {
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingSite, setEditingSite] = useState<Site | null>(null);
  const [formData, setFormData] = useState({
    site_name: '',
    site_number: '',
    site_location: '',
    site_incharge: ''
  });

  useEffect(() => {
    fetchSites();
  }, []);

  const fetchSites = async () => {
    try {
      const { data } = await supabase
        .from('sites')
        .select('*')
        .order('site_name');
      setSites(data || []);
    } catch (error) {
      console.error('Error fetching sites:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        site_name: formData.site_name,
        site_number: formData.site_number.toUpperCase(),
        site_location: formData.site_location || null,
        site_incharge: formData.site_incharge || null,
        updated_at: new Date().toISOString()
      };

      if (editingSite) {
        await supabase
          .from('sites')
          .update(payload)
          .eq('id', editingSite.id);
      } else {
        await supabase.from('sites').insert([payload]);
      }
      resetForm();
      fetchSites();
    } catch (error) {
      console.error('Error saving site:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this site?')) return;
    try {
      await supabase.from('sites').delete().eq('id', id);
      fetchSites();
    } catch (error) {
      console.error('Error deleting site:', error);
    }
  };

  const openEditModal = (site: Site) => {
    setEditingSite(site);
    setFormData({
      site_name: site.site_name,
      site_number: site.site_number,
      site_location: site.site_location || '',
      site_incharge: site.site_incharge || ''
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      site_name: '',
      site_number: '',
      site_location: '',
      site_incharge: ''
    });
    setEditingSite(null);
    setShowModal(false);
  };

  const filteredSites = sites.filter((site) =>
    site.site_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    site.site_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    site.site_location?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-purple-100 p-3 rounded-xl">
            <MapPin className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Sites</h1>
            <p className="text-gray-500 text-sm">{sites.length} sites registered</p>
          </div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-purple-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          Add Site
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search sites..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Sites Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSites.map((site) => (
          <div
            key={site.id}
            className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-all group"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="bg-purple-50 p-3 rounded-xl">
                  <Building className="w-8 h-8 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{site.site_name}</h3>
                  <p className="text-purple-600 font-medium text-sm">#{site.site_number}</p>
                  {site.site_location && (
                    <p className="text-gray-500 text-sm mt-1 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      {site.site_location}
                    </p>
                  )}
                  {site.site_incharge && (
                    <p className="text-gray-500 text-sm mt-1 flex items-center gap-1">
                      <User className="w-3.5 h-3.5" />
                      {site.site_incharge}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEditModal(site)}
                  className="p-2 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(site.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {filteredSites.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-500">
            {searchTerm ? 'No sites found matching your search.' : 'No sites found. Add your first site to get started.'}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-xl font-bold text-gray-900">
                {editingSite ? 'Edit Site' : 'Add New Site'}
              </h2>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Building className="w-4 h-4 inline mr-1" />
                  Site Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.site_name}
                  onChange={(e) => setFormData({ ...formData, site_name: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                  placeholder="Enter site name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Site Number *</label>
                <input
                  type="text"
                  required
                  value={formData.site_number}
                  onChange={(e) => setFormData({ ...formData, site_number: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none uppercase"
                  placeholder="e.g., SITE001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <MapPin className="w-4 h-4 inline mr-1" />
                  Site Location
                </label>
                <input
                  type="text"
                  value={formData.site_location}
                  onChange={(e) => setFormData({ ...formData, site_location: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                  placeholder="Enter location"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <User className="w-4 h-4 inline mr-1" />
                  Site Incharge
                </label>
                <input
                  type="text"
                  value={formData.site_incharge}
                  onChange={(e) => setFormData({ ...formData, site_incharge: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                  placeholder="Enter incharge name"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-purple-700 transition-all"
                >
                  {editingSite ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
