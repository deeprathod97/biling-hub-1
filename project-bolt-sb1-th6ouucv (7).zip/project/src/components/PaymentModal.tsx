import { useState } from 'react';
import { X, IndianRupee, Calendar, FileText, Printer } from 'lucide-react';
import { supabase, COMPANY_PROFILE } from '../lib/supabase';

interface PaymentModalProps {
  bill: any;
  onClose: () => void;
  onSuccess: (amount: number) => void;
}

export default function PaymentModal({ bill, onClose, onSuccess }: PaymentModalProps) {
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSlip, setShowSlip] = useState(false);
  const [paymentData, setPaymentData] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const paymentAmount = parseFloat(amount) || 0;
    if (paymentAmount <= 0) return;

    setLoading(true);
    try {
      // Create payment record
      const { data: payment, error } = await supabase
        .from('payments')
        .insert([{
          bill_id: bill.id,
          amount: paymentAmount,
          payment_date: new Date().toISOString().split('T')[0],
          notes: notes || null
        }])
        .select()
        .single();

      if (error) throw error;

      setPaymentData(payment);
      onSuccess(paymentAmount);
    } catch (error) {
      console.error('Error saving payment:', error);
      alert('Failed to save payment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handlePrintSlip = () => {
    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Payment Slip - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 300px; margin: 0 auto; }
          .header { text-align: center; border-bottom: 2px dashed #000; padding-bottom: 15px; margin-bottom: 15px; }
          .logo { width: 60px; height: 60px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 16px; }
          .title { font-size: 12px; color: #666; margin-top: 5px; }
          .section { margin-bottom: 15px; }
          .row { display: flex; justify-content: space-between; margin: 5px 0; font-size: 12px; }
          .label { color: #666; }
          .value { font-weight: 500; }
          .amount-section { background: #f5f5f5; padding: 10px; border-radius: 5px; text-align: center; margin: 15px 0; }
          .amount-value { font-size: 24px; font-weight: bold; }
          .footer { border-top: 2px dashed #000; padding-top: 10px; margin-top: 15px; text-align: center; font-size: 10px; color: #666; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="title">PAYMENT RECEIPT</div>
        </div>

        <div class="section">
          <div class="row">
            <span class="label">Receipt No:</span>
            <span class="value">${paymentData?.id?.slice(0, 8).toUpperCase() || 'N/A'}</span>
          </div>
          <div class="row">
            <span class="label">Bill No:</span>
            <span class="value">${bill.bill_number}</span>
          </div>
          <div class="row">
            <span class="label">Date:</span>
            <span class="value">${new Date().toLocaleDateString('en-IN')}</span>
          </div>
        </div>

        <div class="section">
          <div class="row">
            <span class="label">Party:</span>
            <span class="value">${bill.party?.name || 'N/A'}</span>
          </div>
          ${bill.party?.mobile_number ? `
          <div class="row">
            <span class="label">Mobile:</span>
            <span class="value">${bill.party.mobile_number}</span>
          </div>
          ` : ''}
        </div>

        <div class="amount-section">
          <div class="label">Amount Received</div>
          <div class="amount-value">${formatCurrency(paymentData?.amount || parseFloat(amount))}</div>
        </div>

        <div class="section">
          <div class="row">
            <span class="label">Bill Amount:</span>
            <span class="value">${formatCurrency(bill.total_amount)}</span>
          </div>
          <div class="row">
            <span class="label">Previously Paid:</span>
            <span class="value">${formatCurrency(bill.payment_amount)}</span>
          </div>
          <div class="row">
            <span class="label">This Payment:</span>
            <span class="value">${formatCurrency(paymentData?.amount || parseFloat(amount))}</span>
          </div>
          <div class="row" style="font-weight: bold; border-top: 1px solid #ddd; padding-top: 5px; margin-top: 5px;">
            <span class="label">Balance:</span>
            <span class="value">${formatCurrency(bill.pending_amount - (paymentData?.amount || parseFloat(amount)))}</span>
          </div>
        </div>

        <div class="footer">
          <p>Thank you for your payment!</p>
          <p>${COMPANY_PROFILE.contact} | ${COMPANY_PROFILE.location}</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold text-gray-900">Add Payment</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Bill Summary */}
          <div className="bg-gray-50 rounded-xl p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Bill No:</span>
              <span className="font-medium">{bill.bill_number}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Party:</span>
              <span className="font-medium">{bill.party?.name || 'N/A'}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Total Amount:</span>
              <span className="font-medium">{formatCurrency(bill.total_amount)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Already Paid:</span>
              <span className="font-medium text-green-600">{formatCurrency(bill.payment_amount)}</span>
            </div>
            <div className="flex justify-between text-sm pt-2 border-t">
              <span className="text-gray-600 font-medium">Pending Amount:</span>
              <span className="font-bold text-red-600">{formatCurrency(bill.pending_amount)}</span>
            </div>
          </div>

          {paymentData ? (
            <div className="text-center py-4">
              <div className="text-green-600 text-4xl font-bold mb-4">
                {formatCurrency(paymentData.amount)}
              </div>
              <p className="text-gray-600">Payment recorded successfully!</p>
              <div className="flex gap-3 mt-4">
                <button
                  onClick={handlePrintSlip}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-600 transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  Print Slip
                </button>
                <button
                  onClick={onClose}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Payment Amount *</label>
                <div className="relative">
                  <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="number"
                    required
                    min="0.01"
                    max={bill.pending_amount}
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                    placeholder="Enter amount"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">Max: {formatCurrency(bill.pending_amount)}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes (Optional)</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none resize-none"
                  placeholder="Any additional notes..."
                  rows={2}
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all disabled:opacity-50"
                >
                  {loading ? 'Processing...' : 'Save Payment'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
