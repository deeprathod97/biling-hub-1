import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Search,
  Truck,
  CircleDot
} from 'lucide-react';
import { supabase, Truck as TruckType } from '../lib/supabase';

export default function Trucks() {
  const [trucks, setTrucks] = useState<TruckType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingTruck, setEditingTruck] = useState<TruckType | null>(null);
  const [formData, setFormData] = useState({
    truck_number: '',
    wheel_count: '10'
  });

  const getWheelLabel = (count: number) => {
    if (count === 0) return 'No Vehicle';
    if (count === 2) return '2 Wheels (Two Wheeler)';
    if (count === 3) return '3 Wheels (Auto)';
    if (count === 4) return '4 Wheels (Mini)';
    return `${count} Wheels`;
  };

  useEffect(() => {
    fetchTrucks();
  }, []);

  const fetchTrucks = async () => {
    try {
      const { data } = await supabase
        .from('trucks')
        .select('*')
        .order('truck_number');
      setTrucks(data || []);
    } catch (error) {
      console.error('Error fetching trucks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        truck_number: formData.truck_number.toUpperCase(),
        wheel_count: parseInt(formData.wheel_count) || 10,
        updated_at: new Date().toISOString()
      };

      if (editingTruck) {
        await supabase
          .from('trucks')
          .update(payload)
          .eq('id', editingTruck.id);
      } else {
        await supabase.from('trucks').insert([payload]);
      }
      resetForm();
      fetchTrucks();
    } catch (error) {
      console.error('Error saving truck:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this truck?')) return;
    try {
      await supabase.from('trucks').delete().eq('id', id);
      fetchTrucks();
    } catch (error) {
      console.error('Error deleting truck:', error);
    }
  };

  const openEditModal = (truck: TruckType) => {
    setEditingTruck(truck);
    setFormData({
      truck_number: truck.truck_number,
      wheel_count: truck.wheel_count.toString()
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({ truck_number: '', wheel_count: '10' });
    setEditingTruck(null);
    setShowModal(false);
  };

  const filteredTrucks = trucks.filter((truck) =>
    truck.truck_number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-3 rounded-xl">
            <Truck className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Trucks</h1>
            <p className="text-gray-500 text-sm">{trucks.length} trucks registered</p>
          </div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-blue-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          Add Truck
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search trucks by number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Trucks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredTrucks.map((truck) => (
          <div
            key={truck.id}
            className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-all group"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-blue-50 p-3 rounded-xl">
                  <Truck className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{truck.truck_number}</h3>
                  <div className="flex items-center gap-1.5 text-gray-500 text-sm mt-1">
                    <CircleDot className="w-3.5 h-3.5" />
                    <span>{getWheelLabel(truck.wheel_count || 0)}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEditModal(truck)}
                  className="p-2 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(truck.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {filteredTrucks.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-500">
            {searchTerm ? 'No trucks found matching your search.' : 'No trucks found. Add your first truck to get started.'}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-xl font-bold text-gray-900">
                {editingTruck ? 'Edit Truck' : 'Add New Truck'}
              </h2>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Truck Number *</label>
                <input
                  type="text"
                  required
                  value={formData.truck_number}
                  onChange={(e) => setFormData({ ...formData, truck_number: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none uppercase"
                  placeholder="e.g., GJ01AB1234"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Wheel Count *</label>
                <select
                  value={formData.wheel_count}
                  onChange={(e) => setFormData({ ...formData, wheel_count: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                >
                  <option value="0">0 Wheel (No Vehicle)</option>
                  <option value="2">2 Wheels (Two Wheeler)</option>
                  <option value="3">3 Wheels (Auto/Tempo)</option>
                  <option value="4">4 Wheels (Mini Vehicle)</option>
                  <option value="6">6 Wheels</option>
                  <option value="10">10 Wheels</option>
                  <option value="12">12 Wheels</option>
                  <option value="14">14 Wheels</option>
                  <option value="18">18 Wheels</option>
                  <option value="22">22 Wheels</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-blue-700 transition-all"
                >
                  {editingTruck ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
