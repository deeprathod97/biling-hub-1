import { useEffect, useState } from 'react';
import {
  Calendar,
  Printer,
  Search,
  X,
  FileText,
  IndianRupee,
  Filter
} from 'lucide-react';
import { supabase, Party, Material, Truck as TruckType, COMPANY_PROFILE } from '../lib/supabase';

type BillType = 'stone_sell' | 'stone_purchase' | 'aggregate_sell' | 'aggregate_purchase';

const BILL_TYPE_LABELS: Record<BillType, string> = {
  'stone_sell': 'Stone Sell',
  'stone_purchase': 'Stone Purchase',
  'aggregate_sell': 'Aggregate Sell',
  'aggregate_purchase': 'Aggregate Purchase'
};

type BillReport = {
  id: string;
  bill_number: string;
  bill_date: string;
  bill_type: BillType;
  party: Party | null;
  material: Material | null;
  truck: TruckType | null;
  gross_weight_kg: number;
  tare_weight_kg: number;
  net_weight_ton: number;
  royalty_ton: number;
  royalty_amount: number;
  total_amount: number;
  rate_per_ton: number;
};

export default function DailySalesReport() {
  const [loading, setLoading] = useState(true);
  const [parties, setParties] = useState<Party[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [trucks, setTrucks] = useState<TruckType[]>([]);
  const [reports, setReports] = useState<BillReport[]>([]);

  const [filters, setFilters] = useState({
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    bill_type: '' as string,
    party_id: '',
    material_id: '',
    truck_id: ''
  });

  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchFilterOptions();
    fetchReports();
  }, []);

  useEffect(() => {
    fetchReports();
  }, [filters]);

  const fetchFilterOptions = async () => {
    try {
      const [partiesRes, materialsRes, trucksRes] = await Promise.all([
        supabase.from('parties').select('*').order('name'),
        supabase.from('materials').select('*').order('name'),
        supabase.from('trucks').select('*').order('truck_number')
      ]);

      setParties(partiesRes.data || []);
      setMaterials(materialsRes.data || []);
      setTrucks(trucksRes.data || []);
    } catch (error) {
      console.error('Error fetching filter options:', error);
    }
  };

  const fetchReports = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('bills')
        .select(`
          id,
          bill_number,
          bill_date,
          bill_type,
          gross_weight_kg,
          tare_weight_kg,
          net_weight_ton,
          royalty_ton,
          royalty_amount,
          total_amount,
          party:parties(id, name, mobile_number, address),
          material:materials(id, name, rate_per_ton, royalty_per_ton),
          truck:trucks(id, truck_number, wheel_count)
        `)
        .gte('bill_date', filters.startDate)
        .lte('bill_date', filters.endDate)
        .order('bill_date', { ascending: false })
        .order('bill_number', { ascending: false });

      if (filters.bill_type) {
        query = query.eq('bill_type', filters.bill_type);
      }
      if (filters.party_id) {
        query = query.eq('party_id', filters.party_id);
      }
      if (filters.material_id) {
        query = query.eq('material_id', filters.material_id);
      }
      if (filters.truck_id) {
        query = query.eq('truck_id', filters.truck_id);
      }

      const { data } = await query;

      const formattedData: BillReport[] = (data || []).map((bill) => ({
        id: bill.id,
        bill_number: bill.bill_number,
        bill_date: bill.bill_date,
        bill_type: bill.bill_type || 'aggregate_sell',
        party: bill.party as Party | null,
        material: bill.material as Material | null,
        truck: bill.truck as TruckType | null,
        gross_weight_kg: bill.gross_weight_kg || 0,
        tare_weight_kg: bill.tare_weight_kg || 0,
        net_weight_ton: bill.net_weight_ton || 0,
        royalty_ton: bill.royalty_ton || 0,
        royalty_amount: bill.royalty_amount || 0,
        total_amount: bill.total_amount || 0,
        rate_per_ton: bill.material?.rate_per_ton || 0
      }));

      setReports(formattedData);
    } catch (error) {
      console.error('Error fetching reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setFilters({
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      bill_type: '',
      party_id: '',
      material_id: '',
      truck_id: ''
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatNumber = (num: number, decimals: number = 3) => {
    return new Intl.NumberFormat('en-IN', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(num);
  };

  const getTruckDisplay = (truck: TruckType | null) => {
    if (!truck) return { number: 'No Vehicle', wheels: 0 };
    return { number: truck.truck_number, wheels: truck.wheel_count || 0 };
  };

  // Calculate totals
  const totals = reports.reduce(
    (acc, report) => ({
      gross_weight_kg: acc.gross_weight_kg + report.gross_weight_kg,
      tare_weight_kg: acc.tare_weight_kg + report.tare_weight_kg,
      net_weight_ton: acc.net_weight_ton + report.net_weight_ton,
      royalty_amount: acc.royalty_amount + report.royalty_amount,
      total_amount: acc.total_amount + report.total_amount,
      count: acc.count + 1
    }),
    { gross_weight_kg: 0, tare_weight_kg: 0, net_weight_ton: 0, royalty_amount: 0, total_amount: 0, count: 0 }
  );

  const handlePrint = () => {
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Daily Sales Report - ${COMPANY_PROFILE.name}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 1100px; margin: 0 auto; font-size: 12px; }
          .header { text-align: center; border-bottom: 3px solid #f59e0b; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; color: #1e293b; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .report-title { background: #1e293b; color: #fff; padding: 10px; text-align: center; font-weight: bold; font-size: 16px; margin: 20px -20px; }
          .filter-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; background: #f5f5f5; border-radius: 5px; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          th { background: #1e293b; color: #fff; padding: 10px 8px; text-align: left; font-size: 11px; }
          td { padding: 8px; border-bottom: 1px solid #ddd; }
          tr:nth-child(even) { background: #f9fafb; }
          tr:hover { background: #fef3c7; }
          .text-right { text-align: right; }
          .text-center { text-align: center; }
          .total-row { background: #f59e0b !important; font-weight: bold; }
          .total-row td { border-top: 2px solid #1e293b; }
          .footer { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; font-size: 11px; text-align: center; color: #666; }
          .summary-box { display: flex; justify-content: space-around; margin: 20px 0; padding: 15px; background: linear-gradient(135deg, #1e293b 0%, #334155 100%); color: #fff; border-radius: 10px; }
          .summary-item { text-align: center; }
          .summary-label { font-size: 11px; opacity: 0.8; }
          .summary-value { font-size: 20px; font-weight: bold; margin-top: 5px; }
          @media print { body { padding: 0; } @page { margin: 10mm; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="report-title">DAILY SALES REPORT${filters.bill_type ? ' - ' + BILL_TYPE_LABELS[filters.bill_type as BillType].toUpperCase() : ''}</div>

        <div class="filter-info">
          <div><strong>Period:</strong> ${filters.startDate} to ${filters.endDate}</div>
          <div><strong>Bill Type:</strong> ${filters.bill_type ? BILL_TYPE_LABELS[filters.bill_type as BillType] : 'All Types'}</div>
          <div><strong>Total Bills:</strong> ${totals.count}</div>
          <div><strong>Generated:</strong> ${new Date().toLocaleString('en-IN')}</div>
        </div>

        <div class="summary-box">
          <div class="summary-item">
            <div class="summary-label">Total Net Weight</div>
            <div class="summary-value">${formatNumber(totals.net_weight_ton)} Ton</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Total Royalty</div>
            <div class="summary-value">${formatCurrency(totals.royalty_amount)}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Grand Total</div>
            <div class="summary-value">${formatCurrency(totals.total_amount)}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 5%">#</th>
              <th style="width: 8%">Bill No.</th>
              <th style="width: 7%">Date</th>
              <th style="width: 9%">Type</th>
              <th style="width: 13%">Party Name</th>
              <th style="width: 10%">Material</th>
              <th style="width: 9%">Truck No.</th>
              <th class="text-right" style="width: 7%">Rate/Ton</th>
              <th class="text-right" style="width: 7%">Gross (Kg)</th>
              <th class="text-right" style="width: 7%">Tare (Kg)</th>
              <th class="text-right" style="width: 7%">Net (Ton)</th>
              <th class="text-right" style="width: 10%">Total Amt</th>
            </tr>
          </thead>
          <tbody>
            ${reports.map((report, index) => `
              <tr>
                <td class="text-center">${index + 1}</td>
                <td><strong>${report.bill_number}</strong></td>
                <td>${report.bill_date}</td>
                <td>${BILL_TYPE_LABELS[report.bill_type] || '-'}</td>
                <td>${report.party?.name || '-'}</td>
                <td>${report.material?.name || '-'}</td>
                <td>${getTruckDisplay(report.truck).number} (${getTruckDisplay(report.truck).wheels}W)</td>
                <td class="text-right">${formatCurrency(report.rate_per_ton)}</td>
                <td class="text-right">${formatNumber(report.gross_weight_kg, 2)}</td>
                <td class="text-right">${formatNumber(report.tare_weight_kg, 2)}</td>
                <td class="text-right"><strong>${formatNumber(report.net_weight_ton)}</strong></td>
                <td class="text-right"><strong>${formatCurrency(report.total_amount)}</strong></td>
              </tr>
            `).join('')}
            <tr class="total-row">
              <td colspan="8" class="text-right"><strong>TOTALS:</strong></td>
              <td class="text-right"><strong>${formatNumber(totals.gross_weight_kg, 2)}</strong></td>
              <td class="text-right"><strong>${formatNumber(totals.tare_weight_kg, 2)}</strong></td>
              <td class="text-right"><strong>${formatNumber(totals.net_weight_ton)}</strong></td>
              <td class="text-right"><strong>${formatCurrency(totals.total_amount)}</strong></td>
            </tr>
          </tbody>
        </table>

        <div class="footer">
          <p>This is a computer generated report from ${COMPANY_PROFILE.name} Billing System.</p>
          <p>Report generated on: ${new Date().toLocaleString('en-IN')}</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-100 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Daily Sales Report</h1>
            <p className="text-gray-500 text-sm">Aggregate Material Sales Report</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all ${
              showFilters
                ? 'bg-indigo-100 text-indigo-700'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Filter className="w-5 h-5" />
            Filters
          </button>
          <button
            onClick={handlePrint}
            disabled={reports.length === 0}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-500 to-indigo-600 text-white rounded-xl font-semibold hover:from-indigo-600 hover:to-indigo-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Printer className="w-5 h-5" />
            Print Report
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className={`bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden transition-all ${showFilters ? 'block' : 'hidden'}`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Filter className="w-5 h-5 text-indigo-500" />
              Filter Report
            </h3>
            <button
              onClick={clearFilters}
              className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
            >
              <X className="w-4 h-4" />
              Clear All
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
            {/* Start Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4 inline mr-1" />
                Start Date
              </label>
              <input
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              />
            </div>

            {/* End Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4 inline mr-1" />
                End Date
              </label>
              <input
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              />
            </div>

            {/* Bill Type Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bill Type</label>
              <select
                value={filters.bill_type}
                onChange={(e) => setFilters({ ...filters, bill_type: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              >
                <option value="">All Types</option>
                <option value="stone_sell">Stone Sell</option>
                <option value="stone_purchase">Stone Purchase</option>
                <option value="aggregate_sell">Aggregate Sell</option>
                <option value="aggregate_purchase">Aggregate Purchase</option>
              </select>
            </div>

            {/* Party Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Party</label>
              <select
                value={filters.party_id}
                onChange={(e) => setFilters({ ...filters, party_id: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              >
                <option value="">All Parties</option>
                {parties.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            {/* Material Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Material</label>
              <select
                value={filters.material_id}
                onChange={(e) => setFilters({ ...filters, material_id: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              >
                <option value="">All Materials</option>
                {materials.map((m) => (
                  <option key={m.id} value={m.id}>{m.name}</option>
                ))}
              </select>
            </div>

            {/* Truck Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Truck</label>
              <select
                value={filters.truck_id}
                onChange={(e) => setFilters({ ...filters, truck_id: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              >
                <option value="">All Trucks</option>
                {trucks.map((t) => (
                  <option key={t.id} value={t.id}>{t.truck_number}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-5 text-white">
          <p className="text-blue-100 text-sm font-medium">Total Bills</p>
          <p className="text-3xl font-bold mt-2">{totals.count}</p>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-5 text-white">
          <p className="text-green-100 text-sm font-medium">Net Weight</p>
          <p className="text-3xl font-bold mt-2">{formatNumber(totals.net_weight_ton)} <span className="text-lg">Ton</span></p>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl p-5 text-white">
          <p className="text-amber-100 text-sm font-medium">Royalty Amount</p>
          <p className="text-3xl font-bold mt-2">{formatCurrency(totals.royalty_amount)}</p>
        </div>
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-5 text-white">
          <p className="text-indigo-100 text-sm font-medium">Total Amount</p>
          <p className="text-3xl font-bold mt-2">{formatCurrency(totals.total_amount)}</p>
        </div>
      </div>

      {/* Reports Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Sales Report Details</h3>
            <span className="text-sm text-gray-500">
              Period: {filters.startDate} to {filters.endDate}
            </span>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">#</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Bill No.</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Party Name</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Material</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Truck No.</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Rate/Ton</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Gross (Kg)</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Tare (Kg)</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Net (Ton)</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Royalty Amt</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Total Amt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {reports.map((report, index) => (
                  <tr key={report.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap text-gray-500">{index + 1}</td>
                    <td className="px-4 py-3 whitespace-nowrap font-semibold text-gray-900">{report.bill_number}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{report.bill_date}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={"px-2 py-1 rounded-lg text-xs font-medium " + (report.bill_type?.includes("stone") ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700")}>
                        {BILL_TYPE_LABELS[report.bill_type] || "-"}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{report.party?.name || "-"}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{report.material?.name || '-'}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{getTruckDisplay(report.truck).number} ({getTruckDisplay(report.truck).wheels}W)</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right text-gray-600">{formatCurrency(report.rate_per_ton)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right text-gray-600">{formatNumber(report.gross_weight_kg, 2)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right text-gray-600">{formatNumber(report.tare_weight_kg, 2)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatNumber(report.net_weight_ton)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right text-gray-600">{formatCurrency(report.royalty_amount)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-bold text-green-600">{formatCurrency(report.total_amount)}</td>
                  </tr>
                ))}
                {reports.length === 0 && (
                  <tr>
                    <td colSpan={13} className="px-4 py-12 text-center text-gray-500">
                      No sales data found for the selected period.
                    </td>
                  </tr>
                )}
                {reports.length > 0 && (
                  <tr className="bg-indigo-50 font-bold">
                    <td colSpan={7} className="px-4 py-3 text-right text-indigo-700">TOTALS:</td>
                    <td className="px-4 py-3 text-right text-indigo-700">-</td>
                    <td className="px-4 py-3 text-right text-indigo-900">{formatNumber(totals.gross_weight_kg, 2)}</td>
                    <td className="px-4 py-3 text-right text-indigo-900">{formatNumber(totals.tare_weight_kg, 2)}</td>
                    <td className="px-4 py-3 text-right text-indigo-900">{formatNumber(totals.net_weight_ton)}</td>
                    <td className="px-4 py-3 text-right text-indigo-900">{formatCurrency(totals.royalty_amount)}</td>
                    <td className="px-4 py-3 text-right text-indigo-900">{formatCurrency(totals.total_amount)}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
