import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Search,
  Truck
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface TM {
  id: string;
  tm_number: string;
  tm_code: string | null;
  wheel_count: number | null;
  created_at: string;
}

export default function TMs() {
  const [tms, setTMs] = useState<TM[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingTM, setEditingTM] = useState<TM | null>(null);
  const [formData, setFormData] = useState({
    tm_number: '',
    tm_code: '',
    wheel_count: '10'
  });

  useEffect(() => {
    fetchTMs();
  }, []);

  const fetchTMs = async () => {
    try {
      const { data } = await supabase
        .from('tms')
        .select('*')
        .order('tm_number');
      setTMs(data || []);
    } catch (error) {
      console.error('Error fetching TMs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        tm_number: formData.tm_number.toUpperCase(),
        tm_code: formData.tm_code.toUpperCase() || null,
        wheel_count: parseInt(formData.wheel_count) || 10,
        updated_at: new Date().toISOString()
      };

      if (editingTM) {
        await supabase
          .from('tms')
          .update(payload)
          .eq('id', editingTM.id);
      } else {
        await supabase.from('tms').insert([payload]);
      }
      resetForm();
      fetchTMs();
    } catch (error) {
      console.error('Error saving TM:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this TM?')) return;
    try {
      await supabase.from('tms').delete().eq('id', id);
      fetchTMs();
    } catch (error) {
      console.error('Error deleting TM:', error);
    }
  };

  const openEditModal = (tm: TM) => {
    setEditingTM(tm);
    setFormData({
      tm_number: tm.tm_number,
      tm_code: tm.tm_code || '',
      wheel_count: tm.wheel_count?.toString() || '10'
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      tm_number: '',
      tm_code: '',
      wheel_count: '10'
    });
    setEditingTM(null);
    setShowModal(false);
  };

  const filteredTMs = tms.filter((tm) =>
    tm.tm_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tm.tm_code?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-orange-100 p-3 rounded-xl">
            <Truck className="w-6 h-6 text-orange-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Transit Mixers (TM)</h1>
            <p className="text-gray-500 text-sm">{tms.length} TMs registered</p>
          </div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl font-semibold hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          Add TM
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search TMs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
        />
      </div>

      {/* TMs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTMs.map((tm) => (
          <div
            key={tm.id}
            className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-all group"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="bg-orange-50 p-3 rounded-xl">
                  <Truck className="w-8 h-8 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{tm.tm_number}</h3>
                  {tm.tm_code && (
                    <p className="text-orange-600 font-medium text-sm">Code: {tm.tm_code}</p>
                  )}
                  <p className="text-gray-500 text-sm mt-1">{tm.wheel_count || 10} Wheels</p>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEditModal(tm)}
                  className="p-2 text-gray-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(tm.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {filteredTMs.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-500">
            {searchTerm ? 'No TMs found matching your search.' : 'No TMs found. Add your first TM to get started.'}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-xl font-bold text-gray-900">
                {editingTM ? 'Edit TM' : 'Add New TM'}
              </h2>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <Truck className="w-4 h-4 inline mr-1" />
                  TM Number *
                </label>
                <input
                  type="text"
                  required
                  value={formData.tm_number}
                  onChange={(e) => setFormData({ ...formData, tm_number: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none uppercase"
                  placeholder="e.g., TM-001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">TM Code</label>
                <input
                  type="text"
                  value={formData.tm_code}
                  onChange={(e) => setFormData({ ...formData, tm_code: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none uppercase"
                  placeholder="e.g., TM001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Wheel Count</label>
                <input
                  type="number"
                  min="4"
                  max="20"
                  value={formData.wheel_count}
                  onChange={(e) => setFormData({ ...formData, wheel_count: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl font-semibold hover:from-orange-600 hover:to-orange-700 transition-all"
                >
                  {editingTM ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
