import { useEffect, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Eye,
  Printer,
  IndianRupee,
  Search,
  Calendar,
  FileText,
  CreditCard,
  Palette,
  Receipt
} from 'lucide-react';
import { supabase, Bill, COMPANY_PROFILE } from '../lib/supabase';
import PaymentModal from './PaymentModal';

type View = 'dashboard' | 'parties' | 'materials' | 'trucks' | 'bills' | 'new-bill' | 'edit-bill' | 'print-bill';

type BillType = 'stone_sell' | 'stone_purchase' | 'aggregate_sell' | 'aggregate_purchase';

const BILL_TYPE_LABELS: Record<BillType, string> = {
  'stone_sell': 'Stone Sell',
  'stone_purchase': 'Stone Purchase',
  'aggregate_sell': 'Aggregate Sell',
  'aggregate_purchase': 'Aggregate Purchase'
};

interface StoneBillsProps {
  onNavigate: (view: View, billId?: string) => void;
}

export default function StoneBills({ onNavigate }: StoneBillsProps) {
  const [bills, setBills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [paymentModal, setPaymentModal] = useState<{ open: boolean; bill: any | null }>({
    open: false,
    bill: null
  });

  useEffect(() => {
    fetchBills();
  }, []);

  const fetchBills = async () => {
    try {
      const { data } = await supabase
        .from('bills')
        .select(`
          id,
          bill_number,
          bill_date,
          bill_type,
          gross_weight_kg,
          tare_weight_kg,
          net_weight_ton,
          royalty_ton,
          royalty_amount,
          total_amount,
          payment_amount,
          pending_amount,
          royalty_number,
          party:parties(id, name, mobile_number, address),
          material:materials(id, name, rate_per_ton, royalty_per_ton),
          truck:trucks(id, truck_number, wheel_count)
        `)
        .order('created_at', { ascending: false });

      setBills(data || []);
    } catch (error) {
      console.error('Error fetching bills:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this bill?')) return;
    try {
      await supabase.from('bills').delete().eq('id', id);
      fetchBills();
    } catch (error) {
      console.error('Error deleting bill:', error);
    }
  };

  const getTruckDisplay = (truck: any) => {
    if (!truck) return { number: 'No Vehicle', wheels: 0 };
    return { number: truck.truck_number, wheels: truck.wheel_count || 0 };
  };

  const filteredBills = bills.filter((bill) => {
    const matchesSearch =
      bill.bill_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bill.party?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      getTruckDisplay(bill.truck).number.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = filterType === 'all' || bill.bill_type === filterType;

    return matchesSearch && matchesType;
  });

  // Calculate totals
  const totals = bills.reduce(
    (acc, bill) => ({
      totalAmount: acc.totalAmount + (bill.total_amount || 0),
      totalTons: acc.totalTons + (bill.net_weight_ton || 0),
      pendingAmount: acc.pendingAmount + (bill.pending_amount || 0),
      count: acc.count + 1
    }),
    { totalAmount: 0, totalTons: 0, pendingAmount: 0, count: 0 }
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handlePrint = (bill: any, blackAndWhite: boolean = false) => {
    const truckInfo = getTruckDisplay(bill.truck);

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Bill - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; ${blackAndWhite ? 'filter: grayscale(100%);' : ''} }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 15px; margin-bottom: 20px; }
          .logo { width: 80px; height: 80px; margin: 0 auto 10px; }
          .company-name { font-weight: bold; font-size: 24px; }
          .company-details { font-size: 12px; color: #333; margin-top: 5px; }
          .title-bar { background: ${blackAndWhite ? '#ccc' : '#f59e0b'}; color: ${blackAndWhite ? '#000' : '#fff'}; padding: 10px; text-align: center; font-weight: bold; font-size: 18px; margin: 20px -20px; }
          .bill-info { display: flex; justify-content: space-between; margin: 20px 0; padding: 10px; background: #f5f5f5; }
          .party-info { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
          .party-name { font-size: 16px; font-weight: bold; margin-bottom: 10px; }
          .info-row { display: flex; justify-content: space-between; margin: 5px 0; }
          .weight-section { margin: 20px 0; }
          .weight-table { width: 100%; border-collapse: collapse; margin: 10px 0; }
          .weight-table th, .weight-table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
          .weight-table th { background: #f5f5f5; }
          .amount-section { margin: 20px 0; padding: 15px; background: #f5f5f5; }
          .amount-row { display: flex; justify-content: space-between; margin: 8px 0; padding: 5px 0; }
          .amount-row.total { font-weight: bold; font-size: 18px; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
          .payment-row { background: #e0f2fe; padding: 10px; margin-top: 10px; border-radius: 5px; }
          .footer { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 15px; font-size: 12px; text-align: center; color: #666; }
          .signature-section { display: flex; justify-content: space-between; margin-top: 50px; }
          .signature-box { border-top: 1px solid #000; width: 200px; text-align: center; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${COMPANY_PROFILE.logo}" alt="Logo" class="logo">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div class="company-details">
            (${COMPANY_PROFILE.parentCompany})<br>
            ${COMPANY_PROFILE.location} | GST: ${COMPANY_PROFILE.gst} | Ph: ${COMPANY_PROFILE.contact}
          </div>
        </div>

        <div class="title-bar">${BILL_TYPE_LABELS[bill.bill_type as BillType]?.toUpperCase() || 'BILL'}</div>

        <div class="bill-info">
          <div><strong>Bill No:</strong> ${bill.bill_number}</div>
          <div><strong>Date:</strong> ${bill.bill_date}</div>
        </div>

        <div class="party-info">
          <div class="party-name">${bill.party?.name || 'N/A'}</div>
          ${bill.party?.mobile_number ? `<div class="info-row"><span>Mobile:</span><span>${bill.party.mobile_number}</span></div>` : ''}
          ${bill.party?.address ? `<div class="info-row"><span>Address:</span><span>${bill.party.address}</span></div>` : ''}
        </div>

        <div class="info-row">
          <span><strong>Material:</strong> ${bill.material?.name || 'N/A'}</span>
          <span><strong>Rate:</strong> ${formatCurrency(bill.material?.rate_per_ton || 0)}/Ton</span>
        </div>

        <div class="info-row">
          <span><strong>Truck No:</strong> ${truckInfo.number}</span>
          <span><strong>Wheels:</strong> ${truckInfo.wheels}</span>
        </div>

        ${bill.royalty_number ? `<div class="info-row"><span><strong>Royalty No:</strong> ${bill.royalty_number}</span></div>` : ''}

        <div class="weight-section">
          <table class="weight-table">
            <tr>
              <th>Gross Weight</th>
              <th>Tare Weight</th>
              <th>Net Weight</th>
            </tr>
            <tr>
              <td>${bill.gross_weight_kg || 0} Kg</td>
              <td>${bill.tare_weight_kg || 0} Kg</td>
              <td>${(bill.net_weight_ton || 0).toFixed(3)} Ton</td>
            </tr>
          </table>
        </div>

        <div class="amount-section">
          <div class="amount-row">
            <span>Material Amount</span>
            <span>${formatCurrency((bill.net_weight_ton || 0) * (bill.material?.rate_per_ton || 0))}</span>
          </div>
          <div class="amount-row">
            <span>Royalty Amount</span>
            <span>${formatCurrency(bill.royalty_amount || 0)}</span>
          </div>
          <div class="amount-row total">
            <span>GRAND TOTAL</span>
            <span>${formatCurrency(bill.total_amount || 0)}</span>
          </div>
          ${(bill.payment_amount || 0) > 0 ? `
          <div class="payment-row">
            <div class="amount-row">
              <span>Payment Received</span>
              <span>${formatCurrency(bill.payment_amount || 0)}</span>
            </div>
            <div class="amount-row" style="font-weight: bold; color: #dc2626;">
              <span>Pending Amount</span>
              <span>${formatCurrency(bill.pending_amount || 0)}</span>
            </div>
          </div>
          ` : ''}
        </div>

        <div class="signature-section">
          <div class="signature-box">Receiver's Signature</div>
          <div class="signature-box">For ${COMPANY_PROFILE.name}</div>
        </div>

        <div class="footer">
          <p>This is a computer generated bill.</p>
          <p>Terms & Conditions Apply</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleSlipPrint = (bill: any) => {
    const truckInfo = getTruckDisplay(bill.truck);

    const slipContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Slip - ${bill.bill_number}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 10px; max-width: 400px; margin: 0 auto; font-size: 12px; }
          .header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
          .company-name { font-weight: bold; font-size: 14px; }
          .row { display: flex; justify-content: space-between; margin: 5px 0; padding: 3px 0; }
          .total { font-weight: bold; font-size: 14px; border-top: 1px dashed #000; margin-top: 5px; padding-top: 5px; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${COMPANY_PROFILE.name}</div>
          <div>${COMPANY_PROFILE.location}</div>
        </div>
        <div class="row"><span>Bill No:</span><span>${bill.bill_number}</span></div>
        <div class="row"><span>Type:</span><span>${BILL_TYPE_LABELS[bill.bill_type as BillType] || '-'}</span></div>
        <div class="row"><span>Date:</span><span>${bill.bill_date}</span></div>
        <div class="row"><span>Party:</span><span>${bill.party?.name || '-'}</span></div>
        <div class="row"><span>Material:</span><span>${bill.material?.name || '-'}</span></div>
        <div class="row"><span>Truck:</span><span>${truckInfo.number}</span></div>
        <div class="row"><span>Gross:</span><span>${bill.gross_weight_kg || 0} Kg</span></div>
        <div class="row"><span>Tare:</span><span>${bill.tare_weight_kg || 0} Kg</span></div>
        <div class="row"><span>Net:</span><span>${(bill.net_weight_ton || 0).toFixed(3)} Ton</span></div>
        <div class="total row"><span>TOTAL:</span><span>${formatCurrency(bill.total_amount || 0)}</span></div>
        <div class="row"><span>Payment:</span><span>${formatCurrency(bill.payment_amount || 0)}</span></div>
        <div class="row" style="font-weight: bold;"><span>Pending:</span><span>${formatCurrency(bill.pending_amount || 0)}</span></div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(slipContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-green-100 p-3 rounded-xl">
            <FileText className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">All Bills</h1>
            <p className="text-gray-500 text-sm">{totals.count} bills recorded</p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('new-bill')}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all shadow-lg"
        >
          <Plus className="w-5 h-5" />
          New Bill
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-5 text-white">
          <p className="text-blue-100 text-sm font-medium">Total Bills</p>
          <p className="text-3xl font-bold mt-2">{totals.count}</p>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-5 text-white">
          <p className="text-green-100 text-sm font-medium">Total Amount</p>
          <p className="text-2xl font-bold mt-2">{formatCurrency(totals.totalAmount)}</p>
        </div>
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-5 text-white">
          <p className="text-indigo-100 text-sm font-medium">Total Tons</p>
          <p className="text-3xl font-bold mt-2">{totals.totalTons.toFixed(3)}</p>
        </div>
        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-5 text-white">
          <p className="text-red-100 text-sm font-medium">Pending Amount</p>
          <p className="text-2xl font-bold mt-2">{formatCurrency(totals.pendingAmount)}</p>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by bill number, party, truck..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none min-w-[180px]"
        >
          <option value="all">All Types</option>
          <option value="stone_sell">Stone Sell</option>
          <option value="stone_purchase">Stone Purchase</option>
          <option value="aggregate_sell">Aggregate Sell</option>
          <option value="aggregate_purchase">Aggregate Purchase</option>
        </select>
      </div>

      {/* Bills Table */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Bill No.</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Party</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Material</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Truck</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Net (Ton)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Pending</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredBills.map((bill) => {
                const truckInfo = getTruckDisplay(bill.truck);
                return (
                  <tr key={bill.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap font-bold text-gray-900">#{bill.bill_number}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.bill_date}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                        bill.bill_type?.includes('stone') ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {BILL_TYPE_LABELS[bill.bill_type as BillType] || 'N/A'}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.party?.name || '-'}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{bill.material?.name || '-'}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{truckInfo.number} ({truckInfo.wheels}W)</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-medium text-gray-900">{(bill.net_weight_ton || 0).toFixed(3)}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{formatCurrency(bill.total_amount || 0)}</td>
                    <td className={`px-4 py-3 whitespace-nowrap text-right font-semibold ${bill.pending_amount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {formatCurrency(bill.pending_amount || 0)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handlePrint(bill, false)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Print Bill"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handlePrint(bill, true)}
                          className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title="B&W Print"
                        >
                          <Palette className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleSlipPrint(bill)}
                          className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                          title="Print Slip"
                        >
                          <Receipt className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setPaymentModal({ open: true, bill })}
                          className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Add Payment"
                        >
                          <CreditCard className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onNavigate('edit-bill', bill.id)}
                          className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                          title="Edit Bill"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(bill.id)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Bill"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredBills.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-gray-500">
                    No bills found. Create your first bill to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Modal */}
      {paymentModal.open && paymentModal.bill && (
        <PaymentModal
          bill={paymentModal.bill}
          onClose={() => setPaymentModal({ open: false, bill: null })}
          onUpdated={fetchBills}
        />
      )}
    </div>
  );
}
