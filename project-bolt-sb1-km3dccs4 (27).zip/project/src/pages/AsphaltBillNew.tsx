import { useState, useEffect } from 'react';
import { supabase, type Site, type Truck, type BituminousGrade } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Check, Loader2, Calculator } from 'lucide-react';

const emptyForm = {
  site_id: '',
  bituminous_grade_id: '',
  truck_id: '',
  quantity_ton: '',
  _wheels: '',
};

interface Props {
  onSuccess?: () => void;
}

export default function AsphaltBillNew({ onSuccess }: Props) {
  const [sites, setSites] = useState<Site[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [grades, setGrades] = useState<BituminousGrade[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const selectedSite = sites.find(s => s.id === form.site_id);
  const selectedGrade = grades.find(g => g.id === form.bituminous_grade_id);
  const selectedTruck = trucks.find(t => t.id === form.truck_id);

  const pricePerTon = selectedGrade?.price_per_ton ?? 0;
  const cartingBhada = selectedGrade?.carting_bhada ?? 0;
  const quantityTon = parseFloat(form.quantity_ton) || 0;
  const totalTon = quantityTon;
  const totalAmount = (pricePerTon * quantityTon) + (cartingBhada * quantityTon);

  useEffect(() => {
    Promise.all([
      supabase.from('sites').select('*').order('site_name'),
      supabase.from('trucks').select('*').order('truck_number'),
      supabase.from('bituminous_grades').select('*').order('grade_name'),
    ]).then(([s, t, g]) => {
      setSites(s.data ?? []);
      setTrucks(t.data ?? []);
      setGrades(g.data ?? []);
    });
  }, []);

  async function generateBillNumber(): Promise<string> {
    const { data } = await supabase.from('bill_counters').select('last_number').eq('counter_name', 'asphalt').maybeSingle();
    const next = (data?.last_number ?? 0) + 1;
    await supabase.from('bill_counters').update({ last_number: next }).eq('counter_name', 'asphalt');
    return String(next).padStart(4, '0');
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!form.site_id || !form.bituminous_grade_id || !form.truck_id) {
      setError('Please select site, bituminous grade, and truck.');
      return;
    }
    if (!form.quantity_ton || quantityTon <= 0) {
      setError('Please enter a valid quantity.');
      return;
    }
    setSaving(true);
    const billNumber = await generateBillNumber();
    const payload = {
      bill_number: billNumber,
      site_id: form.site_id,
      site_name: selectedSite!.site_name,
      site_number: selectedSite!.site_number,
      site_location: selectedSite!.site_location,
      site_incharge: selectedSite!.site_incharge,
      bituminous_grade_id: form.bituminous_grade_id,
      grade_name: selectedGrade!.grade_name,
      price_per_ton: pricePerTon,
      carting_bhada: cartingBhada,
      truck_id: form.truck_id,
      truck_number: selectedTruck!.truck_number,
      quantity_ton: quantityTon,
      total_ton: totalTon,
      total_amount: totalAmount,
      payment_status: 'pending',
    };
    const { error: err } = await supabase.from('asphalt_bills').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    setSaving(false);
    setSuccess(`Bill ${billNumber} created successfully!`);
    setForm(emptyForm);
    if (onSuccess) setTimeout(onSuccess, 1500);
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="New Asphalt Bill" subtitle="Create an Asphalt / Bituminous bill" />

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && <p className="text-red-500 text-sm bg-red-50 px-4 py-3 rounded-lg border border-red-100">{error}</p>}
        {success && <p className="text-green-700 text-sm bg-green-50 px-4 py-3 rounded-lg border border-green-100">{success}</p>}

        {/* Site Selection */}
        <Section title="Site Details">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Site</label>
            <select value={form.site_id} onChange={e => setForm(f => ({ ...f, site_id: e.target.value }))} className="select-field">
              <option value="">-- Select Site --</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
            </select>
          </div>
          {selectedSite && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Site Number" value={selectedSite.site_number} />
              <InfoChip label="Location" value={selectedSite.site_location} />
              <InfoChip label="In-Charge" value={selectedSite.site_incharge} />
            </div>
          )}
        </Section>

        {/* Bituminous Grade Selection */}
        <Section title="Bituminous Grade">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Grade</label>
            <select value={form.bituminous_grade_id} onChange={e => setForm(f => ({ ...f, bituminous_grade_id: e.target.value }))} className="select-field">
              <option value="">-- Select Grade --</option>
              {grades.map(g => (
                <option key={g.id} value={g.id}>{g.grade_name} - Rs. {Number(g.price_per_ton).toFixed(2)}/Ton | Carting: Rs. {Number(g.carting_bhada).toFixed(2)}/Ton</option>
              ))}
            </select>
          </div>
          {selectedGrade && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Price Per Ton" value={`Rs. ${Number(selectedGrade.price_per_ton).toFixed(2)}`} />
              <InfoChip label="Carting Bhada" value={`Rs. ${Number(selectedGrade.carting_bhada).toFixed(2)}/Ton`} />
            </div>
          )}
        </Section>

        {/* Truck Selection */}
        <Section title="Truck Details">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Wheels</label>
            <div className="flex flex-wrap gap-2">
              {[...new Set(trucks.map(t => t.wheels))].sort((a, b) => a - b).map(w => (
                <button key={w} type="button" onClick={() => setForm(f => ({ ...f, truck_id: f.truck_id && trucks.find(t => t.id === f.truck_id)?.wheels !== w ? '' : f.truck_id, _wheels: f._wheels === String(w) ? '' : String(w) }))}
                  className={`py-2 px-4 rounded-lg text-xs font-bold border-2 transition-all ${form._wheels === String(w) ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                  {w} Wheels
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Truck</label>
            <select value={form.truck_id} onChange={e => setForm(f => ({ ...f, truck_id: e.target.value }))} className="select-field">
              <option value="">-- Select Truck --</option>
              {trucks.filter(t => !form._wheels || String(t.wheels) === form._wheels).map(t => <option key={t.id} value={t.id}>{t.truck_number} ({t.select_code}) - {t.wheels} Wheels</option>)}
            </select>
          </div>
          {selectedTruck && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Code" value={selectedTruck.select_code} />
              <InfoChip label="Wheels" value={`${selectedTruck.wheels}`} />
            </div>
          )}
        </Section>

        {/* Quantity */}
        <Section title="Quantity">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Quantity (Ton)</label>
            <input type="number" step="0.001" value={form.quantity_ton} onChange={e => setForm(f => ({ ...f, quantity_ton: e.target.value }))} placeholder="0.000" className="input-field" />
          </div>
        </Section>

        {/* Calculation Summary */}
        {(quantityTon > 0 || pricePerTon > 0) && (
          <div className="bg-gray-900 rounded-xl p-5 text-white animate-slide-up">
            <div className="flex items-center gap-2 mb-4">
              <Calculator size={16} className="text-gray-400" />
              <span className="text-sm font-semibold text-gray-300">Calculation Summary</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <CalcItem label="Total Ton" value={`${totalTon.toFixed(3)}`} highlight />
              <CalcItem label="Grade Amount" value={`Rs. ${(pricePerTon * quantityTon).toFixed(2)}`} />
              <CalcItem label="Carting Amount" value={`Rs. ${(cartingBhada * quantityTon).toFixed(2)}`} />
              <CalcItem label="Total Amount" value={`Rs. ${totalAmount.toFixed(2)}`} highlight />
            </div>
            <p className="text-xs text-gray-500 mt-3">
              ({pricePerTon} x {quantityTon} Ton) + ({cartingBhada} x {quantityTon} Ton) = Rs. {totalAmount.toFixed(2)}
            </p>
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl bg-gray-900 text-white font-semibold text-sm hover:bg-gray-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl active:scale-[0.99]"
        >
          {saving ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
          {saving ? 'Creating Bill...' : 'Create Asphalt Bill'}
        </button>
      </form>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm animate-slide-up">
      <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">{title}</h3>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

function InfoChip({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-gray-50 rounded-lg px-3 py-2">
      <p className="text-xs text-gray-400">{label}</p>
      <p className="text-sm font-medium text-gray-800">{value}</p>
    </div>
  );
}

function CalcItem({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className={`text-base font-bold ${highlight ? 'text-white' : 'text-gray-300'}`}>{value}</p>
    </div>
  );
}
