import { useState, useEffect } from 'react';
import { supabase, type Site, type TM } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Check, Loader2, Calculator } from 'lucide-react';

const CONCRETE_GRADES = [
  { grade: 'M5', rate: 2500 },
  { grade: 'M7.5', rate: 3100 },
  { grade: 'M10', rate: 3350 },
  { grade: 'M20', rate: 3900 },
  { grade: 'M25', rate: 4700 },
  { grade: 'M30', rate: 5000 },
  { grade: 'M35', rate: 6100 },
  { grade: 'M40', rate: 6500 },
];

const emptyForm = {
  site_id: '',
  tm_id: '',
  concrete_grade: '',
  carting_bhada: '',
  quantity_mcb: '',
};

interface Props {
  onSuccess?: () => void;
}

export default function RMCBillNew({ onSuccess }: Props) {
  const [sites, setSites] = useState<Site[]>([]);
  const [tms, setTMs] = useState<TM[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const selectedSite = sites.find(s => s.id === form.site_id);
  const selectedTM = tms.find(t => t.id === form.tm_id);
  const selectedGrade = CONCRETE_GRADES.find(g => g.grade === form.concrete_grade);

  const gradeRate = selectedGrade?.rate ?? 0;
  const cartingBhada = parseFloat(form.carting_bhada) || 0;
  const quantityMcb = parseFloat(form.quantity_mcb) || 0;
  const totalMcb = quantityMcb;
  const totalAmount = (gradeRate * quantityMcb) + (cartingBhada * quantityMcb);

  useEffect(() => {
    Promise.all([
      supabase.from('sites').select('*').order('site_name'),
      supabase.from('tms').select('*').order('tm_number'),
    ]).then(([s, t]) => {
      setSites(s.data ?? []);
      setTMs(t.data ?? []);
    });
  }, []);

  async function generateBillNumber(): Promise<string> {
    const { data } = await supabase.from('bill_counters').select('last_number').eq('counter_name', 'rmc').maybeSingle();
    const next = (data?.last_number ?? 0) + 1;
    await supabase.from('bill_counters').update({ last_number: next }).eq('counter_name', 'rmc');
    return String(next).padStart(5, '0');
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!form.site_id || !form.tm_id || !form.concrete_grade) {
      setError('Please select site, TM and concrete grade.');
      return;
    }
    if (!form.quantity_mcb || quantityMcb <= 0) {
      setError('Please enter a valid quantity.');
      return;
    }
    setSaving(true);
    const billNumber = await generateBillNumber();
    const payload = {
      bill_number: billNumber,
      site_id: form.site_id,
      site_name: selectedSite!.site_name,
      site_number: selectedSite!.site_number,
      site_location: selectedSite!.site_location,
      site_incharge: selectedSite!.site_incharge,
      tm_id: form.tm_id,
      tm_number: selectedTM!.tm_number,
      concrete_grade: form.concrete_grade,
      grade_rate: gradeRate,
      carting_bhada: cartingBhada,
      quantity_mcb: quantityMcb,
      total_mcb: totalMcb,
      total_amount: totalAmount,
      payment_status: 'pending',
    };
    const { error: err } = await supabase.from('rmc_bills').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    setSaving(false);
    setSuccess(`Bill ${billNumber} created successfully!`);
    setForm(emptyForm);
    if (onSuccess) setTimeout(onSuccess, 1500);
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <PageHeader title="New RMC Bill" subtitle="Create a Ready Mix Concrete bill" />

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && <p className="text-red-500 text-sm bg-red-50 px-4 py-3 rounded-lg border border-red-100">{error}</p>}
        {success && <p className="text-green-700 text-sm bg-green-50 px-4 py-3 rounded-lg border border-green-100">{success}</p>}

        {/* Site Selection */}
        <Section title="Site Details">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Site</label>
            <select value={form.site_id} onChange={e => setForm(f => ({ ...f, site_id: e.target.value }))} className="select-field">
              <option value="">-- Select Site --</option>
              {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
            </select>
          </div>
          {selectedSite && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Site Number" value={selectedSite.site_number} />
              <InfoChip label="Location" value={selectedSite.site_location} />
              <InfoChip label="In-Charge" value={selectedSite.site_incharge} />
            </div>
          )}
        </Section>

        {/* TM Selection */}
        <Section title="Transit Mixer">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select TM</label>
            <select value={form.tm_id} onChange={e => setForm(f => ({ ...f, tm_id: e.target.value }))} className="select-field">
              <option value="">-- Select TM --</option>
              {tms.map(t => <option key={t.id} value={t.id}>{t.tm_number} ({t.code})</option>)}
            </select>
          </div>
          {selectedTM && (
            <div className="grid grid-cols-2 gap-3 mt-2">
              <InfoChip label="Code" value={selectedTM.code} />
              <InfoChip label="Wheels" value={`${selectedTM.wheels}`} />
            </div>
          )}
        </Section>

        {/* Concrete Grade */}
        <Section title="Concrete Grade & Pricing">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Select Grade</label>
            <select value={form.concrete_grade} onChange={e => setForm(f => ({ ...f, concrete_grade: e.target.value }))} className="select-field">
              <option value="">-- Select Grade --</option>
              {CONCRETE_GRADES.map(g => (
                <option key={g.grade} value={g.grade}>{g.grade} - Rs. {g.rate}/MCB</option>
              ))}
            </select>
          </div>
          {selectedGrade && (
            <div className="mt-2">
              <InfoChip label="Rate per MCB" value={`Rs. ${selectedGrade.rate.toFixed(2)}`} />
            </div>
          )}
        </Section>

        {/* Carting & Quantity */}
        <Section title="Carting & Quantity">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Carting Bhada (Rs./MCB)</label>
              <input type="number" step="0.01" value={form.carting_bhada} onChange={e => setForm(f => ({ ...f, carting_bhada: e.target.value }))} placeholder="0.00" className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">Quantity (MCB)</label>
              <input type="number" step="0.001" value={form.quantity_mcb} onChange={e => setForm(f => ({ ...f, quantity_mcb: e.target.value }))} placeholder="0.000" className="input-field" />
            </div>
          </div>
        </Section>

        {/* Calculation Summary */}
        {(quantityMcb > 0 || gradeRate > 0) && (
          <div className="bg-gray-900 rounded-xl p-5 text-white animate-slide-up">
            <div className="flex items-center gap-2 mb-4">
              <Calculator size={16} className="text-gray-400" />
              <span className="text-sm font-semibold text-gray-300">Calculation Summary</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <CalcItem label="Total MCB" value={`${totalMcb.toFixed(3)}`} highlight />
              <CalcItem label="Grade Amount" value={`Rs. ${(gradeRate * quantityMcb).toFixed(2)}`} />
              <CalcItem label="Carting Amount" value={`Rs. ${(cartingBhada * quantityMcb).toFixed(2)}`} />
              <CalcItem label="Total Amount" value={`Rs. ${totalAmount.toFixed(2)}`} highlight />
            </div>
            <p className="text-xs text-gray-500 mt-3">
              ({gradeRate} x {quantityMcb} MCB) + ({cartingBhada} x {quantityMcb} MCB) = Rs. {totalAmount.toFixed(2)}
            </p>
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl bg-gray-900 text-white font-semibold text-sm hover:bg-gray-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl active:scale-[0.99]"
        >
          {saving ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
          {saving ? 'Creating Bill...' : 'Create RMC Bill'}
        </button>
      </form>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm animate-slide-up">
      <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">{title}</h3>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

function InfoChip({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-gray-50 rounded-lg px-3 py-2">
      <p className="text-xs text-gray-400">{label}</p>
      <p className="text-sm font-medium text-gray-800">{value}</p>
    </div>
  );
}

function CalcItem({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className={`text-base font-bold ${highlight ? 'text-white' : 'text-gray-300'}`}>{value}</p>
    </div>
  );
}
