import { useState, useEffect } from 'react';
import { supabase, type ColdMillingMachine, type ColdMillingRate, type Site } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Check, Loader2 } from 'lucide-react';

const RATE_TYPE_LABELS: Record<string, string> = {
  per_hour_rent: 'Per Hour Rent',
  '8_hour_shift': '8 Hour Shift',
  '12_hour_shift': '12 Hour Shift',
  machine_only_per_day: 'Machine Only Per Day',
  full_package_per_day: 'Full Package Per Day',
};

export default function ColdMillingBillNew({ onSuccess }: { onSuccess: () => void }) {
  const [sites, setSites] = useState<Site[]>([]);
  const [machines, setMachines] = useState<ColdMillingMachine[]>([]);
  const [rates, setRates] = useState<ColdMillingRate[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [siteId, setSiteId] = useState('');
  const [machineId, setMachineId] = useState('');
  const [rateType, setRateType] = useState('');
  const [selectedRate, setSelectedRate] = useState<ColdMillingRate | null>(null);
  const [quantity, setQuantity] = useState('');
  const [billDate, setBillDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const amount = selectedRate ? Number(selectedRate.rate) * Number(quantity || 0) : 0;

  useEffect(() => {
    supabase.from('sites').select('*').order('site_name').then(({ data }) => setSites(data ?? []));
    supabase.from('cold_milling_machines').select('*').order('company_name').then(({ data }) => setMachines(data ?? []));
    supabase.from('cold_milling_rates').select('*').then(({ data }) => setRates(data ?? []));
  }, []);

  useEffect(() => {
    if (machineId && rateType) {
      setSelectedRate(rates.find(r => r.machine_id === machineId && r.rate_type === rateType) ?? null);
    } else {
      setSelectedRate(null);
    }
  }, [machineId, rateType, rates]);

  const availableRateTypes = [...new Set(rates.filter(r => r.machine_id === machineId).map(r => r.rate_type))];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setError('');
    if (!siteId || !machineId || !rateType || !quantity) { setError('All fields are required.'); return; }
    if (!selectedRate) { setError('No rate configured for this selection.'); return; }
    setSaving(true);

    const { data: lastBill } = await supabase.from('cold_milling_bills').select('bill_number').order('created_at', { ascending: false }).limit(1);
    let nextNum = 1;
    if (lastBill && lastBill.length > 0) { const n = parseInt(lastBill[0].bill_number, 10); if (!isNaN(n)) nextNum = n + 1; }
    const billNumber = String(nextNum).padStart(5, '0');

    const machine = machines.find(m => m.id === machineId);
    const site = sites.find(s => s.id === siteId);
    const calcAmount = Number(selectedRate.rate) * Number(quantity);

    const { error: err } = await supabase.from('cold_milling_bills').insert({
      bill_number: billNumber,
      site_id: siteId,
      site_name: site?.site_name ?? '',
      machine_id: machineId,
      machine_name: machine ? `${machine.company_name} - ${machine.model}` : '',
      machine_code: machine?.code ?? '',
      rate_type: rateType,
      rate: Number(selectedRate.rate),
      unit: selectedRate.unit,
      quantity: Number(quantity),
      amount: calcAmount,
      paid_amount: 0,
      pending_amount: calcAmount,
      payment_status: 'pending',
      bill_date: billDate,
      notes,
    });

    if (err) { setError(err.message); setSaving(false); return; }
    setSaving(false); onSuccess();
  }

  return (
    <div className="p-4 sm:p-6 max-w-2xl mx-auto">
      <PageHeader title="New Cold Milling Bill" subtitle="Create a new bill for cold milling machine work" />

      <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded-xl p-6 space-y-5 mt-4 shadow-sm">
        {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Bill Date</label>
          <input type="date" value={billDate} onChange={e => setBillDate(e.target.value)} className="input-field" />
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Select Site</label>
          <select value={siteId} onChange={e => setSiteId(e.target.value)} className="select-field">
            <option value="">-- Select Site --</option>
            {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Select Cold Milling Machine</label>
          <select value={machineId} onChange={e => { setMachineId(e.target.value); setRateType(''); }} className="select-field">
            <option value="">-- Select Machine --</option>
            {machines.map(m => <option key={m.id} value={m.id}>{m.company_name} - {m.model} ({m.code || 'No code'})</option>)}
          </select>
        </div>

        {machineId && availableRateTypes.length > 0 && (
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Rate Configuration</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {availableRateTypes.map(rt => (
                <button key={rt} type="button" onClick={() => setRateType(rt)}
                  className={`py-2 px-3 rounded-lg text-xs font-medium border-2 transition-all text-left ${rateType === rt ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                  {RATE_TYPE_LABELS[rt] || rt}
                </button>
              ))}
            </div>
          </div>
        )}

        {selectedRate && (
          <div className="bg-green-50 rounded-lg p-3 border border-green-200">
            <p className="text-xs text-green-700">Selected Rate: <span className="font-bold">Rs. {Number(selectedRate.rate).toFixed(2)}</span> / {selectedRate.unit}</p>
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Quantity ({selectedRate?.unit || 'units'})</label>
          <input type="number" step="0.01" value={quantity} onChange={e => setQuantity(e.target.value)} className="input-field" placeholder="Enter quantity" />
        </div>

        {selectedRate && quantity && (
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 space-y-2">
            <div className="flex justify-between text-sm"><span className="text-gray-500">Rate:</span><span className="font-semibold">Rs. {Number(selectedRate.rate).toFixed(2)} / {selectedRate.unit}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Quantity:</span><span className="font-semibold">{quantity} {selectedRate.unit}</span></div>
            <div className="border-t border-gray-200 pt-2 flex justify-between text-base font-bold">
              <span>Total Amount:</span><span>Rs. {amount.toFixed(2)}</span>
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="input-field resize-none" placeholder="Optional notes..." />
        </div>

        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onSuccess} className="flex-1 py-3 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving || !selectedRate || !quantity} className="flex-1 py-3 rounded-lg bg-gray-900 text-white text-sm font-semibold hover:bg-gray-700 flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
            Submit Bill
          </button>
        </div>
      </form>
    </div>
  );
}
