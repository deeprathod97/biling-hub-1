import { useState, useEffect } from 'react';
import { supabase, type Excavator, type ExcavatorRate, type Site } from '../lib/supabase';
import PageHeader from '../components/PageHeader';
import { Check, Loader2, X, FileText } from 'lucide-react';

export default function ExcavatorBillNew({ onSuccess }: { onSuccess: () => void }) {
  const [sites, setSites] = useState<Site[]>([]);
  const [excavators, setExcavators] = useState<Excavator[]>([]);
  const [rates, setRates] = useState<ExcavatorRate[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [siteId, setSiteId] = useState('');
  const [excavatorId, setExcavatorId] = useState('');
  const [rateType, setRateType] = useState('per_hour');
  const [selectedRate, setSelectedRate] = useState<ExcavatorRate | null>(null);
  const [quantity, setQuantity] = useState('');
  const [billDate, setBillDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const amount = selectedRate ? Number(selectedRate.rate) * Number(quantity || 0) : 0;

  useEffect(() => {
    supabase.from('sites').select('*').order('site_name').then(({ data }) => setSites(data ?? []));
    supabase.from('excavators').select('*').order('company_name').then(({ data }) => setExcavators(data ?? []));
    supabase.from('excavator_rates').select('*').order('created_at').then(({ data }) => setRates(data ?? []));
  }, []);

  useEffect(() => {
    if (excavatorId && rateType) {
      const match = rates.find(r => r.excavator_id === excavatorId && r.rate_type === rateType);
      setSelectedRate(match ?? null);
    } else {
      setSelectedRate(null);
    }
  }, [excavatorId, rateType, rates]);

  const availableRates = rates.filter(r => r.excavator_id === excavatorId);
  const availableRateTypes = [...new Set(availableRates.map(r => r.rate_type))];

  const rateTypeLabels: Record<string, string> = {
    per_minutes: 'Per Minutes', per_hour: 'Per Hour', per_dumper: 'Per Dumper',
    per_months: 'Per Months', per_loads: 'Per Loads', per_lid: 'Per Lid',
  };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!siteId || !excavatorId || !rateType || !quantity) { setError('All fields are required.'); return; }
    if (!selectedRate) { setError('No rate configured for this selection.'); return; }
    setSaving(true);

    // Generate bill number: 00001, 00002, etc.
    const { data: lastBill } = await supabase.from('excavator_bills').select('bill_number').order('created_at', { ascending: false }).limit(1);
    let nextNum = 1;
    if (lastBill && lastBill.length > 0) {
      const lastNum = parseInt(lastBill[0].bill_number, 10);
      if (!isNaN(lastNum)) nextNum = lastNum + 1;
    }
    const billNumber = String(nextNum).padStart(5, '0');

    const exc = excavators.find(e => e.id === excavatorId);
    const site = sites.find(s => s.id === siteId);
    const calcAmount = Number(selectedRate.rate) * Number(quantity);

    const payload = {
      bill_number: billNumber,
      site_id: siteId,
      site_name: site?.site_name ?? '',
      excavator_id: excavatorId,
      excavator_name: exc ? `${exc.company_name} - ${exc.model}` : '',
      excavator_code: exc?.code ?? '',
      rate_type: rateType,
      rate: Number(selectedRate.rate),
      unit: selectedRate.unit,
      quantity: Number(quantity),
      amount: calcAmount,
      paid_amount: 0,
      pending_amount: calcAmount,
      payment_status: 'pending',
      bill_date: billDate,
      notes,
    };

    const { error: err } = await supabase.from('excavator_bills').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    setSaving(false);
    onSuccess();
  }

  return (
    <div className="p-4 sm:p-6 max-w-2xl mx-auto">
      <PageHeader title="New Excavator Bill" subtitle="Create a new bill for excavator work" />

      <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded-xl p-6 space-y-5 mt-4 shadow-sm">
        {error && <p className="text-red-500 text-sm bg-red-50 px-3 py-2 rounded-lg">{error}</p>}

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Bill Date</label>
          <input type="date" value={billDate} onChange={e => setBillDate(e.target.value)} className="input-field" />
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Select Site</label>
          <select value={siteId} onChange={e => setSiteId(e.target.value)} className="select-field">
            <option value="">-- Select Site --</option>
            {sites.map(s => <option key={s.id} value={s.id}>{s.site_name} (#{s.site_number})</option>)}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Select Excavator</label>
          <select value={excavatorId} onChange={e => { setExcavatorId(e.target.value); setRateType('per_hour'); }} className="select-field">
            <option value="">-- Select Excavator --</option>
            {excavators.map(e => <option key={e.id} value={e.id}>{e.company_name} - {e.model} ({e.code || 'No code'}) [{e.type === 'jcb' ? 'JCB' : 'Excavator'}]</option>)}
          </select>
        </div>

        {excavatorId && availableRateTypes.length > 0 && (
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Rate Configuration</label>
            <div className="grid grid-cols-3 gap-2">
              {availableRateTypes.map(rt => (
                <button key={rt} type="button" onClick={() => setRateType(rt)}
                  className={`py-2 rounded-lg text-xs font-medium border-2 transition-all ${rateType === rt ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                  {rateTypeLabels[rt] || rt}
                </button>
              ))}
            </div>
          </div>
        )}

        {selectedRate && (
          <div className="bg-green-50 rounded-lg p-3 border border-green-200">
            <p className="text-xs text-green-600">Selected Rate: <span className="font-bold">Rs. {Number(selectedRate.rate).toFixed(2)}</span> / {selectedRate.unit}</p>
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Quantity ({selectedRate?.unit || 'units'})</label>
          <input type="number" step="0.01" value={quantity} onChange={e => setQuantity(e.target.value)} className="input-field" placeholder="Enter quantity" />
        </div>

        {selectedRate && quantity && (
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 space-y-2">
            <div className="flex justify-between text-sm"><span className="text-gray-500">Rate:</span><span className="font-semibold">Rs. {Number(selectedRate.rate).toFixed(2)} / {selectedRate.unit}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Quantity:</span><span className="font-semibold">{quantity} {selectedRate.unit}</span></div>
            <div className="border-t border-gray-200 pt-2 flex justify-between text-base font-bold">
              <span>Total Amount:</span><span className="text-gray-900">Rs. {amount.toFixed(2)}</span>
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Notes</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="input-field resize-none" placeholder="Optional notes..." />
        </div>

        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onSuccess} className="flex-1 py-3 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
          <button type="submit" disabled={saving || !selectedRate} className="flex-1 py-3 rounded-lg bg-gray-900 text-white text-sm font-semibold hover:bg-gray-700 flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed">
            {saving ? <Loader2 size={16} class="animate-spin" /> : <Check size={16} />}
            Submit Bill
          </button>
        </div>
      </form>
    </div>
  );
}
